create view v_gas_interconn
            ("ID", "Интерконнектор", "Газопровод", "Статус", "Направление", "Из страны", "В страну", "Оператор",
             "Уникальный оператор", "Макс проп способность МВтч в день", "Примечание")
as
SELECT t1.id                                             AS "ID",
       t1.name                                           AS "Интерконнектор",
       COALESCE(t1.pipeline_name, ''::character varying) AS "Газопровод",
       t3.status                                         AS "Статус",
       t1.direction                                      AS "Направление",
       t4.country_rus                                    AS "Из страны",
       t5.country_rus                                    AS "В страну",
       t1.operator                                       AS "Оператор",
       t1.unique_operator                                AS "Уникальный оператор",
       t1.max_capacity                                   AS "Макс проп способность МВтч в день",
       t1.comments                                       AS "Примечание"
FROM im.gas_interconn_info t1
         LEFT JOIN im.gas_interconn_status t3 ON t1.status = t3.id
         LEFT JOIN countries t4 ON t1.country_from = t4.id
         LEFT JOIN countries t5 ON t1.country_to = t5.id;

alter table v_gas_interconn
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_gas_interconn to quicksight;

