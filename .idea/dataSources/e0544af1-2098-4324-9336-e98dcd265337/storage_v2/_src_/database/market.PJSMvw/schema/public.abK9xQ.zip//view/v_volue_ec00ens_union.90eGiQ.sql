create view v_volue_ec00ens_union("Date Time CET", "Date Time UTC", "Commodity", "Zone", "Value") as
SELECT DISTINCT ON (f.date_time, f.zone, f.commodity) f.local_date_time AS "Date Time CET",
                                                      f.date_time       AS "Date Time UTC",
                                                      vc.commodity      AS "Commodity",
                                                      vfpz.zone         AS "Zone",
                                                      f.value           AS "Value"
FROM (SELECT volue_forecast_phys.id,
             volue_forecast_phys.iteration,
             volue_forecast_phys.zone,
             volue_forecast_phys.local_date_time,
             volue_forecast_phys.value,
             volue_forecast_phys.commodity,
             volue_forecast_phys.date_time
      FROM volue_forecast_phys
      WHERE volue_forecast_phys.date_time >= (CURRENT_DATE - '3 days'::interval)
        AND volue_forecast_phys.date_time < (CURRENT_DATE + '3 mons'::interval)
        AND (volue_forecast_phys.commodity = ANY (ARRAY [1, 2, 3]))
      UNION
      SELECT volue_forecast_phys_ec00ens.id,
             volue_forecast_phys_ec00ens.iteration,
             volue_forecast_phys_ec00ens.zone,
             volue_forecast_phys_ec00ens.local_date_time,
             volue_forecast_phys_ec00ens.value,
             volue_forecast_phys_ec00ens.commodity,
             volue_forecast_phys_ec00ens.date_time
      FROM volue_forecast_phys_ec00ens
      WHERE volue_forecast_phys_ec00ens.date_time >= (CURRENT_DATE - '3 days'::interval)
        AND volue_forecast_phys_ec00ens.date_time < (CURRENT_DATE + '3 mons'::interval)
        AND (volue_forecast_phys_ec00ens.commodity = ANY (ARRAY [1, 2, 3]))
      GROUP BY volue_forecast_phys_ec00ens.date_time, volue_forecast_phys_ec00ens.zone,
               volue_forecast_phys_ec00ens.commodity
      ORDER BY 2 DESC) f
         LEFT JOIN volue_commodities vc ON f.commodity = vc.id
         LEFT JOIN volue_forecast_phys_zones vfpz ON f.zone = vfpz.id
WHERE date_part('minute'::text, f.date_time) = 0::double precision
ORDER BY f.date_time;

alter table v_volue_ec00ens_union
    owner to postgres;

