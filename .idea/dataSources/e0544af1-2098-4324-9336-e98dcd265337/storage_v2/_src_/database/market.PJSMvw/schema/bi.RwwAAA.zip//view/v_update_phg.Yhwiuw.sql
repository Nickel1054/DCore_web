create view v_update_phg(ugsid, tech_min, tech_max, max_inj, max_wtd) as
SELECT ugseurope.ugsid,
       round(min(COALESCE(ugseurope.corrected_gas_in_storage, 0::double precision))::numeric, 4) AS tech_min,
       round(max(COALESCE(ugseurope.corrected_gas_in_storage, 0::double precision))::numeric, 4) AS tech_max,
       round(max(COALESCE(ugseurope.injection, 0::double precision))::numeric, 4)                AS max_inj,
       round(max(COALESCE(ugseurope.withdrawal, 0::double precision))::numeric, 4)               AS max_wtd
FROM ugseurope
GROUP BY ugseurope.ugsid;

alter table v_update_phg
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_update_phg to quicksight;

