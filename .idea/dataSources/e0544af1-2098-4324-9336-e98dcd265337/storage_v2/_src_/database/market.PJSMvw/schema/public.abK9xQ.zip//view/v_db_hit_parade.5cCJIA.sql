create view v_db_hit_parade(schema, relation, total_size) as
SELECT n.nspname                                               AS schema,
       c.relname                                               AS relation,
       pg_size_pretty(pg_total_relation_size(c.oid::regclass)) AS total_size
FROM pg_class c
         LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE (n.nspname <> ALL (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
  AND c.relkind <> 'i'::"char"
  AND n.nspname !~ '^pg_toast'::text
ORDER BY (pg_total_relation_size(c.oid::regclass)) DESC
LIMIT 20;

alter table v_db_hit_parade
    owner to postgres;

