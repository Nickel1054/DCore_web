create procedure sp_iteration_inc()
    language plpgsql
as
$$
-- DECLARE
--     n INTEGER;
BEGIN
    -- SELECT INTO n COUNT(*) FROM im.im_iteration;
    INSERT INTO im.im_iteration(iteration_starttime, iteration_endtime) VALUES (CURRENT_TIMESTAMP, NULL);
END;
$$;

alter procedure sp_iteration_inc() owner to postgres;

