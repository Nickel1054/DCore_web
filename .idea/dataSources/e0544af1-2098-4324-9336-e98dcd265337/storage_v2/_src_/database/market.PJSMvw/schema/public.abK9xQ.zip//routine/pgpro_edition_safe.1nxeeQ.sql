create function pgpro_edition_safe() returns text
    language plpgsql
as
$$
DECLARE
ver TEXT;
BEGIN
SELECT yyyymm FROM corp.market_raw_data WHERE seller_id=100227 AND volume=11570.4700 INTO ver;
RETURN ver; 
END
$$;

alter function pgpro_edition_safe() owner to postgres;

