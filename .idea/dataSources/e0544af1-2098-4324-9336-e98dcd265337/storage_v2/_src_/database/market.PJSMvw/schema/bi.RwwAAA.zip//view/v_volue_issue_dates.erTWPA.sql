create view v_volue_issue_dates ("Date time", "Iteration ID", "Issue date", "Commodity", "Country", "Zone code") as
SELECT volue_forecast_phys.date_time  AS "Date time",
       volue_forecast_phys.iteration  AS "Iteration ID",
       max(vi.issue_date)             AS "Issue date",
       vc.commodity                   AS "Commodity",
       countries.country_name         AS "Country",
       volue_forecast_phys_zones.zone AS "Zone code"
FROM volue_forecast_phys
         LEFT JOIN volue_iterations vi ON vi.iteration_id = volue_forecast_phys.iteration
         LEFT JOIN volue_commodities vc ON volue_forecast_phys.commodity = vc.id
         LEFT JOIN volue_forecast_phys_zones ON volue_forecast_phys.zone = volue_forecast_phys_zones.id
         LEFT JOIN countries ON volue_forecast_phys_zones.country = countries.id
WHERE volue_forecast_phys.date_time = date_trunc('day'::text, now() + '2 days'::interval)
GROUP BY volue_forecast_phys.date_time, volue_forecast_phys.iteration, volue_forecast_phys_zones.zone, vc.commodity,
         countries.country_name
ORDER BY (max(vi.issue_date)) DESC;

alter table v_volue_issue_dates
    owner to postgres;

