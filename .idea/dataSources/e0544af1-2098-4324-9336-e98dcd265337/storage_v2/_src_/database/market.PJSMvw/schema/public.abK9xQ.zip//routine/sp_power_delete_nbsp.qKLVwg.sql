create procedure sp_power_delete_nbsp()
    language sql
as
$$
    UPDATE public.power_powerunits_directory_new_info
    SET country = replace(country,chr(160),''),
        owner = replace(owner,chr(160),''),
        powerstation = replace(powerstation,chr(160),''),
        powerstation_eic_code = replace(powerstation_eic_code,chr(160),''),
        powerunit = replace(powerunit,chr(160),''),
        powerunit_eic_code = replace(powerunit_eic_code,chr(160),''),
        powerunit_status = replace(powerunit_status,chr(160),'')
    WHERE country LIKE '%'||chr(160)||'%'
       OR owner LIKE '%'||chr(160)||'%'
       OR powerstation LIKE '%'||chr(160)||'%'
       OR powerstation_eic_code LIKE '%'||chr(160)||'%'
       OR powerunit LIKE '%'||chr(160)||'%'
       OR powerunit_eic_code LIKE '%'||chr(160)||'%'
       OR powerunit_status LIKE '%'||chr(160)||'%'
       OR data_source LIKE '%'||chr(160)||'%'
       OR note LIKE '%'||chr(160)||'%'
$$;

alter procedure sp_power_delete_nbsp() owner to postgres;

