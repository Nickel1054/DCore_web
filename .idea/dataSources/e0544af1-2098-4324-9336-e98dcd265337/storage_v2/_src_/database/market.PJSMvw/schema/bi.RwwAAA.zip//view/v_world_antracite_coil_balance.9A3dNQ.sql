create view v_world_antracite_coil_balance(commodity, series_name_ru, d_date, value) as
SELECT 'Антрацит'::text AS commodity,
       t1.series_name_ru,
       t2.d_date,
       t2.value
FROM series_dictionary t1
         LEFT JOIN series_data t2 ON t1.series_id = t2.series_id
WHERE t1.series_id = ANY (ARRAY [123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133])
UNION ALL
SELECT 'Энергетический уголь'::text AS commodity,
       t1.series_name_ru,
       t2.d_date,
       t2.value
FROM series_dictionary t1
         LEFT JOIN series_data t2 ON t1.series_id = t2.series_id
WHERE t1.series_id = ANY (ARRAY [108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122]);

alter table v_world_antracite_coil_balance
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_world_antracite_coil_balance to quicksight;

