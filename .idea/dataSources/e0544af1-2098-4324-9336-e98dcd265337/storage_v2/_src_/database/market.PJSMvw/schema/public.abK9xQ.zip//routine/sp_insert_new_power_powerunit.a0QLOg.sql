create procedure sp_insert_new_power_powerunit()
    language sql
as
$$
    INSERT INTO power_powerunit_info(p_name, p_eic_code, p_status, p_power_output_mw, p_power_max_generation,
                                     p_chp_mode, p_co2_pollutions, p_start_date, p_end_date, p_s_id, p_f_id)
    (
        SELECT t1.powerunit
             , t1.powerunit_eic_code
             , t1.powerunit_status
             , t1.powerunit_output_mw
             , t1.powerunit_max_generation_mw
             , t1.chp_mode
             , t1.co2_pollution
             , t1.start_date
             , t1.end_date
             , t2.s_id
             , t3.f_id
        FROM power_powerunits_directory_new_info t1
        LEFT JOIN power_station_info t2 ON (t1.powerstation = t2.s_name AND t1.powerstation_eic_code = t2.s_eic_code)
        LEFT JOIN power_fuel_info t3 ON t1.fuel_type = t3.f_type
        EXCEPT
             (
                 SELECT p_name
                      , p_eic_code
                      , p_status
                      , p_power_output_mw
                      , p_power_max_generation
                      , p_chp_mode
                      , p_co2_pollutions
                      , p_start_date
                      , p_end_date
                      , p_s_id
                      , p_f_id
                 FROM power_powerunit_info
             )
    );
$$;

alter procedure sp_insert_new_power_powerunit() owner to postgres;

