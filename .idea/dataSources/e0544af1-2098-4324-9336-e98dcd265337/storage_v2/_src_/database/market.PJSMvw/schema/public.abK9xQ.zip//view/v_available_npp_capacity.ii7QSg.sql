create view v_available_npp_capacity
            ("Итерация", "Сценарий", "Дата-время UTC", "Рынок", "ID энергоблока", "EIC код энергоблока",
             "Электростанция", "Ном. доступ. мощность", "Доступ. мощность + ремонты", "Доступ. мощность + ограничения")
as
SELECT t1.gfc_iteration         AS "Итерация",
       t1.gfc_scenario          AS "Сценарий",
       t1.gfc_utc_datetime      AS "Дата-время UTC",
       t5.country_rus           AS "Рынок",
       t1.gfc_generationunit_id AS "ID энергоблока",
       t2.eic_code              AS "EIC код энергоблока",
       t3.station               AS "Электростанция",
       t1.gfc_val_1             AS "Ном. доступ. мощность",
       t1.gfc_val_2             AS "Доступ. мощность + ремонты",
       t1.gfc_val_3             AS "Доступ. мощность + ограничения"
FROM im.im_generationunit_forecast_calc t1
         LEFT JOIN im.power_powerunit_info t2 ON t1.gfc_generationunit_id = t2.unit_id
         LEFT JOIN im.power_powerstation_info t3 ON t2.station_id = t3.id
         LEFT JOIN im.im_market_country t4 ON t1.gfc_market_id = t4.m_id AND t4.m_commodity = 1
         LEFT JOIN countries t5 ON t4.m_country = t5.id
WHERE t1.gfc_iteration > ((SELECT im_system_variables.max_iter - 3
                           FROM im.im_system_variables))
  AND t1.gfc_indicator_id = 15
  AND t1.gfc_scenario = 1
  AND (t1.gfc_generationunit_id IN (SELECT power_powerunit_info.unit_id
                                    FROM im.power_powerunit_info
                                    WHERE power_powerunit_info.generation_id = 18));

alter table v_available_npp_capacity
    owner to postgres;

