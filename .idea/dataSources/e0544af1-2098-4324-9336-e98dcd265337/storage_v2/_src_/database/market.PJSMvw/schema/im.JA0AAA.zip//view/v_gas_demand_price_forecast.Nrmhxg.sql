create view v_gas_demand_price_forecast
            ("Итерация", "Микросервис", "Рынок", "Индикатор", "Сценарий", "Код объекта", "Поряд.№ заявки",
             "Ранг заявки", "Время UTC", "Объём заявки", "Цена заявки", "Акцептованный объём заявки")
as
SELECT t.gdp_iteration    AS "Итерация",
       t.gdp_mcrsrvc      AS "Микросервис",
       t2.country_rus     AS "Рынок",
       t.gdp_indicator    AS "Индикатор",
       t.gdp_scenario     AS "Сценарий",
       t.gdp_object_id    AS "Код объекта",
       t.gdp_order_id     AS "Поряд.№ заявки",
       t.gdp_order_rank   AS "Ранг заявки",
       t.gdp_utc_datetime AS "Время UTC",
       t.gdp_val_1        AS "Объём заявки",
       t.gdp_val_2        AS "Цена заявки",
       t.gdp_val_8        AS "Акцептованный объём заявки"
FROM (SELECT rank()
             OVER (PARTITION BY im_gas_demand_price_forecast_calc.gdp_iteration, im_gas_demand_price_forecast_calc.gdp_mcrsrvc, im_gas_demand_price_forecast_calc.gdp_market, im_gas_demand_price_forecast_calc.gdp_indicator, im_gas_demand_price_forecast_calc.gdp_scenario, im_gas_demand_price_forecast_calc.gdp_object_id, im_gas_demand_price_forecast_calc.gdp_order_id, im_gas_demand_price_forecast_calc.gdp_order_rank ORDER BY im_gas_demand_price_forecast_calc.gdp_iteration DESC, im_gas_demand_price_forecast_calc.gdp_utc_datetime DESC) AS rn,
             im_gas_demand_price_forecast_calc.gdp_iteration,
             im_gas_demand_price_forecast_calc.gdp_mcrsrvc,
             im_gas_demand_price_forecast_calc.gdp_market,
             im_gas_demand_price_forecast_calc.gdp_indicator,
             im_gas_demand_price_forecast_calc.gdp_scenario,
             im_gas_demand_price_forecast_calc.gdp_object_id,
             im_gas_demand_price_forecast_calc.gdp_order_id,
             im_gas_demand_price_forecast_calc.gdp_order_rank,
             im_gas_demand_price_forecast_calc.gdp_utc_datetime,
             im_gas_demand_price_forecast_calc.gdp_val_1,
             im_gas_demand_price_forecast_calc.gdp_val_2,
             im_gas_demand_price_forecast_calc.gdp_val_8
      FROM im.im_gas_demand_price_forecast_calc) t
         LEFT JOIN im.im_market_country t1 ON t.gdp_market = t1.m_id AND t1.m_commodity = 2
         LEFT JOIN countries t2 ON t1.m_country = t2.id
WHERE t.rn = 1;

alter table v_gas_demand_price_forecast
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_gas_demand_price_forecast to quicksight;

