create view v_power_market_map
            (num, "Дата", "ЕДРОУП продавца", "Продавец", "Группа продавца", "Сегмент продавца", "Тип бизнеса продавца",
             "Статус продавца", "ЕДРОУП покупателя", "Покупатель", "Группа покупателя", "Сегмент покупателя",
             "Тип бизнеса покупателя", "Статус покупателя", "Трейдер", "Тип продукта", "Размер контрагента",
             "Число сделок за месяц", "Общее количество", "Общий объём", "Средневзвешенная цена")
as
SELECT row_number() OVER ()                 AS num,
       t.mpi_md_id                          AS "Дата",
       t2.mc_inn                            AS "ЕДРОУП продавца",
       t2.mc_name                           AS "Продавец",
       t3.description                       AS "Группа продавца",
       t4.description                       AS "Сегмент продавца",
       t5.description                       AS "Тип бизнеса продавца",
       t6.description                       AS "Статус продавца",
       t7.mc_inn                            AS "ЕДРОУП покупателя",
       t7.mc_name                           AS "Покупатель",
       t8.description                       AS "Группа покупателя",
       t9.description                       AS "Сегмент покупателя",
       t10.description                      AS "Тип бизнеса покупателя",
       t11.description                      AS "Статус покупателя",
       COALESCE(t.byuer_seller, 'no'::text) AS "Трейдер",
       t13.mp_type                          AS "Тип продукта",
       CASE
           WHEN t.agent_size = 1 THEN 'крупный'::text
           ELSE 'средний'::text
           END                              AS "Размер контрагента",
       t.n                                  AS "Число сделок за месяц",
       t.tot_qty                            AS "Общее количество",
       t.tot_vol                            AS "Общий объём",
       t.avg_w_price                        AS "Средневзвешенная цена"
FROM (SELECT t1.mpi_md_id,
             t1.mpi_seller_id,
             t1.mpi_buyer_id,
             t1.mpi_mp_id,
             t14.agent_size,
             t12.byuer_seller,
             count(*)                                       AS n,
             sum(t1.mpi_qty)                                AS tot_qty,
             sum(t1.mpi_volume)                             AS tot_vol,
             round(sum(t1.mpi_volume) / sum(t1.mpi_qty), 2) AS avg_w_price
      FROM market_product_info t1
               LEFT JOIN v_market_grouping_by_seller_buyer t14
                         ON t1.mpi_seller_id = t14.mpi_seller_id AND t1.mpi_buyer_id = t14.mpi_buyer_id AND
                            t1.mpi_md_id = t14.mpi_md_id
               LEFT JOIN v_market_checking_duplicates t12
                         ON t1.mpi_buyer_id = t12.countragent AND t1.mpi_md_id = t12.date
      GROUP BY t1.mpi_mp_id, t1.mpi_md_id, t1.mpi_seller_id, t1.mpi_buyer_id, t14.agent_size, t12.byuer_seller) t
         LEFT JOIN market_counterparty t2 ON t.mpi_seller_id = t2.mc_id
         LEFT JOIN market_category t3 ON t2.group_ua = t3.id
         LEFT JOIN market_category t4 ON t2.segment_region_ee = t4.id
         LEFT JOIN market_category t5 ON t2.type_of_business_ee = t5.id
         LEFT JOIN market_category t6 ON t2.cp_status_ee = t6.id
         LEFT JOIN market_counterparty t7 ON t.mpi_buyer_id = t7.mc_id
         LEFT JOIN market_category t8 ON t7.group_ua = t8.id
         LEFT JOIN market_category t9 ON t7.segment_region_ee = t9.id
         LEFT JOIN market_category t10 ON t7.type_of_business_ee = t10.id
         LEFT JOIN market_category t11 ON t7.cp_status_ee = t11.id
         LEFT JOIN market_product t13 ON t.mpi_mp_id = t13.mp_id;

alter table v_power_market_map
    owner to postgres;

