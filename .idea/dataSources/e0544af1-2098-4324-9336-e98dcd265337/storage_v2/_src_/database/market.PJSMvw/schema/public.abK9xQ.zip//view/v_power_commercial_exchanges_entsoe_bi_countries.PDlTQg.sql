create view v_power_commercial_exchanges_entsoe_bi_countries
            ("Период", "Дата", "Час", "Торговая зона", "Импорт/экспорт", "МВтч", country_to, country_from, is_import,
             "Страна") as
SELECT t.date_time                                                     AS "Период",
       "left"(to_char(t.date_time, 'YYYY-MM-DD HH24:MI:SS'::text), 10) AS "Дата",
       "right"(to_char(t.date_time, 'YYYY-MM-DD HH24:MI:SS'::text), 8) AS "Час",
       t.zone_to                                                       AS "Торговая зона",
       t.zone_from                                                     AS "Импорт/экспорт",
       t.value                                                         AS "МВтч",
       t.country_to,
       t.country_from,
       t.is_import,
       c.country_rus                                                   AS "Страна"
FROM power_commercial_exchanges_entsoe_bi_trash t
         LEFT JOIN countries c ON t.country_to::text = c.iso_code::text;

alter table v_power_commercial_exchanges_entsoe_bi_countries
    owner to postgres;

