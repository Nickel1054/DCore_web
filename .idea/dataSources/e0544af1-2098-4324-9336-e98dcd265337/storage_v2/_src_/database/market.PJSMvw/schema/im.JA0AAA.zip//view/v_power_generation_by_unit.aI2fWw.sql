create view v_power_generation_by_unit
            (num, "Итерация", "Сценарий", "Дата-время UTC", "Рынок", "ID энергоблока", "Индикатор",
             "Доступная генерация в МВт", "Ген + ремонты МВт", "Ген + климат огранич МВт")
as
SELECT row_number() OVER ()    AS num,
       t.gfc_iteration         AS "Итерация",
       t.gfc_scenario          AS "Сценарий",
       t.gfc_utc_datetime      AS "Дата-время UTC",
       t.gfc_market_id         AS "Рынок",
       t.gfc_generationunit_id AS "ID энергоблока",
       t.gfc_indicator_id      AS "Индикатор",
       t.gfc_val_1             AS "Доступная генерация в МВт",
       t.gfc_val_2             AS "Ген + ремонты МВт",
       t.gfc_val_3             AS "Ген + климат огранич МВт"
FROM (SELECT rank()
             OVER (PARTITION BY t1.gfc_iteration, t1.gfc_scenario, t1.gfc_generationunit_id ORDER BY t1.gfc_iteration DESC, t1.gfc_utc_datetime DESC) AS rn,
             t1.gfc_iteration,
             t1.gfc_scenario,
             t1.gfc_utc_datetime,
             t1.gfc_market_id,
             t1.gfc_generationunit_id,
             t1.gfc_indicator_id,
             t1.gfc_val_1,
             t1.gfc_val_2,
             t1.gfc_val_3
      FROM im.im_generationunit_forecast_calc t1
      WHERE t1.gfc_indicator_id = 15
        AND t1.gfc_id > ((SELECT im_system_variables.max_iter - 5
                          FROM im.im_system_variables))) t
WHERE t.rn = 1;

alter table v_power_generation_by_unit
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_power_generation_by_unit to quicksight;

