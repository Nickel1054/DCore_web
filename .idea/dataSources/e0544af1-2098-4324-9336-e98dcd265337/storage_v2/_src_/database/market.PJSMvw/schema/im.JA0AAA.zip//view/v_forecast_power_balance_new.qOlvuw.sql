create view v_forecast_power_balance_new
            ("Итерация", "Сценарий", "Местное время", "Время UTC", "Страна", "Индикатор", "Значение 1", "Значение 2") as
SELECT t.mfc_iteration      AS "Итерация",
       t.scenario_name_ru   AS "Сценарий",
       t.mfc_datetime_local AS "Местное время",
       t.mfc_datetime_utc   AS "Время UTC",
       t.country_rus        AS "Страна",
       t.ind_name_ru        AS "Индикатор",
       t.mfc_val_1          AS "Значение 1",
       t.mfc_val_2          AS "Значение 2"
FROM (SELECT rank()
             OVER (PARTITION BY t1.mfc_iteration, t1.mfc_market_id, t1.mfc_scenario ORDER BY t1.mfc_iteration DESC, t1.mfc_datetime_utc DESC) AS rn,
             t1.mfc_iteration,
             t2.scenario_name_ru,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t4.country_rus,
             t5.ind_name_ru,
             t1.mfc_val_1,
             t1.mfc_val_2
      FROM im.im_markets_forecast_calc t1
               LEFT JOIN im.im_scenario t2 ON t1.mfc_scenario = t2.scenario_id
               LEFT JOIN im.im_market_country t3 ON t1.mfc_market_id = t3.m_id
               LEFT JOIN countries t4 ON t3.m_country = t4.id
               LEFT JOIN im.im_indicator t5 ON t1.mfc_indicator_id = t5.ind_id
      WHERE (t1.mfc_indicator_id = ANY (ARRAY [8, 9, 11, 12, 13, 17]))
        AND t1.mfc_iteration >= 200) t
WHERE t.rn = 1;

alter table v_forecast_power_balance_new
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_forecast_power_balance_new to quicksight;

