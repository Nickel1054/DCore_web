create view v_gas_pipeline_maintenance
            ("N", "Интерконнектор", "Название", "Ремонт", "Мощность", "Прогнозная дата", "Дата начала",
             "Дата окончания", "Работающий", "Источник", "Примечание")
as
SELECT t1.gm_id                                    AS "N",
       t2.name                                     AS "Интерконнектор",
       t1.p_name                                   AS "Название",
       t1.gm_category                              AS "Ремонт",
       t1.gm_impact_value_mwy                      AS "Мощность",
       t1.gm_forecast_date                         AS "Прогнозная дата",
       t1.gm_start_date                            AS "Дата начала",
       t1.gm_end_date                              AS "Дата окончания",
       t1.is_working                               AS "Работающий",
       t1.gm_source                                AS "Источник",
       COALESCE(t1.gm_note, ''::character varying) AS "Примечание"
FROM im.gas_pipeline_maintenance_info t1
         LEFT JOIN im.gas_interconn_info t2 ON t1.gm_gaspoint_id = t2.id;

alter table v_gas_pipeline_maintenance
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_gas_pipeline_maintenance to quicksight;

