create view v_volue_iterations_ec00ens
            ("Date time CET", "Commodity", "Zone", "Last value", "Prev value", "Difference [MWh]", "Difference [%]") as
SELECT t.date_time                                                               AS "Date time CET",
       t.commodity                                                               AS "Commodity",
       t.zone                                                                    AS "Zone",
       t.value_last                                                              AS "Last value",
       t.value_prev                                                              AS "Prev value",
       t.value_last - t.value_prev                                               AS "Difference [MWh]",
       (t.value_last - t.value_prev) / NULLIF(t.value_prev, 0::double precision) AS "Difference [%]"
FROM (SELECT t1.date_time,
             t1.commodity,
             t1.zone,
             max(
                     CASE
                         WHEN t1.rn = 1 THEN t1.value::double precision
                         ELSE NULL::double precision
                         END) AS value_last,
             max(
                     CASE
                         WHEN t1.rn = 2 THEN t1.value::double precision
                         ELSE NULL::double precision
                         END) AS value_prev
      FROM (SELECT volue_forecast_phys_ec00ens_iterations.iteration,
                   timezone('Europe/Rome'::text,
                            timezone('utc'::text, volue_forecast_phys_ec00ens_iterations.date_time))                                                                            AS date_time,
                   vc.commodity,
                   vfpz.zone,
                   volue_forecast_phys_ec00ens_iterations.value,
                   row_number()
                   OVER (PARTITION BY vc.commodity, vfpz.zone, volue_forecast_phys_ec00ens_iterations.date_time ORDER BY volue_forecast_phys_ec00ens_iterations.iteration DESC) AS rn
            FROM volue_forecast_phys_ec00ens_iterations
                     LEFT JOIN volue_commodities vc ON vc.id = volue_forecast_phys_ec00ens_iterations.commodity
                     LEFT JOIN volue_forecast_phys_zones vfpz ON volue_forecast_phys_ec00ens_iterations.zone = vfpz.id
                     LEFT JOIN volue_last_iterations vli ON volue_forecast_phys_ec00ens_iterations.iteration = vli.id
            WHERE volue_forecast_phys_ec00ens_iterations.iteration <> 0
            ORDER BY (row_number()
                      OVER (PARTITION BY vc.commodity, vfpz.zone, volue_forecast_phys_ec00ens_iterations.date_time ORDER BY volue_forecast_phys_ec00ens_iterations.iteration DESC))) t1
      WHERE t1.iteration <> 0
        AND t1.rn <= 2
        AND t1.date_time <= (now() + '1 year'::interval)
        AND t1.date_time >= (now() - '3 days'::interval)::date
      GROUP BY t1.date_time, t1.commodity, t1.zone) t;

alter table v_volue_iterations_ec00ens
    owner to postgres;

