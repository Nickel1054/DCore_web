create view v_power_import_export
            ("Итерация", "Микросервис", "Тип", "Из страны", "В страну", "Индикатор", "Сценарий", "Значение 1",
             "Значение 2", "Значение 3", "Значение 4", "Значение 5", "Значение 6", "Значение 7", "Значение 8",
             "Время UTC")
as
SELECT t.eif_iteration     AS "Итерация",
       t.eif_mcrsrvc       AS "Микросервис",
       t.eif_type          AS "Тип",
       t3.country_rus      AS "Из страны",
       t4.country_rus      AS "В страну",
       t6.ind_name_ru      AS "Индикатор",
       t5.scenario_name_ru AS "Сценарий",
       t.eif_val_1         AS "Значение 1",
       t.eif_val_2         AS "Значение 2",
       t.eif_val_3         AS "Значение 3",
       t.eif_val_4         AS "Значение 4",
       t.eif_val_5         AS "Значение 5",
       t.eif_val_6         AS "Значение 6",
       t.eif_val_7         AS "Значение 7",
       t.eif_val_8         AS "Значение 8",
       t.eif_utc_datetime  AS "Время UTC"
FROM (SELECT rank()
             OVER (PARTITION BY im_electr_impex_forecast_calc.eif_iteration, im_electr_impex_forecast_calc.eif_mcrsrvc, im_electr_impex_forecast_calc.eif_indicator, im_electr_impex_forecast_calc.eif_scenario, im_electr_impex_forecast_calc.eif_src, im_electr_impex_forecast_calc.eif_dst ORDER BY im_electr_impex_forecast_calc.eif_iteration DESC, im_electr_impex_forecast_calc.eif_utc_datetime DESC) AS rn,
             im_electr_impex_forecast_calc.eif_iteration,
             im_electr_impex_forecast_calc.eif_mcrsrvc,
             im_electr_impex_forecast_calc.eif_type,
             im_electr_impex_forecast_calc.eif_src,
             im_electr_impex_forecast_calc.eif_dst,
             im_electr_impex_forecast_calc.eif_indicator,
             im_electr_impex_forecast_calc.eif_scenario,
             im_electr_impex_forecast_calc.eif_val_1,
             im_electr_impex_forecast_calc.eif_val_2,
             im_electr_impex_forecast_calc.eif_val_3,
             im_electr_impex_forecast_calc.eif_val_4,
             im_electr_impex_forecast_calc.eif_val_5,
             im_electr_impex_forecast_calc.eif_val_6,
             im_electr_impex_forecast_calc.eif_val_7,
             im_electr_impex_forecast_calc.eif_val_8,
             im_electr_impex_forecast_calc.eif_utc_datetime
      FROM im.im_electr_impex_forecast_calc) t
         LEFT JOIN im.im_market_country t1 ON t.eif_src = t1.m_id AND t1.m_commodity = 1
         LEFT JOIN im.im_market_country t2 ON t.eif_dst = t2.m_id AND t2.m_commodity = 1
         LEFT JOIN countries t3 ON t1.m_country = t3.id
         LEFT JOIN countries t4 ON t2.m_country = t4.id
         LEFT JOIN im.im_scenario t5 ON t.eif_scenario = t5.scenario_id
         LEFT JOIN im.im_indicator t6 ON t.eif_indicator = t6.ind_id
WHERE t.rn = 1;

alter table v_power_import_export
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_power_import_export to quicksight;

