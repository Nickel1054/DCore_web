create view tables(relid, nspname, relname, set_name) as
WITH set_relations AS (SELECT s.set_name,
                              r.set_reloid
                       FROM pglogical.replication_set_table r,
                            pglogical.replication_set s,
                            pglogical.local_node n
                       WHERE s.set_nodeid = n.node_id
                         AND s.set_id = r.set_id),
     user_tables AS (SELECT r.oid,
                            n.nspname,
                            r.relname,
                            r.relreplident
                     FROM pg_class r,
                          pg_namespace n
                     WHERE r.relkind = 'r'::"char"
                       AND r.relpersistence = 'p'::"char"
                       AND n.oid = r.relnamespace
                       AND n.nspname !~ '^pg_'::text
                       AND n.nspname <> 'information_schema'::name
                       AND n.nspname <> 'pglogical'::name)
SELECT r.oid AS relid,
       n.nspname,
       r.relname,
       s.set_name
FROM pg_namespace n,
     pg_class r,
     set_relations s
WHERE r.relkind = 'r'::"char"
  AND n.oid = r.relnamespace
  AND r.oid = s.set_reloid::oid
UNION
SELECT t.oid      AS relid,
       t.nspname,
       t.relname,
       NULL::name AS set_name
FROM user_tables t
WHERE NOT (t.oid IN (SELECT set_relations.set_reloid
                     FROM set_relations));

alter table tables
    owner to rds_superuser;

