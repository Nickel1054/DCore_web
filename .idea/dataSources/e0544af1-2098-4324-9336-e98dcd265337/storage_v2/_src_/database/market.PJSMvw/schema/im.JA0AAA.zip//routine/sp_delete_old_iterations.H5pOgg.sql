create procedure sp_delete_old_iterations()
    language plpgsql
as
$$
DECLARE
    iter_id BIGINT;
BEGIN
    -- Delete old iterations from im.im_generationunit_forecast_calc
    DELETE FROM im.im_generationunit_forecast_calc
    WHERE gfc_iteration < (SELECT max_iter - 8 FROM im.im_system_variables);

    -- Delete old iterations from im.im_markets_forecast_calc
    DELETE FROM im.im_markets_forecast_calc
    WHERE mfc_iteration < (SELECT max_iter - 8 FROM im.im_system_variables);

    -- Delete old iterations from im.im_electr_demand_price_forecast_calc
    DELETE FROM im.im_electr_demand_price_forecast_calc
    WHERE edp_iteration < (SELECT max_iter - 8 FROM im.im_system_variables);

    -- Delete old iterations from im.im_gas_demand_price_forecast_calc
    DELETE FROM im.im_gas_demand_price_forecast_calc
    WHERE gdp_iteration < (SELECT max_iter - 8 FROM im.im_system_variables);

    -- Delete old iterations from im.im_electr_impex_forecast_calc
    DELETE FROM im.im_electr_impex_forecast_calc
    WHERE eif_iteration < (SELECT max_iter - 8 FROM im.im_system_variables);

    COMMIT;
END
$$;

alter procedure sp_delete_old_iterations() owner to postgres;

