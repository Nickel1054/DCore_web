create function is_new_station() returns boolean
    language plpgsql
as
$$
declare
    res BOOLEAN;
BEGIN
    SELECT EXISTS(
                    SELECT DISTINCT powerstation, powerstation_eic_code
                    FROM power_powerunits_directory_new_info
                    EXCEPT
                    SELECT DISTINCT s_name, s_eic_code
                    FROM power_station_info
                 ) INTO res;
    RETURN res;
END;
$$;

alter function is_new_station() owner to postgres;

