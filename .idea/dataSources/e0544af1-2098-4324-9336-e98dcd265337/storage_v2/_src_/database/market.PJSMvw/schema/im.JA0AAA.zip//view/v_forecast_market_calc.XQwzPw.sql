create view v_forecast_market_calc
            (mfc_iteration, mfc_market_id, mfc_microservice_id, mfc_indicator_id, mfc_scenario, mfc_datetime_utc) as
SELECT t.mfc_iteration,
       t.mfc_market_id,
       t.mfc_microservice_id,
       t.mfc_indicator_id,
       t.mfc_scenario,
       t.mfc_datetime_utc
FROM (SELECT rank()
             OVER (PARTITION BY im_markets_forecast_calc.mfc_iteration, im_markets_forecast_calc.mfc_microservice_id, im_markets_forecast_calc.mfc_market_id, im_markets_forecast_calc.mfc_indicator_id ORDER BY im_markets_forecast_calc.mfc_iteration DESC, im_markets_forecast_calc.mfc_datetime_utc DESC) AS rn,
             im_markets_forecast_calc.mfc_iteration,
             im_markets_forecast_calc.mfc_market_id,
             im_markets_forecast_calc.mfc_microservice_id,
             im_markets_forecast_calc.mfc_indicator_id,
             im_markets_forecast_calc.mfc_datetime_utc,
             im_markets_forecast_calc.mfc_scenario
      FROM im.im_markets_forecast_calc) t
WHERE t.rn = 1;

alter table v_forecast_market_calc
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_forecast_market_calc to quicksight;

