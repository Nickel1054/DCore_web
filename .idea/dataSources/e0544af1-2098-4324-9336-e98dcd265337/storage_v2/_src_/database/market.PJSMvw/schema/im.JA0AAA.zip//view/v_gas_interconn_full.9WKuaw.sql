create view v_gas_interconn_full
            ("ID", "Интерконнектор", "Статус", "Направление", "Из страны", "В страну", "Оператор",
             "Уникальный оператор", "Макс проп способность МВтч в день", "Примечание", "Дата начала", "Дата окончания",
             "Сценарий", "Пропускная способность МВтч в ден")
as
SELECT t1.id               AS "ID",
       t1.name             AS "Интерконнектор",
       t3.status           AS "Статус",
       t1.direction        AS "Направление",
       t4.country_rus      AS "Из страны",
       t5.country_rus      AS "В страну",
       t1.operator         AS "Оператор",
       t1.unique_operator  AS "Уникальный оператор",
       t1.max_capacity     AS "Макс проп способность МВтч в день",
       t1.comments         AS "Примечание",
       t2.start_date       AS "Дата начала",
       t2.end_date         AS "Дата окончания",
       t6.scenario_name_ru AS "Сценарий",
       t2.capacity         AS "Пропускная способность МВтч в ден"
FROM im.gas_interconn_info t1
         LEFT JOIN im.gas_interconn_timeperiod t2 ON t1.id = t2.id_interconn
         LEFT JOIN im.gas_interconn_status t3 ON t1.status = t3.id
         LEFT JOIN countries t4 ON t1.country_from = t4.id
         LEFT JOIN countries t5 ON t1.country_to = t5.id
         LEFT JOIN im.im_scenario t6 ON t2.scenario = t6.scenario_id;

alter table v_gas_interconn_full
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_gas_interconn_full to quicksight;

