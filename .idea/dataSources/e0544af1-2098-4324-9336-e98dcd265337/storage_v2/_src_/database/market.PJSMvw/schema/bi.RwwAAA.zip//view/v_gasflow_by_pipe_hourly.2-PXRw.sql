create view v_gasflow_by_pipe_hourly("Поток", "Интерконнектор", "Дата-время", "Значение") as
SELECT t3.flow_name   AS "Поток",
       t2.point_label AS "Интерконнектор",
       t1.date_time   AS "Дата-время",
       t1.value       AS "Значение"
FROM entsog_flows_hourly_bi t1
         LEFT JOIN gaspointlabelentsog t2 ON t1.point_label = t2.id
         LEFT JOIN entsog_flows_names_ref t3 ON t1.flow_name_id = t3.id;

alter table v_gasflow_by_pipe_hourly
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_gasflow_by_pipe_hourly to quicksight;

