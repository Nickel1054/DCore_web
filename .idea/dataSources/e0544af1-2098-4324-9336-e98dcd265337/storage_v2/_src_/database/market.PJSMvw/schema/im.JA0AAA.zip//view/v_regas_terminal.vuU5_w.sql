create view v_regas_terminal
            ("Проект", "Страна", "Терминал", "Оператор", "Статус", "Тип", "Начало эксплуатации",
             "Мощность в млн.т в год", "Мощность в МВтч в день", "Мощность в млн. м3 в день",
             "Объём хранилища в млн. м3", "Доступ третьих сторон")
as
SELECT t1.rgp_name         AS "Проект",
       t2.country_rus      AS "Страна",
       t3.rgt_name         AS "Терминал",
       t4.rgt_name         AS "Оператор",
       t3.rgt_status       AS "Статус",
       t3.rgt_type         AS "Тип",
       t3.rgt_startup      AS "Начало эксплуатации",
       t3.rgt_losscap_mtpa AS "Мощность в млн.т в год",
       t3.rgt_losscap_mwhd AS "Мощность в МВтч в день",
       t3.rgt_losscap_mcmd AS "Мощность в млн. м3 в день",
       t3.rgt_storage_mcm  AS "Объём хранилища в млн. м3",
       t3.rgt_3pta         AS "Доступ третьих сторон"
FROM im.gas_rgt_project_info t1
         LEFT JOIN countries t2 ON t1.rgp_country = t2.id
         LEFT JOIN im.gas_rgt_terminal_info t3 ON t1.rgp_id = t3.rgt_project
         LEFT JOIN im.gas_rgt_operator_info t4 ON t3.operator_id = t4.rgt_oid;

alter table v_regas_terminal
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_regas_terminal to quicksight;

