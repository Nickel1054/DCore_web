create function is_outlier(eic character varying, date timestamp without time zone) returns boolean
    language plpgsql
as
$$
    BEGIN
        RETURN EXISTS(SELECT FROM power_tmp_outliers_summary
                      WHERE eic_code = eic
                      AND date BETWEEN min_dt AND max_dt);
    END;
$$;

alter function is_outlier(varchar, timestamp) owner to postgres;

