create view v_lng_ltc_contracts
            (id, "Страна экспортёр", "СПГ завод", "Статус", "Экспортёр", "Покупатель", "Страна импортёр",
             "Дата подписания", "Дата начала поставок", "Дата начала поставок по IHS", "Дата окончания поставок",
             "Тип контракта", "Условия поставки", "Фиксированная точка поставки", "Объём ММТра", "Объём ВСМ/а",
             "Объём MWh/d")
as
SELECT t1.ltc_id         AS id,
       t2.country_rus    AS "Страна экспортёр",
       t3.name           AS "СПГ завод",
       t1.status         AS "Статус",
       t4.cp_name        AS "Экспортёр",
       t5.cp_name        AS "Покупатель",
       t6.country_rus    AS "Страна импортёр",
       t1.sign_date      AS "Дата подписания",
       t1.start_date     AS "Дата начала поставок",
       t1.start_date_ihs AS "Дата начала поставок по IHS",
       t1.end_date       AS "Дата окончания поставок",
       t1.contract_type  AS "Тип контракта",
       t1.terms          AS "Условия поставки",
       t1.dest_flex      AS "Фиксированная точка поставки",
       t1.volume_mmtpa   AS "Объём ММТра",
       t1.volume_bcma    AS "Объём ВСМ/а",
       t1.volume_mwhd    AS "Объём MWh/d"
FROM im.gas_lng_ltc_contracts t1
         LEFT JOIN countries t2 ON t1.country_exporter = t2.id
         LEFT JOIN im.gas_lng_plants_projects t3 ON t1.lng_plant = t3.id
         LEFT JOIN im.gas_counterparty_info t4 ON t1.exporter = t4.cp_id
         LEFT JOIN im.gas_counterparty_info t5 ON t1.buyer = t5.cp_id
         LEFT JOIN countries t6 ON t1.country_importer = t6.id;

alter table v_lng_ltc_contracts
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_lng_ltc_contracts to quicksight;

