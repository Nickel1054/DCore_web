create view v_market_checking_duplicates(countragent, date, byuer_seller) as
SELECT DISTINCT t1.mpi_seller_id AS countragent,
                t1.mpi_md_id     AS date,
                'yes'::text      AS byuer_seller
FROM market_product_info t1
         JOIN (SELECT DISTINCT t1_1.mpi_buyer_id,
                               t1_1.mpi_md_id
               FROM market_product_info t1_1) t2 ON t1.mpi_seller_id = t2.mpi_buyer_id AND t1.mpi_md_id = t2.mpi_md_id;

alter table v_market_checking_duplicates
    owner to postgres;

