create function is_new_generation_fuel() returns boolean
    language plpgsql
as
$$
declare
    res BOOLEAN;
BEGIN
    SELECT EXISTS(
                    SELECT DISTINCT  generation_type, fuel_type
                    FROM power_powerunits_directory_new_info
                    EXCEPT (
                                SELECT t2.g_type, t3.f_type
                                FROM power_generation_fuel_info t1
                                LEFT JOIN power_generation_info t2 ON t1.gf_g_id = t2.g_id
                                LEFT JOIN power_fuel_info t3 ON t1.gf_f_id = t3.f_id
                            )
                 ) INTO res;
    RETURN res;
END;
$$;

alter function is_new_generation_fuel() owner to postgres;

