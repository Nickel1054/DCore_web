create procedure sp_insert_new_power_fuel()
    language sql
as
$$
    INSERT INTO power_fuel_info(f_type)
    (SELECT DISTINCT fuel_type
     FROM power_powerunits_directory_new_info
     EXCEPT
          (
              SELECT f_type FROM power_fuel_info
          )
    );
$$;

alter procedure sp_insert_new_power_fuel() owner to postgres;

