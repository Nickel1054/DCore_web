create view v_gasinstorage_forecast
            ("Итерация", "Сценарий", "Дата-время UTC", "Рынок", "ID ПХГ", "Запасы", "Закачка", "Выкачка") as
SELECT t.gsf_iteration    AS "Итерация",
       t.gsf_scenario     AS "Сценарий",
       t.gsf_utc_datetime AS "Дата-время UTC",
       t.gsf_market_id    AS "Рынок",
       t.gsf_ugsid_id     AS "ID ПХГ",
       t.gsf_val_1        AS "Запасы",
       t.gsf_val_3        AS "Закачка",
       t.gsf_val_4        AS "Выкачка"
FROM im.im_gasinstorage_forecast_calc t
WHERE t.gsf_scenario = ANY (ARRAY [1, 2, 3]);

alter table v_gasinstorage_forecast
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_gasinstorage_forecast to quicksight;

