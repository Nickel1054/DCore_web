create procedure sp_insert_new_power_generation()
    language sql
as
$$
    INSERT INTO power_generation_info(g_type)
    (SELECT DISTINCT generation_type
     FROM power_powerunits_directory_new_info
     EXCEPT
          (
              SELECT g_type FROM power_generation_info
          )
    );
$$;

alter procedure sp_insert_new_power_generation() owner to postgres;

