create function get_max_timestamp_no_outlier(eic character varying, dtstmp timestamp without time zone) returns timestamp without time zone
    language plpgsql
as
$$
    DECLARE
        new_max_dt TIMESTAMP;
        n_out SMALLINT;
        dd INTERVAL;
        hh INTERVAL;

    BEGIN
        SELECT daily_num_outliers INTO n_out
        FROM power_tmp_outliers_summary
        WHERE eic_code = eic AND dt=dtstmp::DATE;

        new_max_dt = dtstmp;

        IF n_out<24 THEN SELECT make_interval(hours => n_out) INTO hh;
                    ELSE SELECT make_interval(days => 1) INTO dd;
        END IF;

        IF n_out<24 THEN BEGIN
                            WHILE is_outlier(eic, new_max_dt) LOOP
                                new_max_dt = new_max_dt + hh;
                            END LOOP;
                          END;
        ELSE BEGIN
                WHILE is_outlier(eic, new_max_dt) LOOP
                        new_max_dt = new_max_dt + dd;
                END LOOP;
             END;
        END IF;
        RETURN new_max_dt;
    END;
$$;

alter function get_max_timestamp_no_outlier(varchar, timestamp) owner to postgres;

