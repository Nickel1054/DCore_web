create view v_power_futures_sftp_bi
            ("Id", "Trading date", "Delivery start date", "Delivery end date", "Open price", "High price", "Low price",
             "Last price", "Settlement price", "Lot size", "Traded lots", "Trades number", "Traded volume",
             "Open interest lots", "Open interest volume", "Delivery year", "Delivery date", "Product description",
             "Delivery period", "Zone", "Load type", "Delivery month", "Product type", "Continuation name")
as
SELECT row_number() OVER ()              AS "Id",
       pfsb.trading_date                 AS "Trading date",
       pfsb.delivery_start_date          AS "Delivery start date",
       pfsb.delivery_end_date            AS "Delivery end date",
       pfsb.open_price                   AS "Open price",
       pfsb.high_price                   AS "High price",
       pfsb.low_price                    AS "Low price",
       pfsb.last_price                   AS "Last price",
       pfsb.settlement_price             AS "Settlement price",
       pfsb.lot_size                     AS "Lot size",
       pfsb.traded_lots                  AS "Traded lots",
       pfsb.number_of_trades             AS "Trades number",
       pfsb.traded_volume                AS "Traded volume",
       pfsb.open_interest_lots           AS "Open interest lots",
       pfsb.open_interest_volume         AS "Open interest volume",
       pfsb.delivery_year                AS "Delivery year",
       pfsb.day_product_delivery         AS "Delivery date",
       spdfnr.product_delivery_full_name AS "Product description",
       spdnr.product_delivery_name       AS "Delivery period",
       szr.zone                          AS "Zone",
       sltr.load_type                    AS "Load type",
       m.month_name_eng                  AS "Delivery month",
       sptr.product_type                 AS "Product type",
       sspnr.short_prod_name             AS "Continuation name"
FROM power_futures_sftp_bi pfsb
         LEFT JOIN sftp_product_code_ref spcr ON spcr.id = pfsb.product_code
         LEFT JOIN sftp_product_delivery_full_name_ref spdfnr ON pfsb.product_delivery_full_name = spdfnr.id
         LEFT JOIN sftp_product_delivery_name_ref spdnr ON pfsb.product_delivery_name = spdnr.id
         LEFT JOIN sftp_product_full_name_ref spfnr ON pfsb.product_full_name = spfnr.id
         LEFT JOIN sftp_zone_ref szr ON pfsb.zone = szr.id
         LEFT JOIN sftp_load_type_ref sltr ON pfsb.load_type = sltr.id
         LEFT JOIN bi.months m ON pfsb.delivery_month = m.month_num
         LEFT JOIN sftp_product_type_ref sptr ON pfsb.product_type = sptr.id
         LEFT JOIN sftp_short_prod_name_ref sspnr ON pfsb.short_prod_name = sspnr.id;

alter table v_power_futures_sftp_bi
    owner to postgres;

