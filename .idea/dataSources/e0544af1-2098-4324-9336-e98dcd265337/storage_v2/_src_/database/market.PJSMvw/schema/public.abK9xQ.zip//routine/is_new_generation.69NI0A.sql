create function is_new_generation() returns boolean
    language plpgsql
as
$$
declare
    res BOOLEAN;
BEGIN
    SELECT EXISTS(
                    SELECT DISTINCT generation_type
                    FROM power_powerunits_directory_new_info
                    EXCEPT
                    SELECT g_type
                    FROM power_generation_info
                 ) INTO res;
    RETURN res;
END;
$$;

alter function is_new_generation() owner to postgres;

