create function f_add_table_pk() returns void
    language plpgsql
as
$$
DECLARE
    st TEXT;
BEGIN
    FOR st IN
        /*
        SELECT format('ALTER TABLE %I.%I SET SCHEMA %I',  t1.table_schema, t2.table_name, t2.new_schema)
        FROM information_schema.tables t1
        INNER JOIN table_owner_schema_mapping t2
        ON t1.table_name = t2.table_name
        WHERE t2.table_name LIKE 'power_%'
        */
        --============================================================================================================--
        select format('ALTER TABLE %I.%I ADD COLUMN new_id1 INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY', tab.table_schema, tab.table_name)
        from information_schema.tables tab
        left join information_schema.table_constraints tco
        on tab.table_schema = tco.table_schema
        and tab.table_name = tco.table_name
        and tco.constraint_type = 'PRIMARY KEY'
        where tab.table_type = 'BASE TABLE'
        and tab.table_schema not in ('pg_catalog', 'information_schema')
        and tco.constraint_name is null
        and tab.table_name NOT LIKE 'XT%'
    LOOP
        --RAISE NOTICE '%', st;
        EXECUTE st;
    END LOOP;
END;
$$;

alter function f_add_table_pk() owner to postgres;

