create view v_power_unavailability_transmission
            ("Тип ремонта", "Из страны", "В страну", "Дата начала", "Дата окончания", "Новое значение NTC",
             "Ед. измерения") as
SELECT t.business_type AS "Тип ремонта",
       t.country_from  AS "Из страны",
       t.country_to    AS "В страну",
       t.start_date    AS "Дата начала",
       t.end_date      AS "Дата окончания",
       t.quantity      AS "Новое значение NTC",
       t.quantity_uom  AS "Ед. измерения"
FROM power_unavailability_transmission t;

alter table v_power_unavailability_transmission
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_power_unavailability_transmission to quicksight;

