create procedure schedule_refresh_v_eq_available_capacity_diff()
    language plpgsql
as
$$
BEGIN
  PERFORM pg_schedule_cron('23 8 * * *', 'SELECT refresh_v_eq_available_capacity_diff();');
END;
$$;

alter procedure schedule_refresh_v_eq_available_capacity_diff() owner to postgres;

