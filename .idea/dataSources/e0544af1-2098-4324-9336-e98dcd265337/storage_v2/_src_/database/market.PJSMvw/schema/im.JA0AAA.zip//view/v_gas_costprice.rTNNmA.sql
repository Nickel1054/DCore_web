create view v_gas_costprice (num, "Итерация", "Рынок", "Сценарий", "Равновесная цена газа", "Дата время UTC") as
SELECT row_number() OVER () AS num,
       t1.mfc_iteration     AS "Итерация",
       t3.country_rus       AS "Рынок",
       t4.scenario_name_ru  AS "Сценарий",
       t1.mfc_val_1         AS "Равновесная цена газа",
       t1.mfc_datetime_utc  AS "Дата время UTC"
FROM im.im_markets_forecast_calc t1
         LEFT JOIN im.im_market_country t2 ON t1.mfc_market_id = t2.m_id AND t2.m_commodity = 2
         LEFT JOIN countries t3 ON t2.m_country = t3.id
         LEFT JOIN im.im_scenario t4 ON t1.mfc_scenario = t4.scenario_id
WHERE t1.mfc_indicator_id = 23
  AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 8
                           FROM im.im_system_variables));

alter table v_gas_costprice
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_gas_costprice to quicksight;

