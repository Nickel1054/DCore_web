create procedure sp_insert_new_power_country()
    language sql
as
$$
    INSERT INTO power_country_info(c_id, c_alpha2_code, c_name_en, c_name_ru, c_name_ua, c_eic_code)
    (SELECT DISTINCT t2.id, t1.country, t2.сountry_name, t2.сountry_rus, t2.country_ukr, t3.eic_code
     FROM power_powerunits_directory_new_info t1
     LEFT JOIN countries t2 ON t1.country = t2.iso_сode
     LEFT JOIN power_countries_entsoe t3 ON t1.country = t3.country_code
     EXCEPT
          (
              SELECT c_id, c_alpha2_code, c_name_en, c_name_ru, c_name_ua, c_eic_code FROM power_country_info
          )
    );
$$;

alter procedure sp_insert_new_power_country() owner to postgres;

