create view v_eua_futures_sftp_bi
            ("Trading Date", "Delivery Period", "Contract Volume", "Open Price", "High Price", "Low Price",
             "Last Price", "Settlement Price", "Exchange Volume", "Exchange Traded Contracts",
             "Exchange Number Of Trades", "TradeReg Volume", "TradeReg Traded Contracts", "TradeTeg Number Of Trades",
             "Open Interest Contracts", "Open Interest", "Delivery Month", "Delivery Year", "Delivery Period Name",
             "Emission Contract", "Product Delivery Full Name", "Index", "Continuation Name")
as
SELECT efsb.trading_date                                                      AS "Trading Date",
       efsb.delivery_period                                                   AS "Delivery Period",
       efsb.contract_volume                                                   AS "Contract Volume",
       efsb.open_price                                                        AS "Open Price",
       efsb.high_price                                                        AS "High Price",
       efsb.low_price                                                         AS "Low Price",
       efsb.last_price                                                        AS "Last Price",
       efsb.settlement_price                                                  AS "Settlement Price",
       efsb.exchange_volume                                                   AS "Exchange Volume",
       efsb.exchange_traded_contracts                                         AS "Exchange Traded Contracts",
       efsb.exchange_number_of_trades                                         AS "Exchange Number Of Trades",
       efsb.tradereg_volume                                                   AS "TradeReg Volume",
       efsb.tradereg_traded_contracts                                         AS "TradeReg Traded Contracts",
       efsb.tradereg_number_of_trades                                         AS "TradeTeg Number Of Trades",
       efsb.open_interest_contracts                                           AS "Open Interest Contracts",
       efsb.open_interest                                                     AS "Open Interest",
       to_char(efsb.delivery_period::timestamp with time zone, 'Month'::text) AS "Delivery Month",
       date_part('year'::text, efsb.delivery_period)                          AS "Delivery Year",
       sdpnr.delivery_period_name                                             AS "Delivery Period Name",
       secr.emission_contract                                                 AS "Emission Contract",
       spdfnr.product_delivery_full_name                                      AS "Product Delivery Full Name",
       spdfnr.index                                                           AS "Index",
       CASE
           WHEN date_part('month'::text, efsb.delivery_period) = 12::double precision THEN 'Y+'::text ||
                                                                                           date_part('year'::text, age(
                                                                                                   efsb.delivery_period::timestamp with time zone,
                                                                                                   date_trunc(
                                                                                                           'month'::text,
                                                                                                           efsb.trading_date::timestamp with time zone)))
           WHEN date_part('month'::text, efsb.delivery_period) = ANY
                (ARRAY [3::double precision, 6::double precision, 9::double precision]) THEN 'Q+'::text ||
                                                                                             ((date_part('year'::text, efsb.delivery_period) -
                                                                                               date_part('year'::text, efsb.trading_date)) *
                                                                                              4::double precision +
                                                                                              date_part('quarter'::text, efsb.delivery_period) -
                                                                                              date_part('quarter'::text, efsb.trading_date))
           ELSE 'M+'::text || (date_part('year'::text, age(efsb.delivery_period::timestamp with time zone,
                                                           date_trunc('month'::text,
                                                                      efsb.trading_date::timestamp with time zone))) *
                               12::double precision + date_part('month'::text,
                                                                age(efsb.delivery_period::timestamp with time zone,
                                                                    date_trunc('month'::text,
                                                                               efsb.trading_date::timestamp with time zone))))
           END                                                                AS "Continuation Name"
FROM eua_futures_sftp_bi efsb
         LEFT JOIN sftp_delivery_period_name_ref sdpnr ON sdpnr.id = efsb.delivery_period_name
         LEFT JOIN sftp_emission_contract_ref secr ON secr.id = efsb.emission_contract
         LEFT JOIN sftp_product_delivery_full_name_ref spdfnr ON spdfnr.id = efsb.product_delivery_full_name;

alter table v_eua_futures_sftp_bi
    owner to postgres;

