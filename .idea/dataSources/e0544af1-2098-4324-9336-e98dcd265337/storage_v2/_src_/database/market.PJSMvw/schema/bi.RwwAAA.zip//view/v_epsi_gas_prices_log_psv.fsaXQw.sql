create view v_epsi_gas_prices_log_psv
            (id, date_time, price_eur_mwh, product_delivery_full_name, product_type, short_prod_name, hub) as
SELECT epsi_gas_prices_log.id,
       epsi_gas_prices_log.date_time,
       epsi_gas_prices_log.price_eur_mwh,
       epsi_gas_prices_log.product_delivery_full_name,
       epsi_gas_prices_log.product_type,
       epsi_gas_prices_log.short_prod_name,
       epsi_gas_prices_log.hub
FROM epsi_gas_prices_log
WHERE epsi_gas_prices_log.hub = 'PSV'::text;

alter table v_epsi_gas_prices_log_psv
    owner to postgres;

