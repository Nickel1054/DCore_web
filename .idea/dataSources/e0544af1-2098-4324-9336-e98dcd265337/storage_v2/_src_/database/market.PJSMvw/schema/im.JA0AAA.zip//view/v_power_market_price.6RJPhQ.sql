create view v_power_market_price ("Итерация", "Рынок", "Сценарий", "Значение", "Дата-время UTC", "Локальное Время") as
SELECT im_markets_forecast_calc_tradezone.mfc_iteration      AS "Итерация",
       im_tradezone.tdz_name                                 AS "Рынок",
       im_markets_forecast_calc_tradezone.mfc_scenario       AS "Сценарий",
       im_markets_forecast_calc_tradezone.mfc_val_2          AS "Значение",
       im_markets_forecast_calc_tradezone.mfc_datetime_utc   AS "Дата-время UTC",
       im_markets_forecast_calc_tradezone.mfc_datetime_local AS "Локальное Время"
FROM im.im_markets_forecast_calc_tradezone
         LEFT JOIN im.im_tradezone ON im_markets_forecast_calc_tradezone.mfc_tradezone = im_tradezone.tdz_id
WHERE im_markets_forecast_calc_tradezone.mfc_microservice_id = 8
  AND im_markets_forecast_calc_tradezone.mfc_iteration > ((SELECT im_system_variables.max_iter - 8
                                                           FROM im.im_system_variables))
  AND im_markets_forecast_calc_tradezone.mfc_commodity_id = 1;

alter table v_power_market_price
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_power_market_price to quicksight;

