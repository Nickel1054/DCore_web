create view v_epsi_download_ptdf_flow_diff_mt
            ("Date Hour", "Interconnector", "Scenario Name", "Scenario Run Recent", "Scenario Run Previous", "Units",
             "PTDF Flow Recent", "PTDF Flow Previous", "PTDF Flow Difference Absolute", "PTDF Flow Difference Relative")
as
WITH joined_table AS (SELECT timezone('Europe/Amsterdam'::text, ptdf.date_time)            AS date_time,
                             interconnector.interconnector,
                             property.property_name,
                             scenario.scenario_id,
                             scenario_name.scenario_name,
                             timezone('Europe/Amsterdam'::text, scenario_run.scenario_run) AS scenario_run,
                             units.units,
                             ptdf.value,
                             timezone('Europe/Amsterdam'::text, iteration.iteration)       AS iteration,
                             forecast.forecast_period,
                             tft.timeframe_type
                      FROM epsi_download_ptdf_flow ptdf
                               LEFT JOIN epsi_download_interconnector interconnector
                                         ON ptdf.interconnector = interconnector.id
                               LEFT JOIN epsi_download_property_name property ON ptdf.property_name = property.id
                               LEFT JOIN epsi_download_scenario_id scenario ON ptdf.scenario_id = scenario.id
                               LEFT JOIN epsi_download_scenario_name scenario_name
                                         ON ptdf.scenario_name = scenario_name.id
                               LEFT JOIN epsi_download_scenario_run scenario_run ON ptdf.scenario_run = scenario_run.id
                               LEFT JOIN epsi_download_units units ON ptdf.units = units.id
                               LEFT JOIN epsi_download_iteration iteration ON ptdf.iteration = iteration.id
                               LEFT JOIN epsi_download_forecast_period forecast ON ptdf.forecast_period = forecast.id
                               LEFT JOIN epsi_download_timeframe_type tft ON ptdf.timeframe_type = tft.id
                      WHERE tft.timeframe_type = 'MT'::text),
     max_run AS (SELECT max(joined_table.scenario_run) AS msr
                 FROM joined_table)
SELECT e1.date_time        AS "Date Hour",
       e1.interconnector   AS "Interconnector",
       e1.scenario_name    AS "Scenario Name",
       e1.scenario_run     AS "Scenario Run Recent",
       e2.scenario_run     AS "Scenario Run Previous",
       e1.units            AS "Units",
       e1.value            AS "PTDF Flow Recent",
       e2.value            AS "PTDF Flow Previous",
       e1.value - e2.value AS "PTDF Flow Difference Absolute",
       CASE
           WHEN e2.value IS NULL OR e1.value IS NULL OR e2.value = 0::double precision THEN 0::double precision
           ELSE (e1.value - e2.value) / e2.value
           END             AS "PTDF Flow Difference Relative"
FROM joined_table e1
         JOIN joined_table e2 ON e1.date_time = e2.date_time AND e1.interconnector = e2.interconnector AND
                                 e1.scenario_name = e2.scenario_name AND e1.scenario_run > e2.scenario_run AND
                                 e1.units = e2.units
WHERE e1.scenario_run = ((SELECT max_run.msr
                          FROM max_run))
  AND e2.scenario_run = ((SELECT max(joined_table.scenario_run) AS mdsr
                          FROM joined_table
                          WHERE joined_table.scenario_run < ((SELECT max_run.msr
                                                              FROM max_run))));

alter table v_epsi_download_ptdf_flow_diff_mt
    owner to postgres;

