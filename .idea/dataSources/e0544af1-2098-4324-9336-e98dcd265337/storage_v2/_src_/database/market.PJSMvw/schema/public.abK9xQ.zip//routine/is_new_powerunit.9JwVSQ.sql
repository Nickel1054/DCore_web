create function is_new_powerunit() returns boolean
    language plpgsql
as
$$
declare
    res BOOLEAN;
BEGIN
    SELECT EXISTS(
                    SELECT DISTINCT powerunit, powerunit_eic_code
                    FROM power_powerunits_directory_new_info
                    EXCEPT(
                            SELECT DISTINCT p_name, p_eic_code
                            FROM power_powerunit_info
                          )
                 ) INTO res;
    RETURN res;
END;
$$;

alter function is_new_powerunit() owner to postgres;

