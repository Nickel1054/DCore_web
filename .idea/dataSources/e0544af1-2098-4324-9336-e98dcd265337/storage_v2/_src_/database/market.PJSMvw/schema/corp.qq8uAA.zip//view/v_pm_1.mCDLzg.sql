create view v_pm_1(mpi_md_id, mpi_seller_id, mpi_buyer_id, tot_qty, tot_vol, price, size) as
SELECT t1.mpi_md_id,
       t1.mpi_seller_id,
       t1.mpi_buyer_id,
       sum(t1.mpi_qty)                                AS tot_qty,
       sum(t1.mpi_volume)                             AS tot_vol,
       round(sum(t1.mpi_volume) / sum(t1.mpi_qty), 2) AS price,
       CASE
           WHEN (sum(t1.mpi_volume) / sum(t1.mpi_qty)) > 4500::numeric THEN 'крупный'::text
           ELSE 'средний'::text
           END                                        AS size
FROM market_product_info t1
GROUP BY t1.mpi_md_id, t1.mpi_seller_id, t1.mpi_buyer_id
HAVING sum(t1.mpi_qty) > 5::numeric;

alter table v_pm_1
    owner to postgres;

