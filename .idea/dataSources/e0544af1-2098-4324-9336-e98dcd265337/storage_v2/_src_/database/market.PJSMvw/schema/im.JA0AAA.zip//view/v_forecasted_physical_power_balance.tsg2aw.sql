create view v_forecasted_physical_power_balance("Итеррация", "Сценарий", "Рынок", indicator, value, "Дата-время UTC") as
SELECT t.mfc_iteration    AS "Итеррация",
       t.mfc_scenario     AS "Сценарий",
       t2.country_rus     AS "Рынок",
       t3.ind_name_ru     AS indicator,
       t.value,
       t.mfc_datetime_utc AS "Дата-время UTC"
FROM (SELECT im_markets_forecast_calc.mfc_iteration,
             im_markets_forecast_calc.mfc_scenario,
             im_markets_forecast_calc.mfc_market_id,
             im_markets_forecast_calc.mfc_indicator_id,
             im_markets_forecast_calc.mfc_val_8 AS value,
             im_markets_forecast_calc.mfc_datetime_utc
      FROM im.im_markets_forecast_calc
      WHERE im_markets_forecast_calc.mfc_commodity_id = 1
        AND (im_markets_forecast_calc.mfc_indicator_id = ANY
             (ARRAY [1, 2, 8, 9, 10, 11, 12, 13, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49]))
        AND im_markets_forecast_calc.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                                       FROM im.im_system_variables))
        AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY [1, 2, 3]))
        AND im_markets_forecast_calc.mfc_microservice_id = 7
      UNION ALL
      SELECT im_markets_forecast_calc.mfc_iteration,
             im_markets_forecast_calc.mfc_scenario,
             im_markets_forecast_calc.mfc_market_id,
             im_markets_forecast_calc.mfc_indicator_id,
             - im_markets_forecast_calc.mfc_val_1 AS value,
             im_markets_forecast_calc.mfc_datetime_utc
      FROM im.im_markets_forecast_calc
      WHERE im_markets_forecast_calc.mfc_commodity_id = 1
        AND im_markets_forecast_calc.mfc_indicator_id = 17
        AND im_markets_forecast_calc.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                                       FROM im.im_system_variables))
        AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY [1, 2, 3]))) t
         LEFT JOIN im.im_market_country t1 ON t.mfc_market_id = t1.m_id AND t1.m_commodity = 1
         LEFT JOIN countries t2 ON t1.m_country = t2.id
         LEFT JOIN im.im_indicator t3 ON t.mfc_indicator_id = t3.ind_id;

alter table v_forecasted_physical_power_balance
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_forecasted_physical_power_balance to quicksight;

