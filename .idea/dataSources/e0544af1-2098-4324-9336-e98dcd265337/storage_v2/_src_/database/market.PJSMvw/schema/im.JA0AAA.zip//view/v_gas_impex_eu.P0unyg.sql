create view v_gas_impex_eu (iteration, source, destination, scenario, import_export, mwh, src_datetime, dst_datetime) as
SELECT t1.gif_iteration        AS iteration,
       t4.country_rus          AS source,
       t6.country_rus          AS destination,
       t1.gif_scenario         AS scenario,
       CASE
           WHEN t1.gif_type::text = 'I'::text THEN 'Импорт'::text
           WHEN t1.gif_type::text = 'E'::text THEN 'Экспорт'::text
           ELSE NULL::text
           END                 AS import_export,
       CASE
           WHEN t1.gif_indicator = 27 THEN - t1.gif_val_1
           WHEN t1.gif_indicator = 26 THEN t1.gif_val_1
           ELSE NULL::double precision
           END                 AS mwh,
       t1.gif_utc_datetime_src AS src_datetime,
       t1.gif_utc_datetime_dst AS dst_datetime
FROM im.im_gas_impex_forecast_calc t1
         LEFT JOIN im.im_market_country t3 ON t1.gif_src = t3.m_id AND t3.m_commodity = 2
         LEFT JOIN countries t4 ON t3.m_country = t4.id
         LEFT JOIN im.im_market_country t5 ON t1.gif_dst = t5.m_id AND t5.m_commodity = 2
         LEFT JOIN countries t6 ON t5.m_country = t6.id
WHERE t1.gif_indicator = ANY (ARRAY [26, 27]);

alter table v_gas_impex_eu
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_gas_impex_eu to quicksight;

