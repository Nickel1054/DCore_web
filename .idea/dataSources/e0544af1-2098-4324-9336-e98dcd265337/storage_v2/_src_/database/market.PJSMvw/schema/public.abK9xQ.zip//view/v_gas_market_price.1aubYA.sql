create view v_gas_market_price(iteration, scenario, market, mfc_val_1, mfc_val_2, mfc_date) as
SELECT t1.mfc_iteration AS iteration,
       t1.mfc_scenario  AS scenario,
       t3.country_rus   AS market,
       t1.mfc_val_1,
       t1.mfc_val_2,
       t1.mfc_date
FROM (SELECT im_markets_forecast_calc_daily.mfc_iteration,
             im_markets_forecast_calc_daily.mfc_market_id,
             im_markets_forecast_calc_daily.mfc_scenario,
             im_markets_forecast_calc_daily.mfc_val_1,
             im_markets_forecast_calc_daily.mfc_val_2,
             im_markets_forecast_calc_daily.mfc_date
      FROM im.im_markets_forecast_calc_daily
      WHERE im_markets_forecast_calc_daily.mfc_commodity_id = 2
        AND im_markets_forecast_calc_daily.mfc_market_id <> 200
        AND im_markets_forecast_calc_daily.mfc_indicator_id = 24
        AND im_markets_forecast_calc_daily.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                                             FROM im.im_system_variables))) t1
         LEFT JOIN im.im_market_country t2 ON t1.mfc_market_id = t2.m_id AND t2.m_commodity = 2
         LEFT JOIN countries t3 ON t2.m_country = t3.id AND t2.m_commodity = 2
UNION ALL
SELECT im_markets_forecast_calc_daily.mfc_iteration AS iteration,
       im_markets_forecast_calc_daily.mfc_scenario  AS scenario,
       'Турция'::character varying                  AS market,
       im_markets_forecast_calc_daily.mfc_val_1,
       im_markets_forecast_calc_daily.mfc_val_2,
       im_markets_forecast_calc_daily.mfc_date
FROM im.im_markets_forecast_calc_daily
WHERE im_markets_forecast_calc_daily.mfc_commodity_id = 2
  AND im_markets_forecast_calc_daily.mfc_market_id = 200
  AND im_markets_forecast_calc_daily.mfc_indicator_id = 24
  AND im_markets_forecast_calc_daily.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                                       FROM im.im_system_variables));

alter table v_gas_market_price
    owner to postgres;

