create procedure sp_insert_new_power_station()
    language sql
as
$$
    INSERT INTO power_station_info(s_eic_code, s_g_id, s_name, s_owner, s_effns, s_c_id)
    (
        SELECT t.powerstation_eic_code
             , t.g_id
             , t.powerstation
             , t.owner
             , t.powerstation_effectiveness
             , t.c_id
        FROM
             (
                 SELECT t1.powerstation_eic_code
                      , t3.g_id
                      , t1.powerstation
                      , t1.owner
                      , t1.powerstation_effectiveness
                      , t2.c_id
                      , row_number() over (PARTITION BY t1.powerstation, t1.powerstation_eic_code
                                           ORDER BY t1.powerstation, t1.powerstation_eic_code) as rn
                 FROM power_powerunits_directory_new_info t1
                 LEFT JOIN power_country_info t2 ON t1.country = t2.c_alpha2_code
                 LEFT JOIN power_generation_info t3 ON t1.generation_type = t3.g_type
             ) as t
        WHERE t.rn = 1
        EXCEPT
             (
                 SELECT s_eic_code, s_g_id, s_name, s_owner, s_effns,s_c_id
                 FROM power_station_info
             )
    );
$$;

alter procedure sp_insert_new_power_station() owner to postgres;

