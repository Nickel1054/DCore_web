create view v_eq_remit_messages_transmission
            (planned_unplanned, available_capacity, installed_capacity, activation_begin, activation_end, reason,
             published, version, data_type, area_from, area_to)
as
SELECT eq_remit_messages_planned_unplanned.planned_unplanned,
       eq_remit_messages.available_capacity,
       eq_remit_messages.installed_capacity,
       timezone('Europe/Amsterdam'::text, eq_remit_messages.activation_begin) AS activation_begin,
       timezone('Europe/Amsterdam'::text, eq_remit_messages.activation_end)   AS activation_end,
       eq_remit_messages_reason.reason,
       timezone('Europe/Amsterdam'::text, eq_remit_messages.published)        AS published,
       eq_remit_messages.version,
       eq_remit_messages.data_type,
       eq_remit_messages_area_from.area_from,
       eq_remit_messages_area_to.area_to
FROM eq_remit_messages
         LEFT JOIN eq_remit_messages_planned_unplanned
                   ON eq_remit_messages.planned_unplanned = eq_remit_messages_planned_unplanned.id
         LEFT JOIN eq_remit_messages_zone ON eq_remit_messages.zone = eq_remit_messages_zone.id
         LEFT JOIN eq_remit_messages_unit ON eq_remit_messages.unit = eq_remit_messages_unit.id
         LEFT JOIN eq_remit_messages_eic_code ON eq_remit_messages.eic_code = eq_remit_messages_eic_code.id
         LEFT JOIN eq_remit_messages_fuel_type ON eq_remit_messages.fuel_type = eq_remit_messages_fuel_type.id
         LEFT JOIN eq_remit_messages_reason ON eq_remit_messages.reason = eq_remit_messages_reason.id
         LEFT JOIN eq_remit_messages_area_from ON eq_remit_messages.area_from = eq_remit_messages_area_from.id
         LEFT JOIN eq_remit_messages_area_to ON eq_remit_messages.area_to = eq_remit_messages_area_to.id
WHERE eq_remit_messages.data_type::text = 'transmission'::text;

alter table v_eq_remit_messages_transmission
    owner to postgres;

