create view v_powerinstorage_forecast
            (iteration, scenario, indicator, market, utc_datetime, storage_id, val_1, val_2, val_3) as
SELECT im_powerinstorage_forecast_calc2.psf_iteration    AS iteration,
       im_powerinstorage_forecast_calc2.psf_scenario_id  AS scenario,
       im_powerinstorage_forecast_calc2.psf_indicator_id AS indicator,
       im_powerinstorage_forecast_calc2.psf_market_id    AS market,
       im_powerinstorage_forecast_calc2.psf_utc_datetime AS utc_datetime,
       im_powerinstorage_forecast_calc2.psf_storage_id   AS storage_id,
       im_powerinstorage_forecast_calc2.psf_val_1        AS val_1,
       im_powerinstorage_forecast_calc2.psf_val_2        AS val_2,
       im_powerinstorage_forecast_calc2.psf_val_3        AS val_3
FROM im.im_powerinstorage_forecast_calc2;

alter table v_powerinstorage_forecast
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_powerinstorage_forecast to quicksight;

