create view v_forecasted_european_gas_balance
            ("Итерация", "Сценарий", "Рынок", "Индикатор", "Тип", "Значение", "Дата-время UTC") as
SELECT t.iteration    AS "Итерация",
       t.scenario     AS "Сценарий",
       t3.country_rus AS "Рынок",
       t1.ind_name_ru AS "Индикатор",
       t.type         AS "Тип",
       t.value        AS "Значение",
       t.dtutc        AS "Дата-время UTC"
FROM (SELECT im_markets_forecast_calc.mfc_iteration                AS iteration,
             im_markets_forecast_calc.mfc_scenario                 AS scenario,
             im_markets_forecast_calc.mfc_market_id                AS market,
             im_markets_forecast_calc.mfc_indicator_id             AS indicator,
             'Потребление без учета газовой генерации, МВтч'::text AS type,
             - im_markets_forecast_calc.mfc_val_2                  AS value,
             im_markets_forecast_calc.mfc_datetime_utc             AS dtutc
      FROM im.im_markets_forecast_calc
      WHERE im_markets_forecast_calc.mfc_commodity_id = 2
        AND im_markets_forecast_calc.mfc_indicator_id = 21
        AND im_markets_forecast_calc.mfc_iteration > ((SELECT im_system_variables.max_iter - 8
                                                       FROM im.im_system_variables))
        AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY [1, 2, 3]))
      UNION ALL
      SELECT im_markets_forecast_calc.mfc_iteration,
             im_markets_forecast_calc.mfc_scenario,
             0,
             im_markets_forecast_calc.mfc_indicator_id,
             'Суммарное потребление газа, МВтч'::text,
             - sum(im_markets_forecast_calc.mfc_val_7),
             im_markets_forecast_calc.mfc_datetime_utc
      FROM im.im_markets_forecast_calc
      WHERE im_markets_forecast_calc.mfc_commodity_id = 2
        AND im_markets_forecast_calc.mfc_indicator_id = 22
        AND im_markets_forecast_calc.mfc_iteration > ((SELECT im_system_variables.max_iter - 8
                                                       FROM im.im_system_variables))
        AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY [1, 2, 3]))
      GROUP BY im_markets_forecast_calc.mfc_iteration, im_markets_forecast_calc.mfc_scenario,
               im_markets_forecast_calc.mfc_commodity_id, im_markets_forecast_calc.mfc_indicator_id,
               im_markets_forecast_calc.mfc_datetime_utc
      UNION ALL
      SELECT im_markets_forecast_calc.mfc_iteration,
             im_markets_forecast_calc.mfc_scenario,
             0,
             im_markets_forecast_calc.mfc_indicator_id,
             'Суммарная разница между выкачкой и закачкой в сутки'::text,
             sum(im_markets_forecast_calc.mfc_val_4 - im_markets_forecast_calc.mfc_val_3) AS sum,
             im_markets_forecast_calc.mfc_datetime_utc
      FROM im.im_markets_forecast_calc
      WHERE im_markets_forecast_calc.mfc_commodity_id = 2
        AND im_markets_forecast_calc.mfc_indicator_id = 31
        AND im_markets_forecast_calc.mfc_iteration > ((SELECT im_system_variables.max_iter - 8
                                                       FROM im.im_system_variables))
        AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY [1, 2, 3]))
      GROUP BY im_markets_forecast_calc.mfc_iteration, im_markets_forecast_calc.mfc_scenario,
               im_markets_forecast_calc.mfc_commodity_id, im_markets_forecast_calc.mfc_indicator_id,
               im_markets_forecast_calc.mfc_datetime_utc
      UNION ALL
      SELECT im_markets_forecast_calc.mfc_iteration,
             im_markets_forecast_calc.mfc_scenario,
             0,
             im_markets_forecast_calc.mfc_indicator_id,
             'Cуммарная добыча газа в час'::text,
             sum(im_markets_forecast_calc.mfc_val_1) AS sum,
             im_markets_forecast_calc.mfc_datetime_utc
      FROM im.im_markets_forecast_calc
      WHERE im_markets_forecast_calc.mfc_commodity_id = 2
        AND im_markets_forecast_calc.mfc_indicator_id = 25
        AND im_markets_forecast_calc.mfc_iteration > ((SELECT im_system_variables.max_iter - 8
                                                       FROM im.im_system_variables))
        AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY [1, 2, 3]))
      GROUP BY im_markets_forecast_calc.mfc_iteration, im_markets_forecast_calc.mfc_scenario,
               im_markets_forecast_calc.mfc_commodity_id, im_markets_forecast_calc.mfc_indicator_id,
               im_markets_forecast_calc.mfc_datetime_utc
      UNION ALL
      SELECT im_markets_forecast_calc.mfc_iteration,
             im_markets_forecast_calc.mfc_scenario,
             im_markets_forecast_calc.mfc_market_id,
             im_markets_forecast_calc.mfc_indicator_id,
             'Суммарный объем заявок импорта внешнего газа'::text,
             im_markets_forecast_calc.mfc_val_8,
             im_markets_forecast_calc.mfc_datetime_utc
      FROM im.im_markets_forecast_calc
      WHERE im_markets_forecast_calc.mfc_commodity_id = 2
        AND im_markets_forecast_calc.mfc_indicator_id = 36
        AND im_markets_forecast_calc.mfc_iteration > ((SELECT im_system_variables.max_iter - 8
                                                       FROM im.im_system_variables))
        AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY [1, 2, 3]))
      UNION ALL
      SELECT im_markets_forecast_calc.mfc_iteration,
             im_markets_forecast_calc.mfc_scenario,
             0,
             im_markets_forecast_calc.mfc_indicator_id,
             'Суммарный объём заявок по СПГ'::text,
             sum(im_markets_forecast_calc.mfc_val_8) AS sum,
             im_markets_forecast_calc.mfc_datetime_utc
      FROM im.im_markets_forecast_calc
      WHERE im_markets_forecast_calc.mfc_commodity_id = 2
        AND im_markets_forecast_calc.mfc_indicator_id = 34
        AND im_markets_forecast_calc.mfc_iteration > ((SELECT im_system_variables.max_iter - 8
                                                       FROM im.im_system_variables))
        AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY [1, 2, 3]))
      GROUP BY im_markets_forecast_calc.mfc_iteration, im_markets_forecast_calc.mfc_scenario,
               im_markets_forecast_calc.mfc_commodity_id, im_markets_forecast_calc.mfc_indicator_id,
               im_markets_forecast_calc.mfc_datetime_utc) t
         LEFT JOIN im.im_indicator t1 ON t.indicator = t1.ind_id
         LEFT JOIN im.im_market_country t2 ON t.market = t2.m_id AND t2.m_commodity = 2
         LEFT JOIN countries t3 ON t2.m_country = t3.id;

alter table v_forecasted_european_gas_balance
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_forecasted_european_gas_balance to quicksight;

