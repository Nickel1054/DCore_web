create view v_power_unavailability_transmission_bz
            ("Тип ремонта", "Из торг. зоны", "В торг. зону", "Дата начала", "Дата окончания", "Новое значение NTC",
             "Ед. измерения")
as
SELECT t.business_type AS "Тип ремонта",
       t.bz_from       AS "Из торг. зоны",
       t.bz_to         AS "В торг. зону",
       t.start_date    AS "Дата начала",
       t.end_date      AS "Дата окончания",
       t.quantity      AS "Новое значение NTC",
       t.quantity_uom  AS "Ед. измерения"
FROM power_unavailability_transmission_bz t;

alter table v_power_unavailability_transmission_bz
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_power_unavailability_transmission_bz to quicksight;

