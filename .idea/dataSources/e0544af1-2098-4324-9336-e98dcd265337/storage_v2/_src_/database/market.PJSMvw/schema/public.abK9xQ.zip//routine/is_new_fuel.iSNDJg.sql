create function is_new_fuel() returns boolean
    language plpgsql
as
$$
declare
    res BOOLEAN;
BEGIN
    SELECT EXISTS(
                    SELECT DISTINCT fuel_type
                    FROM power_powerunits_directory_new_info
                    EXCEPT
                    SELECT f_type
                    FROM power_fuel_info
                 ) INTO res;
    RETURN res;
END;
$$;

alter function is_new_fuel() owner to postgres;

