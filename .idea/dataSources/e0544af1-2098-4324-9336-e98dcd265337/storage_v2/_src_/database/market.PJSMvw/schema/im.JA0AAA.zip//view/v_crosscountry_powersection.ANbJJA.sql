create view v_crosscountry_powersection
            (ccs_id, ccs_out, ccs_in, ccs_mwt, ccs_scenario, ccs_startdate, ccs_enddate, country_couple) as
SELECT t1.ccs_id,
       t1.ccs_out,
       t1.ccs_in,
       t1.ccs_mwt,
       t1.ccs_scenario,
       t1.ccs_startdate,
       t1.ccs_enddate,
       (t2.iso_code::text || '_'::text) || t3.iso_code::text AS country_couple
FROM im.im_crosscountry_power_section t1
         LEFT JOIN countries t2 ON t1.ccs_out = t2.id
         LEFT JOIN countries t3 ON t1.ccs_in = t3.id;

alter table v_crosscountry_powersection
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_crosscountry_powersection to quicksight;

