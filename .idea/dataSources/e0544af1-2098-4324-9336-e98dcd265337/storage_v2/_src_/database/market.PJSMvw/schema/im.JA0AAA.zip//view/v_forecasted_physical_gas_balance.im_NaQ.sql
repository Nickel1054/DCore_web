create view v_forecasted_physical_gas_balance
            ("Итерация", "Сценарий", "Индикатор", "Рынок", "Значение", "Дата-время UTC") as
SELECT t.mfc_iteration    AS "Итерация",
       t.mfc_scenario     AS "Сценарий",
       t1.ind_name_ru     AS "Индикатор",
       t3.country_rus     AS "Рынок",
       t.value            AS "Значение",
       t.mfc_datetime_utc AS "Дата-время UTC"
FROM (SELECT im_markets_forecast_calc.mfc_iteration,
             im_markets_forecast_calc.mfc_scenario,
             im_markets_forecast_calc.mfc_market_id,
             im_markets_forecast_calc.mfc_indicator_id,
             - im_markets_forecast_calc.mfc_val_2 AS value,
             im_markets_forecast_calc.mfc_datetime_utc
      FROM im.im_markets_forecast_calc
      WHERE im_markets_forecast_calc.mfc_commodity_id = 2
        AND im_markets_forecast_calc.mfc_indicator_id = 21
        AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY [1, 2, 3]))
        AND im_markets_forecast_calc.mfc_iteration > ((SELECT sys_var.max_iter - 5
                                                       FROM im.sys_var
                                                       WHERE sys_var.indicator = 21))
      UNION ALL
      SELECT im_markets_forecast_calc.mfc_iteration,
             im_markets_forecast_calc.mfc_scenario,
             im_markets_forecast_calc.mfc_market_id,
             im_markets_forecast_calc.mfc_indicator_id,
             - im_markets_forecast_calc.mfc_val_7 AS value,
             im_markets_forecast_calc.mfc_datetime_utc
      FROM im.im_markets_forecast_calc
      WHERE im_markets_forecast_calc.mfc_commodity_id = 2
        AND im_markets_forecast_calc.mfc_indicator_id = 22
        AND im_markets_forecast_calc.mfc_iteration > ((SELECT sys_var.max_iter - 5
                                                       FROM im.sys_var
                                                       WHERE sys_var.indicator = 22))
        AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY [1, 2, 3]))
      UNION ALL
      SELECT im_markets_forecast_calc.mfc_iteration,
             im_markets_forecast_calc.mfc_scenario,
             im_markets_forecast_calc.mfc_market_id,
             im_markets_forecast_calc.mfc_indicator_id,
             - im_markets_forecast_calc.mfc_val_1 AS value,
             im_markets_forecast_calc.mfc_datetime_utc
      FROM im.im_markets_forecast_calc
      WHERE im_markets_forecast_calc.mfc_commodity_id = 2
        AND im_markets_forecast_calc.mfc_indicator_id = 27
        AND im_markets_forecast_calc.mfc_iteration > ((SELECT sys_var.max_iter - 5
                                                       FROM im.sys_var
                                                       WHERE sys_var.indicator = 27))
        AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY [1, 2, 3]))
      UNION ALL
      SELECT im_markets_forecast_calc.mfc_iteration,
             im_markets_forecast_calc.mfc_scenario,
             im_markets_forecast_calc.mfc_market_id,
             im_markets_forecast_calc.mfc_indicator_id,
             - im_markets_forecast_calc.mfc_val_3 AS value,
             im_markets_forecast_calc.mfc_datetime_utc
      FROM im.im_markets_forecast_calc
      WHERE im_markets_forecast_calc.mfc_commodity_id = 2
        AND im_markets_forecast_calc.mfc_indicator_id = 31
        AND im_markets_forecast_calc.mfc_iteration > ((SELECT sys_var.max_iter - 5
                                                       FROM im.sys_var
                                                       WHERE sys_var.indicator = 31))
        AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY [1, 2, 3]))
      UNION ALL
      SELECT im_markets_forecast_calc.mfc_iteration,
             im_markets_forecast_calc.mfc_scenario,
             im_markets_forecast_calc.mfc_market_id,
             im_markets_forecast_calc.mfc_indicator_id,
             im_markets_forecast_calc.mfc_val_1 AS value,
             im_markets_forecast_calc.mfc_datetime_utc
      FROM im.im_markets_forecast_calc
      WHERE im_markets_forecast_calc.mfc_commodity_id = 2
        AND im_markets_forecast_calc.mfc_indicator_id = 25
        AND im_markets_forecast_calc.mfc_iteration > ((SELECT sys_var.max_iter - 5
                                                       FROM im.sys_var
                                                       WHERE sys_var.indicator = 25))
        AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY [1, 2, 3]))
      UNION ALL
      SELECT im_markets_forecast_calc.mfc_iteration,
             im_markets_forecast_calc.mfc_scenario,
             im_markets_forecast_calc.mfc_market_id,
             im_markets_forecast_calc.mfc_indicator_id,
             im_markets_forecast_calc.mfc_val_8 AS value,
             im_markets_forecast_calc.mfc_datetime_utc
      FROM im.im_markets_forecast_calc
      WHERE im_markets_forecast_calc.mfc_commodity_id = 2
        AND im_markets_forecast_calc.mfc_indicator_id = 36
        AND im_markets_forecast_calc.mfc_iteration > ((SELECT sys_var.max_iter - 5
                                                       FROM im.sys_var
                                                       WHERE sys_var.indicator = 36))
        AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY [1, 2, 3]))
      UNION ALL
      SELECT im_markets_forecast_calc.mfc_iteration,
             im_markets_forecast_calc.mfc_scenario,
             im_markets_forecast_calc.mfc_market_id,
             im_markets_forecast_calc.mfc_indicator_id,
             im_markets_forecast_calc.mfc_val_4 AS value,
             im_markets_forecast_calc.mfc_datetime_utc
      FROM im.im_markets_forecast_calc
      WHERE im_markets_forecast_calc.mfc_commodity_id = 2
        AND im_markets_forecast_calc.mfc_indicator_id = 31
        AND im_markets_forecast_calc.mfc_iteration > ((SELECT sys_var.max_iter - 5
                                                       FROM im.sys_var
                                                       WHERE sys_var.indicator = 31))
        AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY [1, 2, 3]))
      UNION ALL
      SELECT im_markets_forecast_calc.mfc_iteration,
             im_markets_forecast_calc.mfc_scenario,
             im_markets_forecast_calc.mfc_market_id,
             im_markets_forecast_calc.mfc_indicator_id,
             im_markets_forecast_calc.mfc_val_8 AS value,
             im_markets_forecast_calc.mfc_datetime_utc
      FROM im.im_markets_forecast_calc
      WHERE im_markets_forecast_calc.mfc_commodity_id = 2
        AND im_markets_forecast_calc.mfc_indicator_id = 34
        AND im_markets_forecast_calc.mfc_iteration > ((SELECT sys_var.max_iter - 5
                                                       FROM im.sys_var
                                                       WHERE sys_var.indicator = 34))
        AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY [1, 2, 3]))) t
         LEFT JOIN im.im_indicator t1 ON t.mfc_indicator_id = t1.ind_id
         LEFT JOIN im.im_market_country t2 ON t.mfc_market_id = t2.m_id AND t2.m_commodity = 2
         LEFT JOIN countries t3 ON t2.m_country = t3.id;

alter table v_forecasted_physical_gas_balance
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_forecasted_physical_gas_balance to quicksight;

