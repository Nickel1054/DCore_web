create function get_avg(eic character varying, dt1 timestamp without time zone, dt2 timestamp without time zone) returns numeric
    language plpgsql
as
$$
    DECLARE
        g1 NUMERIC(10,2);
        g2 NUMERIC(10,2);
        i1 INTERVAL;
        i2 INTERVAL;
        g NUMERIC(10,2);
    BEGIN
        SELECT generated_volume INTO g1 FROM power_generation_by_unit_entsoe_bi WHERE eic_code = eic AND date_time = dt1;
        SELECT generated_volume INTO g2 FROM power_generation_by_unit_entsoe_bi WHERE eic_code = eic AND date_time = dt2;
        IF g1=0 AND g2=0 THEN g:=0; END IF;
        IF g1>0 AND g2>0 THEN g:=(g1+g2)/2; END IF;
        IF g1>0 AND g2=0 THEN g:=g1; END IF;
        IF g1=0 AND g2>0 THEN g:=g2; END IF;
    RETURN g;
    END;
$$;

alter function get_avg(varchar, timestamp, timestamp) owner to postgres;

