create view vtemp_eq_available_capacity_diff
            ("Commodity", "Сountry Code", "Recent Absolute Capacity", "Previous Absolute Capacity",
             "Absolute Capacity Change", "Recent Relative Capacity", "Previous Relative Capacity",
             "Relative Capacity Change", "Recent Iteration", "Previous Iteration", "Recent Iteration Date Hour",
             "Previous Iteration Date Hour")
as
WITH max_iteration AS (SELECT max(eq_installed_available_capacity.iteration) AS max_iter
                       FROM eq_installed_available_capacity)
SELECT c.commodity                                                     AS "Commodity",
       z.zone                                                          AS "Сountry Code",
       e1.available_capacity_absolute                                  AS "Recent Absolute Capacity",
       e2.available_capacity_absolute                                  AS "Previous Absolute Capacity",
       e1.available_capacity_absolute - e2.available_capacity_absolute AS "Absolute Capacity Change",
       e1.available_capacity_relative                                  AS "Recent Relative Capacity",
       e2.available_capacity_relative                                  AS "Previous Relative Capacity",
       e1.available_capacity_relative - e2.available_capacity_relative AS "Relative Capacity Change",
       e1.iteration                                                    AS "Recent Iteration",
       e2.iteration                                                    AS "Previous Iteration",
       e1.date_time                                                    AS "Recent Iteration Date Hour",
       e2.date_time                                                    AS "Previous Iteration Date Hour"
FROM (SELECT eq_installed_available_capacity.date_time,
             eq_installed_available_capacity.zone,
             eq_installed_available_capacity.commodity,
             eq_installed_available_capacity.installed_capacity,
             eq_installed_available_capacity.available_capacity_absolute,
             eq_installed_available_capacity.available_capacity_relative,
             eq_installed_available_capacity.installed_capacity_commodity,
             eq_installed_available_capacity.available_capacity_commodity,
             eq_installed_available_capacity.iteration
      FROM eq_installed_available_capacity) e1
         JOIN eq_installed_available_capacity e2
              ON e1.commodity = e2.commodity AND e1.zone = e2.zone AND e1.date_time = e2.date_time AND
                 e1.iteration > e2.iteration
         JOIN eq_installed_available_capacity_zone z ON e1.zone = z.id
         JOIN eq_installed_available_capacity_commodity c ON e1.commodity = c.id
         CROSS JOIN max_iteration
WHERE e1.iteration = max_iteration.max_iter
  AND e2.iteration = ((SELECT max(eq_installed_available_capacity.iteration) AS max
                       FROM eq_installed_available_capacity
                       WHERE eq_installed_available_capacity.iteration < max_iteration.max_iter));

alter table vtemp_eq_available_capacity_diff
    owner to postgres;

