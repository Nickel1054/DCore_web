create function is_zero_value(eic character varying, dt timestamp without time zone) returns boolean
    language plpgsql
as
$$
    DECLARE
        g NUMERIC(10,2);
    BEGIN
        SELECT generated_volume INTO g FROM power_generation_by_unit_entsoe WHERE eic_code = eic AND date_time = dt;
        IF g = 0 THEN RETURN TRUE;
        ELSE RETURN FALSE;
        END IF;
    END;
$$;

alter function is_zero_value(varchar, timestamp) owner to postgres;

