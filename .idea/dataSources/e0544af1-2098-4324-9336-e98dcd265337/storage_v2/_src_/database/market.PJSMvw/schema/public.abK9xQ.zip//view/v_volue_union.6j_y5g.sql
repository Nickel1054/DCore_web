create view v_volue_union
            ("Date Time CET", "Commodity", "Zone", "Last value", "Prev value", "Difference [MWh]", "Difference [%]") as
SELECT DISTINCT ON (f."Date time CET", f."Commodity", f."Zone") f."Date time CET" AS "Date Time CET",
                                                                f."Commodity",
                                                                f."Zone",
                                                                f."Last value",
                                                                f."Prev value",
                                                                f."Difference [MWh]",
                                                                f."Difference [%]"
FROM (SELECT v_volue_iterations."Date time CET",
             v_volue_iterations."Commodity",
             v_volue_iterations."Zone",
             v_volue_iterations."Last value",
             v_volue_iterations."Prev value",
             v_volue_iterations."Difference [MWh]",
             v_volue_iterations."Difference [%]",
             1 AS "TEMP"
      FROM v_volue_iterations
      WHERE v_volue_iterations."Date time CET" >= (CURRENT_DATE - '3 days'::interval)
        AND v_volue_iterations."Date time CET" < (CURRENT_DATE + '3 mons'::interval)
        AND (v_volue_iterations."Commodity"::text = ANY
             (ARRAY ['Wind generation forecast'::character varying::text, 'Photovoltaic generation forecast'::character varying::text, 'Consumption forecast'::character varying::text]))
        AND v_volue_iterations."Prev value" IS NOT NULL
        AND v_volue_iterations."Last value" IS NOT NULL
      UNION
      SELECT v_volue_iterations_ec00ens."Date time CET",
             v_volue_iterations_ec00ens."Commodity",
             v_volue_iterations_ec00ens."Zone",
             v_volue_iterations_ec00ens."Last value",
             v_volue_iterations_ec00ens."Prev value",
             v_volue_iterations_ec00ens."Difference [MWh]",
             v_volue_iterations_ec00ens."Difference [%]",
             0 AS "TEMP"
      FROM bi.v_volue_iterations_ec00ens
      WHERE v_volue_iterations_ec00ens."Date time CET" >= (CURRENT_DATE - '3 days'::interval)
        AND v_volue_iterations_ec00ens."Date time CET" < (CURRENT_DATE + '3 mons'::interval)
        AND (v_volue_iterations_ec00ens."Commodity"::text = ANY
             (ARRAY ['Wind generation forecast'::character varying::text, 'Photovoltaic generation forecast'::character varying::text, 'Consumption forecast'::character varying::text]))
        AND v_volue_iterations_ec00ens."Prev value" IS NOT NULL
        AND v_volue_iterations_ec00ens."Last value" IS NOT NULL
        AND date_part('minute'::text, v_volue_iterations_ec00ens."Date time CET") = 0::double precision
      ORDER BY 1, 8) f
WHERE date_part('minute'::text, f."Date time CET") = 0::double precision;

alter table v_volue_union
    owner to postgres;

