create procedure sp_update_phg_values()
    language plpgsql
as
$$
BEGIN
    UPDATE bi.agsiugs
    SET tech_min = t.tech_min,
        tech_max = t.tech_max,
        max_inj = t.max_inj,
        max_wtd = t.max_wtd
    FROM bi.v_update_phg AS t
    WHERE agsiugs.id = t.ugsid;
END;
$$;

alter procedure sp_update_phg_values() owner to postgres;

