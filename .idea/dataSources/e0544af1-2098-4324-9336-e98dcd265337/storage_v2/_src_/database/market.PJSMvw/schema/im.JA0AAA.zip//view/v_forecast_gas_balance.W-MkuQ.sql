create view v_forecast_gas_balance
            ("Итерация", "Сценарий", "Дата-время UTC", "Рынок", "Индикатор", "Значение индикатора") as
SELECT t.mfc_iteration    AS "Итерация",
       t.mfc_scenario     AS "Сценарий",
       t.mfc_datetime_utc AS "Дата-время UTC",
       t3.country_rus     AS "Рынок",
       t4.ind_name_ru     AS "Индикатор",
       t.val              AS "Значение индикатора"
FROM (SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             - t1.mfc_val_2 AS val
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 21
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 4
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             - t1.mfc_val_7
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 22
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 4
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 25
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 4
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 34
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 4
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_2
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 36
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 4
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.gif_iteration,
             t1.gif_scenario,
             t1.gif_utc_datetime_dst,
             t1.gif_dst,
             t1.gif_indicator,
             t1.gif_val_1
      FROM im.im_gas_impex_forecast_calc t1
      WHERE t1.gif_indicator = 26
        AND t1.gif_iteration > ((SELECT im_system_variables.max_iter - 4
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.gif_iteration,
             t1.gif_scenario,
             t1.gif_utc_datetime_src,
             t1.gif_src,
             t1.gif_indicator,
             - t1.gif_val_1
      FROM im.im_gas_impex_forecast_calc t1
      WHERE t1.gif_indicator = 27
        AND t1.gif_iteration > ((SELECT im_system_variables.max_iter - 4
                                 FROM im.im_system_variables))) t
         LEFT JOIN im.im_market_country t2 ON t.mfc_market_id = t2.m_id AND t2.m_commodity = 2
         LEFT JOIN countries t3 ON t2.m_country = t3.id
         LEFT JOIN im.im_indicator t4 ON t.mfc_indicator_id = t4.ind_id;

alter table v_forecast_gas_balance
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_forecast_gas_balance to quicksight;

