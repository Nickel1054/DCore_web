create view v_gas_futures_sftp_bi
            ("Id", "Trading date", "Delivery start date", "Delivery end date", "Open price", "High price", "Low price",
             "Last price", "Settlement price", "Lot size", "Traded lots", "Trades number", "Traded volume",
             "Open interest lots", "Open interest volume", "Delivery year", "Delivery date", "Hub", "Futures type",
             "Product type", "Delivery period", "Product Description", "Delivery month", "Continuation name")
as
SELECT row_number() OVER ()              AS "Id",
       gfsb.trading_date                 AS "Trading date",
       gfsb.delivery_start_date          AS "Delivery start date",
       gfsb.delivery_end_date            AS "Delivery end date",
       gfsb.open_price                   AS "Open price",
       gfsb.high_price                   AS "High price",
       gfsb.low_price                    AS "Low price",
       gfsb.last_price                   AS "Last price",
       gfsb.settlement_price             AS "Settlement price",
       gfsb.lot_size                     AS "Lot size",
       gfsb.traded_lots                  AS "Traded lots",
       gfsb.number_of_trades             AS "Trades number",
       gfsb.traded_volume                AS "Traded volume",
       gfsb.open_interest_lots           AS "Open interest lots",
       gfsb.open_interest_volume         AS "Open interest volume",
       gfsb.delivery_year                AS "Delivery year",
       gfsb.day_product_delivery         AS "Delivery date",
       shr.hub                           AS "Hub",
       sftr.futures_type                 AS "Futures type",
       sptr.product_type                 AS "Product type",
       spdnr.product_delivery_name       AS "Delivery period",
       spdfnr.product_delivery_full_name AS "Product Description",
       months.month_name_eng             AS "Delivery month",
       sspnr.short_prod_name             AS "Continuation name"
FROM gas_futures_sftp_bi gfsb
         LEFT JOIN sftp_hub_ref shr ON gfsb.hub = shr.id
         LEFT JOIN sftp_gas_product_code_ref sgpcr ON gfsb.product_code = sgpcr.id
         LEFT JOIN sftp_product_full_name_ref spfnr ON gfsb.product_full_name = spfnr.id
         LEFT JOIN sftp_futures_type_ref sftr ON gfsb.futures_type = sftr.id
         LEFT JOIN sftp_product_type_ref sptr ON gfsb.product_type = sptr.id
         LEFT JOIN sftp_product_delivery_name_ref spdnr ON gfsb.product_delivery_name = spdnr.id
         LEFT JOIN sftp_product_delivery_full_name_ref spdfnr ON gfsb.product_delivery_full_name = spdfnr.id
         LEFT JOIN bi.months ON gfsb.delivery_month = months.month_num
         LEFT JOIN sftp_short_prod_name_ref sspnr ON gfsb.short_prod_name = sspnr.id
WHERE sftr.futures_type::text = 'Natural Gas Future'::text;

alter table v_gas_futures_sftp_bi
    owner to postgres;

