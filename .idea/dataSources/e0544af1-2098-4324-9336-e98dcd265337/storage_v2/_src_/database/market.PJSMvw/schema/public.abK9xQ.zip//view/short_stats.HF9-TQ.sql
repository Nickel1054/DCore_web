create view short_stats
            (datname, pid, usesysid, usename, application_name, client_addr, client_port, backend_start, xact_start,
             query_start, state_change, wait_event_type, wait_event, state, query, backend_type)
as
SELECT pg_stat_activity.datname,
       pg_stat_activity.pid,
       pg_stat_activity.usesysid,
       pg_stat_activity.usename,
       pg_stat_activity.application_name,
       pg_stat_activity.client_addr,
       pg_stat_activity.client_port,
       pg_stat_activity.backend_start,
       pg_stat_activity.xact_start,
       pg_stat_activity.query_start,
       pg_stat_activity.state_change,
       pg_stat_activity.wait_event_type,
       pg_stat_activity.wait_event,
       pg_stat_activity.state,
       pg_stat_activity.query,
       pg_stat_activity.backend_type
FROM pg_stat_activity
WHERE pg_stat_activity.datname = 'market'::name;

alter table short_stats
    owner to postgres;

