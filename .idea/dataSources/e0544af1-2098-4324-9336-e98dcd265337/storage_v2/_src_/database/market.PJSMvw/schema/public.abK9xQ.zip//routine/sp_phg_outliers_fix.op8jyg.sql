create procedure sp_phg_outliers_fix()
    language plpgsql
as
$$

DECLARE tmp1 regclass;
        tmp2 regclass;
        tmp3 regclass;
        tmp4 regclass;
        tmp5 regclass;
BEGIN
    -- 1. Добавляем в таблицу agsidatabi столбец для хранения скорректированных значений газа в хранилище
    ALTER TABLE public.agsidatabi ADD COLUMN corrected_gas_in_storage DOUBLE PRECISION DEFAULT NULL;

    -- 2. Выводим историю значений для каждого UGSID за сегодняшний и завтрашний дни (оконная функция LEAD)
    --DROP TABLE IF EXISTS tmp1;
    SELECT ugsid
         , "gasDayStartedOn" AS gasdaystartedon
         , "gasInStorage" AS gas_end_of_today
         , injection AS inj_during_today
         , withdrawal AS wdr_during_today
         , LEAD("gasInStorage", 1) OVER (PARTITION BY ugsid ORDER BY ugsid, "gasDayStartedOn") AS gas_end_of_tomorrow
         , LEAD(injection, 1) OVER (PARTITION BY ugsid ORDER BY ugsid, "gasDayStartedOn") AS inj_tomorrow
         , LEAD(withdrawal, 1) OVER (PARTITION BY ugsid ORDER BY ugsid, "gasDayStartedOn") AS wdr_tomorrow
         , LEAD("gasInStorage", 1) OVER (PARTITION BY ugsid ORDER BY ugsid, "gasDayStartedOn") -
           LEAD(injection, 1) OVER (PARTITION BY ugsid ORDER BY ugsid, "gasDayStartedOn")/1000 +
           LEAD(withdrawal, 1) OVER (PARTITION BY ugsid ORDER BY ugsid, "gasDayStartedOn")/1000 AS bal_gas_in_storage_today
    INTO tmp1
    FROM public.agsidatabi;

    -- 3. Считаем соотношение значения газа в хранилище сегодняшнего дня к завтрашнему (если не <> 0)
    --DROP TABLE IF EXISTS tmp2;
    SELECT CASE WHEN bal_gas_in_storage_today <> 0 THEN tmp1.gas_end_of_today/bal_gas_in_storage_today
                ELSE 0
           END AS ratio_future
         , *
    INTO tmp2
    FROM tmp1;

    -- 3. Извлекаем те исторические значения где было существенное изменение (25% и выше) по сравнению с предыдущим днём.
    --DROP TABLE IF EXISTS tmp3;
    SELECT ugsid
         , gasdaystartedon
         , gas_end_of_today
         , gas_end_of_tomorrow
         , CASE WHEN gas_end_of_tomorrow > gas_end_of_today THEN '+'
                WHEN gas_end_of_tomorrow < gas_end_of_today THEN '-'
           END AS sign
         , ratio_future
    INTO tmp3
    FROM tmp2
    WHERE (ratio_future >= 1.25 OR ratio_future <= 0.75) OR ratio_future = 0
    AND gas_end_of_today IS NOT NULL;

    -- 4. Сохраняем рельзультаты в промежуточную таблицу tmp4
    --DROP TABLE IF EXISTS tmp4;
    SELECT *
    INTO tmp4
    FROM tmp3
    WHERE gas_end_of_tomorrow IS NOT NULL AND (gas_end_of_today <> 0 OR gas_end_of_tomorrow <> 0);

    -- 5. Удаление одиночных UGSID drops-jumps в которых не происходит возврата к довсплесковому значению
    DELETE FROM tmp4
    WHERE ugsid IN (SELECT ugsid FROM tmp4 GROUP BY ugsid HAVING COUNT(ugsid)=1);

    -- 6. Удаляем пересечения итервалов для UGSID у которых более одного аномального периода продолжительностью более 3х дней
    --DROP TABLE IF EXISTS tmp5;
    SELECT t4.ugsid, t4.gasdaystartedon AS day_1, t5.gasdaystartedon AS day_2, AGE(t5.gasdaystartedon, t4.gasdaystartedon),
           t4.gas_end_of_today as gas_today, t5.gas_end_of_today gas_tomorrow, t5.gas_end_of_tomorrow gas_after_tomorrow,
           t4.sign AS sign_1, t5.sign AS sign_2
    INTO tmp5
    FROM tmp4 t4
    INNER JOIN tmp4 t5 ON t4.ugsid = t5.ugsid
    AND date_part('year',t4.gasdaystartedon) = date_part('year',t5.gasdaystartedon)
    AND date_part('month', t4.gasdaystartedon) = date_part('month', t5.gasdaystartedon)
    AND date_part('day', t4.gasdaystartedon) < date_part('day',t5.gasdaystartedon)
    AND t4.sign = '-' AND t5.sign = '+' AND t5.gas_end_of_today = 0 AND t4.gas_end_of_today > 0.1
    AND AGE(t5.gasdaystartedon, t4.gasdaystartedon) <= make_interval(days :=3);

    -- 7. Обновление скорректированных значений в таблице agsidatabi
    UPDATE public.agsidatabi
    SET corrected_gas_in_storage = q1.upd_gas_in_storage
    FROM (SELECT ugsid AS uid, (gas_today + gas_after_tomorrow)/2 AS upd_gas_in_storage, day_2 AS START_DATE, (day_2 + age)::DATE AS END_DATE  FROM tmp5) AS q1
    WHERE ugsid = q1.uid AND gasdaystartedon >= q1.START_DATE AND gasdaystartedon <=q1.END_DATE;

    -- 8. Обновляем остальные значения в столбце corrected_gas_in_storage которые имеют значения NULL (просто копируем значения из gasinstorage)
    UPDATE public.agsidatabi
    SET corrected_gas_in_storage = "gasInStorage"
    WHERE corrected_gas_in_storage IS NULL;

END;
$$;

alter procedure sp_phg_outliers_fix() owner to postgres;

