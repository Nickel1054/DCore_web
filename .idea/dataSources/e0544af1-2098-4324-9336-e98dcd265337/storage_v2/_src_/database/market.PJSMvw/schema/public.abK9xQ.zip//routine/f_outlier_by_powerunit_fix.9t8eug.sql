create function f_outlier_by_powerunit_fix() returns void
    language plpgsql
as
$$
    BEGIN
        -- Clear tables ------------------------------------------------------------------------------------------------
        TRUNCATE TABLE power_tmp_outliers;
        TRUNCATE TABLE power_tmp_outliers_summary;
        ----------------------------------------------------------------------------------------------------------------
        -- Get all new outliers detail data:
        INSERT INTO power_tmp_outliers (eic_code, generated_volume, powerunit_output_mw, date_time)
        SELECT v.eic_code, v.generated_volume, v.powerunit_output_mw, v.date_time
        FROM v_power_outliers v;
        ----------------------------------------------------------------------------------------------------------------
        -- Get all new outliers data summary:
        INSERT INTO power_tmp_outliers_summary (eic_code, daily_num_outliers, max_generated_volume, powerunit_output_mw, dt, min_dt, max_dt, intrvl)
        SELECT v.eic_code
             , v.daily_num_outliers
             , v.max_generated_volume
             , v.powerunit_output_mw
             , v.dt
             , v.min_dt
             , v.max_dt
             , CASE WHEN daily_num_outliers <= 23 THEN make_interval(hours => daily_num_outliers::INT)
                    ELSE make_interval(days => 1::INT)
               END AS intrvl
        FROM v_power_outliers_summary v;
        ----------------------------------------------------------------------------------------------------------------
        -- Update power_generation_by_unit_entsoe_bi table values where outliers happened
        UPDATE power_generation_by_unit_entsoe_bi b
        SET generated_volume = tt.avg_gen
        FROM (
                 SELECT t.eic_code
                      , t.outlier_timestamp
                      , get_avg(t.eic_code, t.new_min_no_outlier_timestamp, t.new_max_no_outlier_timestamp) AS avg_gen
                 FROM (
                          SELECT p1.eic_code
                               , p1.date_time as outlier_timestamp
                               , p1.generated_volume
                               , p1.powerunit_output_mw
                               , CASE WHEN is_outlier(p1.eic_code, p1.date_time)
                                      THEN get_min_timestamp_no_outlier(p1.eic_code, p1.date_time)
                                      ELSE p1.date_time - p2.intrvl
                                 END AS new_min_no_outlier_timestamp
                               , CASE WHEN is_outlier(p1.eic_code, p1.date_time)
                                      THEN get_max_timestamp_no_outlier(p1.eic_code, p1.date_time)
                                      ELSE p1.date_time + p2.intrvl
                                 END AS new_max_no_outlier_timestamp
                          FROM power_tmp_outliers p1
                          LEFT JOIN power_tmp_outliers_summary p2
                                 ON p1.eic_code = p2.eic_code AND p1.date_time::DATE = p2.dt
                      ) AS t
             ) AS tt
        WHERE b.eic_code = tt.eic_code AND b.date_time = tt.outlier_timestamp;
    END;
$$;

alter function f_outlier_by_powerunit_fix() owner to postgres;

