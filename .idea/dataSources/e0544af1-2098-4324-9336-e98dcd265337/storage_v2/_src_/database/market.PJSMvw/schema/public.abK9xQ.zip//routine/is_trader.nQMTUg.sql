create function is_trader(cpty_id bigint, date date) returns boolean
    language plpgsql
as
$$
declare
    res BOOLEAN;
BEGIN
    CREATE TEMP TABLE tmp_trader(cid INTEGER NOT NULL, cdate DATE NOT NULL);
    INSERT INTO tmp_trader
    SELECT DISTINCT t2.mc_id AS sellerid
                         , t1.month
                    FROM corp.gas_market_product_info_new t1
                    LEFT JOIN corp.market_counterparty t2 ON t1.seller_id = t2.mc_inn
                    INNER JOIN (SELECT DISTINCT t2.mc_id AS buyerid, t1.month
                                FROM corp.gas_market_product_info_new t1
                                LEFT JOIN corp.market_counterparty t2 ON t1.buyer_id = t2.mc_inn) AS t3
                                ON t2.mc_id = t3.buyerid AND t1.month = t3.month;

    SELECT EXISTS(
                    SELECT cpty_id, date
                    INTERSECT
                    SELECT cid, cdate FROM tmp_trader
                 ) INTO res;
    DROP TABLE tmp_trader;
    RETURN res;
END;
$$;

alter function is_trader(bigint, date) owner to postgres;

