create view v_market_grouping_by_seller_buyer(mpi_md_id, mpi_buyer_id, mpi_seller_id, agent_size) as
SELECT market_product_info.mpi_md_id,
       market_product_info.mpi_buyer_id,
       market_product_info.mpi_seller_id,
       CASE
           WHEN sum(market_product_info.mpi_qty) >= 4500::numeric THEN 1
           WHEN sum(market_product_info.mpi_qty) < 4500::numeric THEN 0
           ELSE NULL::integer
           END AS agent_size
FROM market_product_info
GROUP BY market_product_info.mpi_md_id, market_product_info.mpi_buyer_id, market_product_info.mpi_seller_id;

alter table v_market_grouping_by_seller_buyer
    owner to postgres;

