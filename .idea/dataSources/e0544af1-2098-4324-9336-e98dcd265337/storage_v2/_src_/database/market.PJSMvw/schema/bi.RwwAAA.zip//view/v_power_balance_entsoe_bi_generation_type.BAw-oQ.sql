create view v_power_balance_entsoe_bi_generation_type
            ("Period", "Date", "Hour", "Generation", "MWh", "Working/Non-working", "Country") as
SELECT t.date_time                                                     AS "Period",
       "left"(to_char(t.date_time, 'YYYY-MM-DD HH24:MI:SS'::text), 10) AS "Date",
       "right"(to_char(t.date_time, 'YYYY-MM-DD HH24:MI:SS'::text), 8) AS "Hour",
       g.type_name                                                     AS "Generation",
       t.value                                                         AS "MWh",
       m.is_working_str                                                AS "Working/Non-working",
       c.country_name                                                  AS "Country"
FROM power_balance_entsoe_bi t
         LEFT JOIN power_balance_entsoe_info g ON t.id = g.id
         LEFT JOIN countries c ON t.country_code::text = c.iso_code::text
         LEFT JOIN working_day_map m ON t.is_working = m.is_working;

alter table v_power_balance_entsoe_bi_generation_type
    owner to postgres;

