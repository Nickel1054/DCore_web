create view v_pm_2 ("Дата", "Продавец", "Покупатель", tot_qty, tot_vol, price, size, trader) as
SELECT t.mpi_md_id AS "Дата",
       t3.mc_name  AS "Продавец",
       t4.mc_name  AS "Покупатель",
       t.tot_qty,
       t.tot_vol,
       t.price,
       t.size,
       CASE
           WHEN t1.mpi_seller_id IS NULL THEN 'yes'::text
           ELSE 'no'::text
           END     AS trader
FROM (SELECT t1_1.mpi_md_id,
             t1_1.mpi_seller_id,
             t1_1.mpi_buyer_id,
             sum(t1_1.mpi_qty)                                  AS tot_qty,
             sum(t1_1.mpi_volume)                               AS tot_vol,
             round(sum(t1_1.mpi_volume) / sum(t1_1.mpi_qty), 2) AS price,
             CASE
                 WHEN sum(t1_1.mpi_qty) > 4500::numeric THEN 'крупный'::text
                 ELSE 'средний'::text
                 END                                            AS size
      FROM market_product_info t1_1
      WHERE t1_1.mpi_mp_id = 1
      GROUP BY t1_1.mpi_md_id, t1_1.mpi_seller_id, t1_1.mpi_buyer_id
      HAVING sum(t1_1.mpi_qty) > 10::numeric) t
         LEFT JOIN (SELECT market_product_info.mpi_md_id,
                           market_product_info.mpi_seller_id
                    FROM market_product_info
                    GROUP BY market_product_info.mpi_seller_id, market_product_info.mpi_md_id) t1
                   ON t.mpi_buyer_id = t1.mpi_seller_id AND t.mpi_md_id = t1.mpi_md_id
         LEFT JOIN market_counterparty t3 ON t.mpi_seller_id = t3.mc_id
         LEFT JOIN market_counterparty t4 ON t.mpi_buyer_id = t4.mc_id;

alter table v_pm_2
    owner to postgres;

