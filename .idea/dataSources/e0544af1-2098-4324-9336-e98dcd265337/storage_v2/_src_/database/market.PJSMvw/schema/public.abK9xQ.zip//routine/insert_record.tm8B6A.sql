create function insert_record() returns void
    language plpgsql
as
$$
DECLARE first_name TEXT= INITCAP(get_random_string());
DECLARE last_name TEXT= INITCAP(get_random_string());
DECLARE email TEXT= LOWER(CONCAT(first_name, '.', last_name, '@gmail.com'));
DECLARE mobile_no BIGINT=CAST(1000000000 + FLOOR(RANDOM() * 9000000000) AS BIGINT);
DECLARE date_of_birth DATE= CAST( NOW() - INTERVAL '100 year' * RANDOM() AS DATE);
BEGIN
INSERT INTO bi.test (fname, lname, email, mobile, dob) VALUES (first_name, last_name, email, mobile_no, date_of_birth);
END;
$$;

alter function insert_record() owner to postgres;

