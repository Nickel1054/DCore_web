create view v_power_equilibrium_price("Итерация", "Сценарий", "Рынок", "Значение", "Дата-время UTC") as
SELECT t.mfc_iteration                                                             AS "Итерация",
       t.mfc_scenario                                                              AS "Сценарий",
       t2.country_rus                                                              AS "Рынок",
       COALESCE(NULLIF(t.mfc_val_1, 'NaN'::double precision), 0::double precision) AS "Значение",
       t.mfc_datetime_utc                                                          AS "Дата-время UTC"
FROM im.im_markets_forecast_calc t
         LEFT JOIN im.im_market_country t1 ON t.mfc_market_id = t1.m_id AND t1.m_commodity = 1
         LEFT JOIN countries t2 ON t1.m_country = t2.id
WHERE t.mfc_indicator_id = 18
  AND t.mfc_iteration > ((SELECT im_system_variables.max_iter - 8
                          FROM im.im_system_variables));

alter table v_power_equilibrium_price
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_power_equilibrium_price to quicksight;

