create view v_epsi_download_smp_main_test_diff_mt
            ("Date Hour", "Country Code", "Scenario Name Main", "Scenario Name Test", "Scenario Run Main",
             "Scenario Run Test", "Units", "Price Main", "Price Test", "Price Difference Euro",
             "Price Difference Relative")
as
WITH joined_table_main AS (SELECT timezone('Europe/Amsterdam'::text, smp.date_time)             AS date_time,
                                  country.country,
                                  CASE
                                      WHEN country.country = 'Denmark (West)'::text THEN 'DK1'::text
                                      WHEN country.country = 'Denmark (East)'::text THEN 'DK2'::text
                                      WHEN country.country = 'Czech Republic'::text THEN 'CZ'::text
                                      WHEN country.country = 'Bosnia Herzegovina'::text THEN 'BA'::text
                                      WHEN country.country = 'Serbia Montenegro'::text THEN 'RS'::text
                                      ELSE countries.iso_code::text
                                      END                                                       AS country_code,
                                  property.property_name,
                                  scenario.scenario_id,
                                  scenario_name.scenario_name,
                                  timezone('Europe/Amsterdam'::text, scenario_run.scenario_run) AS scenario_run,
                                  units.units,
                                  smp.value,
                                  timezone('Europe/Amsterdam'::text, iteration.iteration)       AS iteration,
                                  forecast.forecast_period,
                                  timeframe_type.timeframe_type
                           FROM epsi_download_smp smp
                                    LEFT JOIN epsi_download_country country ON smp.country = country.id
                                    LEFT JOIN epsi_download_property_name property ON smp.property_name = property.id
                                    LEFT JOIN epsi_download_scenario_id scenario ON smp.scenario_id = scenario.id
                                    LEFT JOIN epsi_download_scenario_name scenario_name
                                              ON smp.scenario_name = scenario_name.id
                                    LEFT JOIN epsi_download_scenario_run scenario_run
                                              ON smp.scenario_run = scenario_run.id
                                    LEFT JOIN epsi_download_units units ON smp.units = units.id
                                    LEFT JOIN epsi_download_iteration iteration ON smp.iteration = iteration.id
                                    LEFT JOIN epsi_download_forecast_period forecast
                                              ON smp.forecast_period = forecast.id
                                    LEFT JOIN epsi_download_timeframe_type timeframe_type
                                              ON smp.timeframe_type = timeframe_type.id
                                    LEFT JOIN countries countries ON countries.country_name::text = country.country
                           WHERE timeframe_type.timeframe_type = 'MT'::text),
     joined_table_test AS (SELECT timezone('Europe/Amsterdam'::text, smp.date_time)             AS date_time,
                                  country.country,
                                  CASE
                                      WHEN country.country = 'Denmark (West)'::text THEN 'DK1'::text
                                      WHEN country.country = 'Denmark (East)'::text THEN 'DK2'::text
                                      WHEN country.country = 'Czech Republic'::text THEN 'CZ'::text
                                      WHEN country.country = 'Bosnia Herzegovina'::text THEN 'BA'::text
                                      WHEN country.country = 'Serbia Montenegro'::text THEN 'RS'::text
                                      ELSE countries.iso_code::text
                                      END                                                       AS country_code,
                                  property.property_name,
                                  scenario.scenario_id,
                                  scenario_name.scenario_name,
                                  timezone('Europe/Amsterdam'::text, scenario_run.scenario_run) AS scenario_run,
                                  units.units,
                                  smp.value,
                                  timezone('Europe/Amsterdam'::text, iteration.iteration)       AS iteration,
                                  forecast.forecast_period,
                                  timeframe_type.timeframe_type
                           FROM epsi_download_smp_test_model smp
                                    LEFT JOIN epsi_download_country country ON smp.country = country.id
                                    LEFT JOIN epsi_download_property_name property ON smp.property_name = property.id
                                    LEFT JOIN epsi_download_scenario_id scenario ON smp.scenario_id = scenario.id
                                    LEFT JOIN epsi_download_scenario_name scenario_name
                                              ON smp.scenario_name = scenario_name.id
                                    LEFT JOIN epsi_download_scenario_run scenario_run
                                              ON smp.scenario_run = scenario_run.id
                                    LEFT JOIN epsi_download_units units ON smp.units = units.id
                                    LEFT JOIN epsi_download_iteration iteration ON smp.iteration = iteration.id
                                    LEFT JOIN epsi_download_forecast_period forecast
                                              ON smp.forecast_period = forecast.id
                                    LEFT JOIN epsi_download_timeframe_type timeframe_type
                                              ON smp.timeframe_type = timeframe_type.id
                                    LEFT JOIN countries countries ON countries.country_name::text = country.country
                           WHERE timeframe_type.timeframe_type = 'MT'::text),
     max_run_main AS (SELECT max(joined_table_main.scenario_run) AS msr
                      FROM joined_table_main),
     max_run_test AS (SELECT max(joined_table_test.scenario_run) AS msr
                      FROM joined_table_test)
SELECT e1.date_time        AS "Date Hour",
       e1.country_code     AS "Country Code",
       e1.scenario_name    AS "Scenario Name Main",
       e2.scenario_name    AS "Scenario Name Test",
       e1.scenario_run     AS "Scenario Run Main",
       e2.scenario_run     AS "Scenario Run Test",
       e1.units            AS "Units",
       e1.value            AS "Price Main",
       e2.value            AS "Price Test",
       e1.value - e2.value AS "Price Difference Euro",
       CASE
           WHEN e2.value IS NULL OR e1.value IS NULL OR e2.value = 0::double precision THEN 0::double precision
           ELSE (e1.value - e2.value) / e2.value
           END             AS "Price Difference Relative"
FROM joined_table_main e1
         JOIN joined_table_test e2
              ON e1.date_time = e2.date_time AND e1.country_code = e2.country_code AND e1.units = e2.units
WHERE e1.scenario_run = ((SELECT max_run_main.msr
                          FROM max_run_main))
  AND e2.scenario_run = ((SELECT max_run_test.msr
                          FROM max_run_test));

alter table v_epsi_download_smp_main_test_diff_mt
    owner to postgres;

