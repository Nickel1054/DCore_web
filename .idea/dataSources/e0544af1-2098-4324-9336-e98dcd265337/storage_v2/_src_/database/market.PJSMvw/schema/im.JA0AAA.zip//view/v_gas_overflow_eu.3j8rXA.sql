create view v_gas_overflow_eu as
SELECT t.gif_iteration,
       t.gif_indicator,
       t.gif_src,
       t.gif_dst,
       t.gif_scenario,
       t."?column?",
       t.gif_utc_datetime_src
FROM (SELECT t1.gif_iteration,
             t1.gif_indicator,
             t1.gif_src,
             t1.gif_dst,
             t1.gif_scenario,
             - t1.gif_val_1,
             t1.gif_utc_datetime_src
      FROM im.im_gas_impex_forecast_calc t1
      WHERE t1.gif_indicator = 27
        AND t1.gif_iteration > ((SELECT im_system_variables.max_iter - 4
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.gif_iteration,
             t1.gif_indicator,
             t1.gif_dst,
             t1.gif_src,
             t1.gif_scenario,
             t1.gif_val_1,
             t1.gif_utc_datetime_src
      FROM im.im_gas_impex_forecast_calc t1
      WHERE t1.gif_indicator = 26
        AND t1.gif_iteration > ((SELECT im_system_variables.max_iter - 4
                                 FROM im.im_system_variables))) t;

alter table v_gas_overflow_eu
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_gas_overflow_eu to quicksight;

