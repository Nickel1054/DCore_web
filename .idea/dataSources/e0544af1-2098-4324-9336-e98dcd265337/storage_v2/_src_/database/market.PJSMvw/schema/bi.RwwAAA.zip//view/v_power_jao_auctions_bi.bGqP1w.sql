create view v_power_jao_auctions_bi
            ("Delivery Period", "Contract Type", "Area From", "Area To", "Auction Price", "Offered ATC",
             "Trading Date") as
SELECT power_jao_auctions_delivery_period.delivery_period                             AS "Delivery Period",
       power_jao_auctions_timeframe_type.timeframe_type                               AS "Contract Type",
       power_jao_auctions_from_area.from_area                                         AS "Area From",
       power_jao_auctions_to_area.to_area                                             AS "Area To",
       power_jao_auctions_bi.auction_price                                            AS "Auction Price",
       power_jao_auctions_bi.offered_capacity                                         AS "Offered ATC",
       timezone('Europe/Amsterdam'::text, power_jao_auctions_bi.auction_gate_opening) AS "Trading Date"
FROM power_jao_auctions_bi
         LEFT JOIN power_jao_auctions_auction_id ON power_jao_auctions_auction_id.id = power_jao_auctions_bi.auction_id
         LEFT JOIN power_jao_auctions_timeframe_type
                   ON power_jao_auctions_timeframe_type.id = power_jao_auctions_bi.timeframe_type
         LEFT JOIN power_jao_auctions_delivery_period
                   ON power_jao_auctions_delivery_period.id = power_jao_auctions_bi.delivery_period
         LEFT JOIN power_jao_auctions_to_area ON power_jao_auctions_to_area.id = power_jao_auctions_bi.to_area
         LEFT JOIN power_jao_auctions_from_area ON power_jao_auctions_from_area.id = power_jao_auctions_bi.from_area
         LEFT JOIN power_jao_auctions_update_datetime
                   ON power_jao_auctions_update_datetime.id = power_jao_auctions_bi.update_datetime
WHERE ('Contract Type'::text <> ALL (ARRAY ['Daily'::text, 'Intraday'::text]))
  AND power_jao_auctions_bi.is_cancelled <> true
ORDER BY power_jao_auctions_timeframe_type.timeframe_type DESC,
         (timezone('Europe/Amsterdam'::text, power_jao_auctions_bi.auction_gate_opening));

alter table v_power_jao_auctions_bi
    owner to postgres;

