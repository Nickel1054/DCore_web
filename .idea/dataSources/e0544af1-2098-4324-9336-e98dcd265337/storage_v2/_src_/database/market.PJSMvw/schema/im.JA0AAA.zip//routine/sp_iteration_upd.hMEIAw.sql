create procedure sp_iteration_upd()
    language plpgsql
as
$$
BEGIN
    UPDATE im.im_iteration
    SET iteration_endtime = CURRENT_TIMESTAMP
    WHERE iteration_starttime IN
          (SELECT iteration_starttime FROM im.im_iteration ORDER BY iteration_starttime DESC LIMIT 1);
END;
$$;

alter procedure sp_iteration_upd() owner to postgres;

