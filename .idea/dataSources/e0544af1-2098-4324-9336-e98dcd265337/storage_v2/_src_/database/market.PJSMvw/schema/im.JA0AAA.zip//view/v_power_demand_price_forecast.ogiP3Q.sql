create view v_power_demand_price_forecast
            (num, "Итерация", "Микросервис", "Индикатор", "Рынок", "Сценарий", "Object ID", "Order ID", "Order rank",
             "Generation type", "Объём заявки", "Цена заявки Евро/МВтч", "расчёт цен в национальных валютах",
             "Прогноз/факт выбросов по заявке, в ", "Прогноз/факт сожженного топлива п",
             "Прогноз/факт выбросов по удовлетв", "Прогноз/факт сожж топлива по удовл",
             "Удовлетворённый объём заявки в МВ", "Время UTC")
as
SELECT row_number() OVER () AS num,
       t.edp_iteration      AS "Итерация",
       t.edp_mcrsrvc        AS "Микросервис",
       t.edp_indicator      AS "Индикатор",
       t.edp_market         AS "Рынок",
       t.edp_scenario       AS "Сценарий",
       t.edp_object_id      AS "Object ID",
       t.edp_order_id       AS "Order ID",
       t.edp_order_rank     AS "Order rank",
       t.edp_gt_id          AS "Generation type",
       t.edp_val_1          AS "Объём заявки",
       t.edp_val_2          AS "Цена заявки Евро/МВтч",
       t.edp_val_3          AS "расчёт цен в национальных валютах",
       t.edp_val_4          AS "Прогноз/факт выбросов по заявке, в ",
       t.edp_val_5          AS "Прогноз/факт сожженного топлива п",
       t.edp_val_6          AS "Прогноз/факт выбросов по удовлетв",
       t.edp_val_7          AS "Прогноз/факт сожж топлива по удовл",
       t.edp_val_8          AS "Удовлетворённый объём заявки в МВ",
       t.edp_utc_datetime   AS "Время UTC"
FROM (SELECT rank()
             OVER (PARTITION BY t1.edp_iteration, t1.edp_mcrsrvc, t1.edp_indicator, t1.edp_market, t1.edp_scenario, t1.edp_object_id, t1.edp_order_id, t1.edp_order_rank, t1.edp_gt_id ORDER BY t1.edp_iteration DESC, t1.edp_utc_datetime DESC) AS rn,
             t1.edp_iteration,
             t1.edp_mcrsrvc,
             t1.edp_indicator,
             t1.edp_market,
             t1.edp_scenario,
             t1.edp_utc_datetime,
             t1.edp_object_id,
             t1.edp_order_id,
             t1.edp_order_rank,
             t1.edp_gt_id,
             t1.edp_val_1,
             t1.edp_val_2,
             t1.edp_val_3,
             t1.edp_val_4,
             t1.edp_val_5,
             t1.edp_val_6,
             t1.edp_val_7,
             t1.edp_val_8
      FROM im.im_electr_demand_price_forecast_calc t1
      WHERE t1.edp_iteration > ((SELECT im_system_variables.max_iter - 6
                                 FROM im.im_system_variables))) t
WHERE t.rn = 1;

alter table v_power_demand_price_forecast
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_power_demand_price_forecast to quicksight;

