create view v_forecast_market_calc_last_iteration
            ("Итерация", "Рынок", "Микросервис", "Индикатор", "Сценарий", "Время UTC", "Значение 1", "Значение 2",
             "Значение 3", "Значение 4", "Значение 5", "Значение 6", "Значение 7", "Значение 8")
as
SELECT t.mfc_iteration    AS "Итерация",
       t.country_name     AS "Рынок",
       t.ms_name          AS "Микросервис",
       t.ind_name_ru      AS "Индикатор",
       t.scenario_name_ru AS "Сценарий",
       t.mfc_datetime_utc AS "Время UTC",
       t.mfc_val_1        AS "Значение 1",
       t.mfc_val_2        AS "Значение 2",
       t.mfc_val_3        AS "Значение 3",
       t.mfc_val_4        AS "Значение 4",
       t.mfc_val_5        AS "Значение 5",
       t.mfc_val_6        AS "Значение 6",
       t.mfc_val_7        AS "Значение 7",
       t.mfc_val_8        AS "Значение 8"
FROM (SELECT rank()
             OVER (PARTITION BY t1.mfc_iteration, t1.mfc_microservice_id, t1.mfc_market_id, t1.mfc_indicator_id ORDER BY t1.mfc_iteration DESC, t1.mfc_datetime_utc DESC) AS rn,
             t1.mfc_iteration,
             t6.country_name,
             t3.ms_name,
             t4.ind_name_ru,
             t1.mfc_datetime_utc,
             t5.scenario_name_ru,
             t1.mfc_val_1,
             t1.mfc_val_2,
             t1.mfc_val_3,
             t1.mfc_val_4,
             t1.mfc_val_5,
             t1.mfc_val_6,
             t1.mfc_val_7,
             t1.mfc_val_8
      FROM im.im_markets_forecast_calc t1
               LEFT JOIN im.im_market_country t2 ON t1.mfc_market_id = t2.m_id
               LEFT JOIN countries t6 ON t2.m_country = t6.id
               LEFT JOIN im.im_microservice t3 ON t1.mfc_microservice_id = t3.ms_id
               LEFT JOIN im.im_indicator t4 ON t1.mfc_indicator_id = t4.ind_id
               LEFT JOIN im.im_scenario t5 ON t1.mfc_scenario = t5.scenario_id) t
WHERE t.rn = 1
  AND t.mfc_iteration >= ((SELECT max(im_markets_forecast_calc.mfc_iteration) - 3 AS max
                           FROM im.im_markets_forecast_calc));

alter table v_forecast_market_calc_last_iteration
    owner to postgres;

