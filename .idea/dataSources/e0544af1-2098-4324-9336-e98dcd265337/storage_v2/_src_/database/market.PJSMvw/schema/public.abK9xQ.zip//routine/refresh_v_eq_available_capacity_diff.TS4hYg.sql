create function refresh_v_eq_available_capacity_diff() returns void
    language plpgsql
as
$$
BEGIN
  REFRESH MATERIALIZED VIEW bi.v_eq_available_capacity_diff;
END;
$$;

alter function refresh_v_eq_available_capacity_diff() owner to postgres;

