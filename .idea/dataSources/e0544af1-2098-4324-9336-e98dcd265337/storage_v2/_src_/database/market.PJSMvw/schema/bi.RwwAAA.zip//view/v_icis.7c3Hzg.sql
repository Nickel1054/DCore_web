create view v_icis
            ("Trading Date", "Delivery Start Day", "Delivery End Day", "Price Low", "Price Mid", "Price High",
             "Delivery Month", "Delivery Year", "Day Product Delivery Date", "Product delivery", "Index",
             "Product code", "Hub", "Product", "Product Name", "Product Type", "Product Delivery Name")
as
SELECT ib.trading_date                   AS "Trading Date",
       ib.delivery_start_date            AS "Delivery Start Day",
       ib.delivery_end_date              AS "Delivery End Day",
       ib.price_low                      AS "Price Low",
       ib.price_mid                      AS "Price Mid",
       ib.price_high                     AS "Price High",
       months.month_name_eng             AS "Delivery Month",
       ib.delivery_year                  AS "Delivery Year",
       ib.day_product_delivery           AS "Day Product Delivery Date",
       spdfnr.product_delivery_full_name AS "Product delivery",
       spdfnr.index                      AS "Index",
       gip.prod_name                     AS "Product code",
       gih.h_name                        AS "Hub",
       gip.item_id                       AS "Product",
       gip.product_name                  AS "Product Name",
       gip.product_type                  AS "Product Type",
       spdnr.product_delivery_name       AS "Product Delivery Name"
FROM icis_bi ib
         LEFT JOIN sftp_product_delivery_full_name_ref spdfnr ON spdfnr.id = ib.product_delivery_full_name
         LEFT JOIN bi.gas_icis_product gip ON gip.prod_id = ib.prod_id
         LEFT JOIN sftp_product_delivery_name_ref spdnr ON spdnr.id = ib.product_delivery_name
         LEFT JOIN bi.months ON ib.delivery_month = months.month_num
         LEFT JOIN bi.gas_icis_hub gih ON gip.h_id = gih.h_id;

alter table v_icis
    owner to postgres;

