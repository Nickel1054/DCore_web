create view v_forecast_gas_balance_test (iteration, scenario, local_datetime, utc_datetime, market, indicator, value) as
SELECT t.mfc_iteration      AS iteration,
       t.mfc_scenario       AS scenario,
       t.mfc_datetime_local AS local_datetime,
       t.mfc_datetime_utc   AS utc_datetime,
       t.mfc_market_id      AS market,
       t.mfc_indicator_id   AS indicator,
       t.val                AS value
FROM (SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             - t1.mfc_val_2 AS val
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 21
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 8
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             - t1.mfc_val_7
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 22
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 8
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 25
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 8
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 34
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 8
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_2
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 36
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 8
                                 FROM im.im_system_variables))) t;

alter table v_forecast_gas_balance_test
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_forecast_gas_balance_test to quicksight;

