create view v_gas_market_map
            (num, "Дата", "ЕДРОУП продавца", "Продавец", "Группа продавца", "Тип бизнеса продавца газа",
             "Лицензия на поставку (продавец)", "ЕДРОУП покупателя", "Покупатель", "Группа покупателя",
             "Тип бизнеса покупателя газа", "Лицензии на поставку (покупатель)", "Конечный потребитель", "Тип продукта",
             "Число сделок за месяц", "Количество тыс.м3", "Общий объём", "Цена грн/тыс.м3")
as
SELECT row_number() OVER ()                   AS num,
       t.gmpi_date                            AS "Дата",
       t2.mc_inn                              AS "ЕДРОУП продавца",
       t2.mc_name                             AS "Продавец",
       t3.description                         AS "Группа продавца",
       t4.description                         AS "Тип бизнеса продавца газа",
       t5.description                         AS "Лицензия на поставку (продавец)",
       t7.mc_inn                              AS "ЕДРОУП покупателя",
       t7.mc_name                             AS "Покупатель",
       t8.description                         AS "Группа покупателя",
       t9.description                         AS "Тип бизнеса покупателя газа",
       t10.description                        AS "Лицензии на поставку (покупатель)",
       COALESCE(t12.byuer_seller, 'no'::text) AS "Конечный потребитель",
       t13.mp_type                            AS "Тип продукта",
       t.n                                    AS "Число сделок за месяц",
       t.tot_qty                              AS "Количество тыс.м3",
       t.tot_vol                              AS "Общий объём",
       CASE
           WHEN COALESCE(t12.byuer_seller, 'no'::text) = 'no'::text THEN t.tot_vol / t.tot_qty
           ELSE t.tot_vol / t.tot_qty - (t.n::numeric * 124.16 * 1.1)::double precision
           END                                AS "Цена грн/тыс.м3"
FROM (SELECT t1.gmpi_date,
             t1.gmpi_seller_id,
             t1.gmpi_buyer_id,
             t1.gmpi_prod_id,
             count(*)         AS n,
             sum(t1.gmpi_qty) AS tot_qty,
             sum(t1.gmpi_vol) AS tot_vol
      FROM gas_market_product_info t1
      WHERE t1.gmpi_qty > 50::double precision
      GROUP BY t1.gmpi_prod_id, t1.gmpi_seller_id, t1.gmpi_buyer_id, t1.gmpi_date) t
         LEFT JOIN market_counterparty t2 ON t.gmpi_seller_id = t2.mc_id
         LEFT JOIN market_category t3 ON t2.group_ua = t3.id
         LEFT JOIN market_category t4 ON t2.type_of_business_gas = t4.id
         LEFT JOIN market_category t5 ON t2.gas_supply_license = t5.id
         LEFT JOIN market_counterparty t7 ON t.gmpi_buyer_id = t7.mc_id
         LEFT JOIN market_category t8 ON t7.group_ua = t8.id
         LEFT JOIN market_category t9 ON t7.type_of_business_gas = t9.id
         LEFT JOIN market_category t10 ON t7.gas_supply_license = t10.id
         LEFT JOIN v_market_checking_duplicates t12 ON t.gmpi_buyer_id = t12.countragent AND t.gmpi_date = t12.date
         LEFT JOIN market_product t13 ON t.gmpi_prod_id = t13.mp_id;

alter table v_gas_market_map
    owner to postgres;

