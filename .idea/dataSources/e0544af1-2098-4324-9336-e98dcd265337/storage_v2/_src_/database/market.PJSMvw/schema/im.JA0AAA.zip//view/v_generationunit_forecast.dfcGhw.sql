create view v_generationunit_forecast
            (gfc_iteration, gfc_microservice_id, gfc_market_id, gfc_indicator_id, gfc_scenario, gfc_utc_datetime,
             gfc_val_1, gfc_val_2)
as
SELECT t.gfc_iteration,
       t.gfc_microservice_id,
       t.gfc_market_id,
       t.gfc_indicator_id,
       t.gfc_scenario,
       t.gfc_utc_datetime,
       t.gfc_val_1,
       t.gfc_val_2
FROM (SELECT rank()
             OVER (PARTITION BY im_generationunit_forecast_calc.gfc_iteration, im_generationunit_forecast_calc.gfc_microservice_id, im_generationunit_forecast_calc.gfc_market_id, im_generationunit_forecast_calc.gfc_indicator_id ORDER BY im_generationunit_forecast_calc.gfc_iteration DESC, im_generationunit_forecast_calc.gfc_utc_datetime DESC) AS rn,
             im_generationunit_forecast_calc.gfc_iteration,
             im_generationunit_forecast_calc.gfc_microservice_id,
             im_generationunit_forecast_calc.gfc_market_id,
             im_generationunit_forecast_calc.gfc_indicator_id,
             im_generationunit_forecast_calc.gfc_scenario,
             im_generationunit_forecast_calc.gfc_utc_datetime,
             im_generationunit_forecast_calc.gfc_val_1,
             im_generationunit_forecast_calc.gfc_val_2
      FROM im.im_generationunit_forecast_calc) t
WHERE t.rn = 1;

alter table v_generationunit_forecast
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_generationunit_forecast to quicksight;

