create view v_epsi_download_generation_diff_mt
            ("Date Hour", "Country Code", "Scenario Name", "Scenario Run Recent", "Scenario Run Previous", "Technology",
             "Units", "Generation Recent", "Generation Previous", "Generation Difference Absolute",
             "Generation Difference Relative")
as
WITH joined_table AS (SELECT timezone('Europe/Amsterdam'::text, g.date_time)     AS date_time,
                             c.country,
                             CASE
                                 WHEN c.country = 'Denmark (West)'::text THEN 'DK1'::text
                                 WHEN c.country = 'Denmark (East)'::text THEN 'DK2'::text
                                 WHEN c.country = 'Czech Republic'::text THEN 'CZ'::text
                                 WHEN c.country = 'Bosnia Herzegovina'::text THEN 'BA'::text
                                 WHEN c.country = 'Serbia Montenegro'::text THEN 'RS'::text
                                 ELSE cs.iso_code::text
                                 END                                             AS country_code,
                             t.technology,
                             pn.property_name,
                             si.scenario_name,
                             timezone('Europe/Amsterdam'::text, sr.scenario_run) AS scenario_run,
                             u.units,
                             g.value,
                             timezone('Europe/Amsterdam'::text, i.iteration)     AS iteration,
                             fp.forecast_period,
                             tft.timeframe_type
                      FROM epsi_download_generation g
                               LEFT JOIN epsi_download_country c ON g.country = c.id
                               LEFT JOIN epsi_download_technology t ON g.technology = t.id
                               LEFT JOIN epsi_download_property_name pn ON g.property_name = pn.id
                               LEFT JOIN epsi_download_scenario_name si ON g.scenario_name = si.id
                               LEFT JOIN epsi_download_scenario_run sr ON g.scenario_run = sr.id
                               LEFT JOIN epsi_download_units u ON g.units = u.id
                               LEFT JOIN epsi_download_iteration i ON g.iteration = i.id
                               LEFT JOIN epsi_download_forecast_period fp ON g.forecast_period = fp.id
                               LEFT JOIN epsi_download_timeframe_type tft ON g.timeframe_type = tft.id
                               LEFT JOIN countries cs ON cs.country_name::text = c.country
                      WHERE tft.timeframe_type = 'MT'::text),
     max_run AS (SELECT max(joined_table.scenario_run) AS msr
                 FROM joined_table)
SELECT e1.date_time        AS "Date Hour",
       e1.country_code     AS "Country Code",
       e1.scenario_name    AS "Scenario Name",
       e1.scenario_run     AS "Scenario Run Recent",
       e2.scenario_run     AS "Scenario Run Previous",
       e1.technology       AS "Technology",
       e1.units            AS "Units",
       e1.value            AS "Generation Recent",
       e2.value            AS "Generation Previous",
       e1.value - e2.value AS "Generation Difference Absolute",
       CASE
           WHEN e2.value IS NULL OR e1.value IS NULL OR e2.value = 0::double precision THEN 0::double precision
           ELSE (e1.value - e2.value) / e2.value
           END             AS "Generation Difference Relative"
FROM joined_table e1
         JOIN joined_table e2
              ON e1.date_time = e2.date_time AND e1.country_code = e2.country_code AND e1.technology = e2.technology AND
                 e1.scenario_name = e2.scenario_name AND e1.scenario_run > e2.scenario_run AND e1.units = e2.units
WHERE e1.scenario_run = ((SELECT max_run.msr
                          FROM max_run))
  AND e2.scenario_run = ((SELECT max(joined_table.scenario_run) AS mdsr
                          FROM joined_table
                          WHERE joined_table.scenario_run < ((SELECT max_run.msr
                                                              FROM max_run))));

alter table v_epsi_download_generation_diff_mt
    owner to postgres;

