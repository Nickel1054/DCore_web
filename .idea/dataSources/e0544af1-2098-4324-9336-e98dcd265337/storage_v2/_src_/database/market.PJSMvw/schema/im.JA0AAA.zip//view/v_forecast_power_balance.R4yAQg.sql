create view v_forecast_power_balance
            ("Итерация", "Сценарий", "Местное дата-время", "Дата-время UTC", "Рынок", "Индикатор", "Значение") as
SELECT t.mfc_iteration      AS "Итерация",
       t.mfc_scenario       AS "Сценарий",
       t.mfc_datetime_local AS "Местное дата-время",
       t.mfc_datetime_utc   AS "Дата-время UTC",
       t3.country_rus       AS "Рынок",
       t4.ind_name_ru       AS "Индикатор",
       t.value              AS "Значение"
FROM (SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 8
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 9
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 10
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_2 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 11
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 12
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 13
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             - t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 17
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 37
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 38
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 39
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 40
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 41
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 42
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 43
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 44
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 45
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 46
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 47
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 48
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_local,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1 AS value
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 49
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 5
                                 FROM im.im_system_variables))) t
         LEFT JOIN im.im_market_country t2 ON t.mfc_market_id = t2.m_id AND t2.m_commodity = 1
         LEFT JOIN countries t3 ON t2.m_country = t3.id
         LEFT JOIN im.im_indicator t4 ON t.mfc_indicator_id = t4.ind_id;

alter table v_forecast_power_balance
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_forecast_power_balance to quicksight;

