create view v_world_antracite_balance(series_id, ticker, series_name_ru, d_date, value) as
SELECT t1.series_id,
       t1.ticker,
       t1.series_name_ru,
       t2.d_date,
       t2.value
FROM series_dictionary t1
         LEFT JOIN series_data t2 ON t1.series_id = t2.series_id
WHERE t1.series_id = ANY (ARRAY [123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133]);

alter table v_world_antracite_balance
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_world_antracite_balance to quicksight;

