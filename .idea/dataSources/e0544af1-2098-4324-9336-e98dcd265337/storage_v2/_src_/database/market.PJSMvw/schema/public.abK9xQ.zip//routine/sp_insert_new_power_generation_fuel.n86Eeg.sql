create procedure sp_insert_new_power_generation_fuel()
    language sql
as
$$
    INSERT INTO power_generation_fuel_info(gf_g_id,gf_f_id)
    (SELECT DISTINCT t2.g_id, t3.f_id
     FROM power_powerunits_directory_new_info t1
     LEFT JOIN power_generation_info t2 ON t1.generation_type = t2.g_type
     LEFT JOIN power_fuel_info t3 ON t1.fuel_type = t3.f_type
     EXCEPT
          (
              SELECT gf_g_id, gf_f_id FROM power_generation_fuel_info
          )
    );
$$;

alter procedure sp_insert_new_power_generation_fuel() owner to postgres;

