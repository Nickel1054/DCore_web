create view v_tge_data
            (download_timestamp, trading_date, contract_name, first_transaction_price, settlement_price, max_price,
             min_price, volume_mwh, volume_qty, volume_pln, transaction_qty, best_bid, best_ask, open_interest_mwh,
             open_interest_cont_qty, volume_from_first_trading_day, contract_qty_from_first_trading_day, load_type,
             product_type, delivery_period, delivery_year, product_name)
as
SELECT t.download_timestamp,
       t.trading_date,
       t.contract_name,
       t.first_transaction_price,
       t.settlement_price,
       t.max_price,
       t.min_price,
       t.volume_mwh,
       t.volume_qty,
       t.volume_pln,
       t.transaction_qty,
       t.best_bid,
       t.best_ask,
       t.open_interest_mwh,
       t.open_interest_cont_qty,
       t.volume_from_first_trading_day,
       t.contract_qty_from_first_trading_day,
       t.load_type,
       t.product_type,
       t.delivery_period,
       t.delivery_year,
       CASE
           WHEN t.product_type = 'Month'::text THEN (((t.load_type || ' '::text) || t.delivery_period) || ' '::text) ||
                                                    t.delivery_year
           WHEN t.product_type = 'Year'::text THEN (((t.load_type || ' '::text) || t.product_type) || ' '::text) ||
                                                   t.delivery_year
           WHEN t.product_type = 'Quarter'::text THEN
                   (((t.load_type || ' Q'::text) || t.delivery_period) || ' '::text) || t.delivery_year
           WHEN t.product_type = 'Week'::text THEN
                   (((t.load_type || ' Week '::text) || t.delivery_period::integer) || ' '::text) || t.delivery_year
           ELSE NULL::text
           END AS product_name
FROM (SELECT tge_data.download_timestamp,
             tge_data.trading_date,
             tge_data.contract_name,
             tge_data.first_transaction_price,
             tge_data.settlement_price,
             tge_data.max_price,
             tge_data.min_price,
             tge_data.volume_mwh,
             tge_data.volume_qty,
             tge_data.volume_pln,
             tge_data.transaction_qty,
             tge_data.best_bid,
             tge_data.best_ask,
             tge_data.open_interest_mwh,
             tge_data.open_interest_cont_qty,
             tge_data.volume_from_first_trading_day,
             tge_data.contract_qty_from_first_trading_day,
             "left"(tge_data.contract_name::text, 4) AS load_type,
             CASE
                 WHEN split_part(split_part(tge_data.contract_name::text, '_'::text, 2), '-'::text, 1) = 'W'::text
                     THEN 'Week'::text
                 WHEN split_part(split_part(tge_data.contract_name::text, '_'::text, 2), '-'::text, 1) = 'M'::text
                     THEN 'Month'::text
                 WHEN split_part(split_part(tge_data.contract_name::text, '_'::text, 2), '-'::text, 1) = 'Q'::text
                     THEN 'Quarter'::text
                 WHEN split_part(split_part(tge_data.contract_name::text, '_'::text, 2), '-'::text, 1) = 'Y'::text
                     THEN 'Year'::text
                 ELSE NULL::text
                 END                                 AS product_type,
             CASE
                 WHEN split_part(split_part(tge_data.contract_name::text, '_'::text, 2), '-'::text, 1) = ANY
                      (ARRAY ['W'::text, 'Q'::text]) THEN split_part(
                         split_part(tge_data.contract_name::text, '_'::text, 2), '-'::text, 2)
                 WHEN split_part(split_part(tge_data.contract_name::text, '_'::text, 2), '-'::text, 1) = 'M'::text
                     THEN btrim(to_char(
                         to_date(split_part(split_part(tge_data.contract_name::text, '_'::text, 2), '-'::text, 2),
                                 'MM'::text)::timestamp with time zone, 'Month'::text))
                 ELSE NULL::text
                 END                                 AS delivery_period,
             CASE
                 WHEN split_part(split_part(tge_data.contract_name::text, '_'::text, 2), '-'::text, 1) = 'Y'::text THEN
                         '20'::text || split_part(split_part(tge_data.contract_name::text, '_'::text, 2), '-'::text, 2)
                 WHEN split_part(split_part(tge_data.contract_name::text, '_'::text, 2), '-'::text, 1) <> 'Y'::text THEN
                         '20'::text || split_part(split_part(tge_data.contract_name::text, '_'::text, 2), '-'::text, 3)
                 ELSE NULL::text
                 END                                 AS delivery_year
      FROM bi.tge_data
      WHERE tge_data.contract_name::text ~~ 'BASE%'::text
         OR tge_data.contract_name::text ~~ 'PEAK%'::text) t;

alter table v_tge_data
    owner to postgres;

