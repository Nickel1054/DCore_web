create procedure sp_restore_all_dashboards()
    language plpgsql
as
$$
begin
CREATE OR REPLACE VIEW im.v_power_margin_costprice AS SELECT row_number() OVER () AS num,
    t.gfc_iteration AS "Итерация",
    t3.country_rus AS "Рынок",
    t4.scenario_name_ru AS "Сценарий",
    t.gfc_generationunit_id AS "ID энергоблока",
    t6.powerunit AS "Энергоблок",
    t7.generation_type_name AS "Тип генерации",
    t.gfc_val_1 AS "Марж себестоимость Евро/МВтч (val_1)",
    t.gfc_val_2 AS "Цена топлива + доставка (val_2)",
    t.gfc_val_3 AS "Топлвн сост-я Евро/МВтч (val_3)",
    t.gfc_val_4 AS "Цена эквивалента CO2 (val_4)",
    t.gfc_val_5 AS "Эко составляющая Евро/МВтч (val_5)",
    t.gfc_val_6 AS "Прочая выручка -Евро/МВтч (val_6)",
    t.gfc_val_7 AS "Прочие затраты +Евро/МВтч (val_7)",
    t.gfc_val_8 AS "val 8",
    t.gfc_utc_datetime AS "Дата время UTC"
   FROM (((((( SELECT rank() OVER (PARTITION BY t1.gfc_iteration, t1.gfc_generationunit_id, t1.gfc_scenario ORDER BY t1.gfc_iteration DESC, t1.gfc_utc_datetime DESC) AS rn,
            t1.gfc_iteration,
            t1.gfc_market_id,
            t1.gfc_scenario,
            t1.gfc_generationunit_id,
            t1.gfc_val_1,
            t1.gfc_val_2,
            t1.gfc_val_3,
            t1.gfc_val_4,
            t1.gfc_val_5,
            t1.gfc_val_6,
            t1.gfc_val_7,
            t1.gfc_val_8,
            t1.gfc_utc_datetime
           FROM im.im_generationunit_forecast_calc t1
          WHERE ((t1.gfc_indicator_id = 14) AND (t1.gfc_scenario = ANY (ARRAY[1, 2, 3])) AND (t1.gfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))) t
     LEFT JOIN im.im_market_country t2 ON (((t.gfc_market_id = t2.m_id) AND (t2.m_commodity = 1))))
     LEFT JOIN bi.countries t3 ON ((t2.m_country = t3.id)))
     LEFT JOIN im.im_scenario t4 ON ((t.gfc_scenario = t4.scenario_id)))
     LEFT JOIN im.power_powerunit_info t6 ON ((t.gfc_generationunit_id = t6.unit_id)))
     LEFT JOIN power_generation_type_info_entsoe t7 ON ((t6.generation_id = t7.generation_type_id)))
  WHERE (t.rn = 1);
CREATE OR REPLACE VIEW im.v_gas_pipeline_maintenance AS SELECT t1.gm_id AS "N",
    t2.name AS "Интерконнектор",
    t1.p_name AS "Название",
    t1.gm_category AS "Ремонт",
    t1.gm_impact_value_mwy AS "Мощность",
    t1.gm_forecast_date AS "Прогнозная дата",
    t1.gm_start_date AS "Дата начала",
    t1.gm_end_date AS "Дата окончания",
    t1.is_working AS "Работающий",
    t1.gm_source AS "Источник",
    COALESCE(t1.gm_note, ''::character varying) AS "Примечание"
   FROM (im.gas_pipeline_maintenance_info t1
     LEFT JOIN im.gas_interconn_info t2 ON ((t1.gm_gaspoint_id = t2.id)));
CREATE OR REPLACE VIEW im.v_generationunit_forecast AS SELECT t.gfc_iteration,
    t.gfc_microservice_id,
    t.gfc_market_id,
    t.gfc_indicator_id,
    t.gfc_scenario,
    t.gfc_utc_datetime,
    t.gfc_val_1,
    t.gfc_val_2
   FROM ( SELECT rank() OVER (PARTITION BY im_generationunit_forecast_calc.gfc_iteration, im_generationunit_forecast_calc.gfc_microservice_id, im_generationunit_forecast_calc.gfc_market_id, im_generationunit_forecast_calc.gfc_indicator_id ORDER BY im_generationunit_forecast_calc.gfc_iteration DESC, im_generationunit_forecast_calc.gfc_utc_datetime DESC) AS rn,
            im_generationunit_forecast_calc.gfc_iteration,
            im_generationunit_forecast_calc.gfc_microservice_id,
            im_generationunit_forecast_calc.gfc_market_id,
            im_generationunit_forecast_calc.gfc_indicator_id,
            im_generationunit_forecast_calc.gfc_scenario,
            im_generationunit_forecast_calc.gfc_utc_datetime,
            im_generationunit_forecast_calc.gfc_val_1,
            im_generationunit_forecast_calc.gfc_val_2
           FROM im.im_generationunit_forecast_calc) t
  WHERE (t.rn = 1);
CREATE OR REPLACE VIEW im.v_gas_impex_eu AS SELECT t1.gif_iteration AS iteration,
    t4.country_rus AS source,
    t6.country_rus AS destination,
    t1.gif_scenario AS scenario,
        CASE
            WHEN ((t1.gif_type)::text = 'I'::text) THEN 'Импорт'::text
            WHEN ((t1.gif_type)::text = 'E'::text) THEN 'Экспорт'::text
            ELSE NULL::text
        END AS import_export,
        CASE
            WHEN (t1.gif_indicator = 27) THEN (- t1.gif_val_1)
            WHEN (t1.gif_indicator = 26) THEN t1.gif_val_1
            ELSE NULL::double precision
        END AS mwh,
    t1.gif_utc_datetime_src AS src_datetime,
    t1.gif_utc_datetime_dst AS dst_datetime
   FROM ((((im.im_gas_impex_forecast_calc t1
     LEFT JOIN im.im_market_country t3 ON (((t1.gif_src = t3.m_id) AND (t3.m_commodity = 2))))
     LEFT JOIN bi.countries t4 ON ((t3.m_country = t4.id)))
     LEFT JOIN im.im_market_country t5 ON (((t1.gif_dst = t5.m_id) AND (t5.m_commodity = 2))))
     LEFT JOIN bi.countries t6 ON ((t5.m_country = t6.id)))
  WHERE (t1.gif_indicator = ANY (ARRAY[26, 27]));
CREATE OR REPLACE VIEW im.v_forecast_market_calc AS SELECT t.mfc_iteration,
    t.mfc_market_id,
    t.mfc_microservice_id,
    t.mfc_indicator_id,
    t.mfc_scenario,
    t.mfc_datetime_utc
   FROM ( SELECT rank() OVER (PARTITION BY im_markets_forecast_calc.mfc_iteration, im_markets_forecast_calc.mfc_microservice_id, im_markets_forecast_calc.mfc_market_id, im_markets_forecast_calc.mfc_indicator_id ORDER BY im_markets_forecast_calc.mfc_iteration DESC, im_markets_forecast_calc.mfc_datetime_utc DESC) AS rn,
            im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_microservice_id,
            im_markets_forecast_calc.mfc_indicator_id,
            im_markets_forecast_calc.mfc_datetime_utc,
            im_markets_forecast_calc.mfc_scenario
           FROM im.im_markets_forecast_calc) t
  WHERE (t.rn = 1);
CREATE OR REPLACE VIEW im.v_power_import_export AS SELECT t.eif_iteration AS "Итерация",
    t.eif_mcrsrvc AS "Микросервис",
    t.eif_type AS "Тип",
    t3.country_rus AS "Из страны",
    t4.country_rus AS "В страну",
    t6.ind_name_ru AS "Индикатор",
    t5.scenario_name_ru AS "Сценарий",
    t.eif_val_1 AS "Значение 1",
    t.eif_val_2 AS "Значение 2",
    t.eif_val_3 AS "Значение 3",
    t.eif_val_4 AS "Значение 4",
    t.eif_val_5 AS "Значение 5",
    t.eif_val_6 AS "Значение 6",
    t.eif_val_7 AS "Значение 7",
    t.eif_val_8 AS "Значение 8",
    t.eif_utc_datetime AS "Время UTC"
   FROM ((((((( SELECT rank() OVER (PARTITION BY im_electr_impex_forecast_calc.eif_iteration, im_electr_impex_forecast_calc.eif_mcrsrvc, im_electr_impex_forecast_calc.eif_indicator, im_electr_impex_forecast_calc.eif_scenario, im_electr_impex_forecast_calc.eif_src, im_electr_impex_forecast_calc.eif_dst ORDER BY im_electr_impex_forecast_calc.eif_iteration DESC, im_electr_impex_forecast_calc.eif_utc_datetime DESC) AS rn,
            im_electr_impex_forecast_calc.eif_iteration,
            im_electr_impex_forecast_calc.eif_mcrsrvc,
            im_electr_impex_forecast_calc.eif_type,
            im_electr_impex_forecast_calc.eif_src,
            im_electr_impex_forecast_calc.eif_dst,
            im_electr_impex_forecast_calc.eif_indicator,
            im_electr_impex_forecast_calc.eif_scenario,
            im_electr_impex_forecast_calc.eif_val_1,
            im_electr_impex_forecast_calc.eif_val_2,
            im_electr_impex_forecast_calc.eif_val_3,
            im_electr_impex_forecast_calc.eif_val_4,
            im_electr_impex_forecast_calc.eif_val_5,
            im_electr_impex_forecast_calc.eif_val_6,
            im_electr_impex_forecast_calc.eif_val_7,
            im_electr_impex_forecast_calc.eif_val_8,
            im_electr_impex_forecast_calc.eif_utc_datetime
           FROM im.im_electr_impex_forecast_calc) t
     LEFT JOIN im.im_market_country t1 ON (((t.eif_src = t1.m_id) AND (t1.m_commodity = 1))))
     LEFT JOIN im.im_market_country t2 ON (((t.eif_dst = t2.m_id) AND (t2.m_commodity = 1))))
     LEFT JOIN bi.countries t3 ON ((t1.m_country = t3.id)))
     LEFT JOIN bi.countries t4 ON ((t2.m_country = t4.id)))
     LEFT JOIN im.im_scenario t5 ON ((t.eif_scenario = t5.scenario_id)))
     LEFT JOIN im.im_indicator t6 ON ((t.eif_indicator = t6.ind_id)))
  WHERE (t.rn = 1);
CREATE OR REPLACE VIEW im.v_forecast_power_balance_new AS SELECT t.mfc_iteration AS "Итерация",
    t.scenario_name_ru AS "Сценарий",
    t.mfc_datetime_local AS "Местное время",
    t.mfc_datetime_utc AS "Время UTC",
    t.country_rus AS "Страна",
    t.ind_name_ru AS "Индикатор",
    t.mfc_val_1 AS "Значение 1",
    t.mfc_val_2 AS "Значение 2"
   FROM ( SELECT rank() OVER (PARTITION BY t1.mfc_iteration, t1.mfc_market_id, t1.mfc_scenario ORDER BY t1.mfc_iteration DESC, t1.mfc_datetime_utc DESC) AS rn,
            t1.mfc_iteration,
            t2.scenario_name_ru,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t4.country_rus,
            t5.ind_name_ru,
            t1.mfc_val_1,
            t1.mfc_val_2
           FROM ((((im.im_markets_forecast_calc t1
             LEFT JOIN im.im_scenario t2 ON ((t1.mfc_scenario = t2.scenario_id)))
             LEFT JOIN im.im_market_country t3 ON ((t1.mfc_market_id = t3.m_id)))
             LEFT JOIN bi.countries t4 ON ((t3.m_country = t4.id)))
             LEFT JOIN im.im_indicator t5 ON ((t1.mfc_indicator_id = t5.ind_id)))
          WHERE ((t1.mfc_indicator_id = ANY (ARRAY[8, 9, 11, 12, 13, 17])) AND (t1.mfc_iteration >= 200))) t
  WHERE (t.rn = 1);
CREATE OR REPLACE VIEW im.v_forecast_market_calc_last_iteration AS SELECT t.mfc_iteration AS "Итерация",
    t.country_rus AS "Рынок",
    t.ms_name AS "Микросервис",
    t.ind_name_ru AS "Индикатор",
    t.scenario_name_ru AS "Сценарий",
    t.mfc_datetime_utc AS "Время UTC",
    t.mfc_val_1 AS "Значение 1",
    t.mfc_val_2 AS "Значение 2",
    t.mfc_val_3 AS "Значение 3",
    t.mfc_val_4 AS "Значение 4",
    t.mfc_val_5 AS "Значение 5",
    t.mfc_val_6 AS "Значение 6",
    t.mfc_val_7 AS "Значение 7",
    t.mfc_val_8 AS "Значение 8"
   FROM ( SELECT rank() OVER (PARTITION BY t1.mfc_iteration, t1.mfc_microservice_id, t1.mfc_market_id, t1.mfc_indicator_id ORDER BY t1.mfc_iteration DESC, t1.mfc_datetime_utc DESC) AS rn,
            t1.mfc_iteration,
            t6.country_rus,
            t3.ms_name,
            t4.ind_name_ru,
            t1.mfc_datetime_utc,
            t5.scenario_name_ru,
            t1.mfc_val_1,
            t1.mfc_val_2,
            t1.mfc_val_3,
            t1.mfc_val_4,
            t1.mfc_val_5,
            t1.mfc_val_6,
            t1.mfc_val_7,
            t1.mfc_val_8
           FROM (((((im.im_markets_forecast_calc t1
             LEFT JOIN im.im_market_country t2 ON ((t1.mfc_market_id = t2.m_id)))
             LEFT JOIN bi.countries t6 ON ((t2.m_country = t6.id)))
             LEFT JOIN im.im_microservice t3 ON ((t1.mfc_microservice_id = t3.ms_id)))
             LEFT JOIN im.im_indicator t4 ON ((t1.mfc_indicator_id = t4.ind_id)))
             LEFT JOIN im.im_scenario t5 ON ((t1.mfc_scenario = t5.scenario_id)))) t
  WHERE ((t.rn = 1) AND (t.mfc_iteration >= ( SELECT (im_system_variables.max_iter - 5)
           FROM im.im_system_variables)));
CREATE OR REPLACE VIEW im.v_lng_ltc_contracts AS SELECT t1.ltc_id AS id,
    t2.country_rus AS "Страна экспортёр",
    t3.name AS "СПГ завод",
    t1.status AS "Статус",
    t4.cp_name AS "Экспортёр",
    t5.cp_name AS "Покупатель",
    t6.country_rus AS "Страна импортёр",
    t1.sign_date AS "Дата подписания",
    t1.start_date AS "Дата начала поставок",
    t1.start_date_ihs AS "Дата начала поставок по IHS",
    t1.end_date AS "Дата окончания поставок",
    t1.contract_type AS "Тип контракта",
    t1.terms AS "Условия поставки",
    t1.dest_flex AS "Фиксированная точка поставки",
    t1.volume_mmtpa AS "Объём ММТра",
    t1.volume_bcma AS "Объём ВСМ/а",
    t1.volume_mwhd AS "Объём MWh/d"
   FROM (((((im.gas_lng_ltc_contracts t1
     LEFT JOIN bi.countries t2 ON ((t1.country_exporter = t2.id)))
     LEFT JOIN im.gas_lng_plants_projects t3 ON ((t1.lng_plant = t3.id)))
     LEFT JOIN im.gas_counterparty_info t4 ON ((t1.exporter = t4.cp_id)))
     LEFT JOIN im.gas_counterparty_info t5 ON ((t1.buyer = t5.cp_id)))
     LEFT JOIN bi.countries t6 ON ((t1.country_importer = t6.id)));
CREATE OR REPLACE VIEW im.v_crosscountry_powersection AS SELECT t1.ccs_id,
    t1.ccs_out,
    t1.ccs_in,
    t1.ccs_mwt,
    t1.ccs_scenario,
    t1.ccs_startdate,
    t1.ccs_enddate,
    (((t2.iso_code)::text || '_'::text) || (t3.iso_code)::text) AS country_couple
   FROM ((im.im_crosscountry_power_section t1
     LEFT JOIN bi.countries t2 ON ((t1.ccs_out = t2.id)))
     LEFT JOIN bi.countries t3 ON ((t1.ccs_in = t3.id)));
CREATE OR REPLACE VIEW im.v_forecasted_european_gas_balance AS SELECT t.iteration AS "Итерация",
    t.scenario AS "Сценарий",
    t3.country_rus AS "Рынок",
    t1.ind_name_ru AS "Индикатор",
    t.type AS "Тип",
    t.value AS "Значение",
    t.dtutc AS "Дата-время UTC"
   FROM (((( SELECT im_markets_forecast_calc.mfc_iteration AS iteration,
            im_markets_forecast_calc.mfc_scenario AS scenario,
            im_markets_forecast_calc.mfc_market_id AS market,
            im_markets_forecast_calc.mfc_indicator_id AS indicator,
            'Потребление без учета газовой генерации, МВтч'::text AS type,
            (- im_markets_forecast_calc.mfc_val_2) AS value,
            im_markets_forecast_calc.mfc_datetime_utc AS dtutc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 2) AND (im_markets_forecast_calc.mfc_indicator_id = 21) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (im_system_variables.max_iter - 8)
                   FROM im.im_system_variables)) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            0,
            im_markets_forecast_calc.mfc_indicator_id,
            'Суммарное потребление газа, МВтч'::text,
            (- sum(im_markets_forecast_calc.mfc_val_7)),
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 2) AND (im_markets_forecast_calc.mfc_indicator_id = 22) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (im_system_variables.max_iter - 8)
                   FROM im.im_system_variables)) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
          GROUP BY im_markets_forecast_calc.mfc_iteration, im_markets_forecast_calc.mfc_scenario, im_markets_forecast_calc.mfc_commodity_id, im_markets_forecast_calc.mfc_indicator_id, im_markets_forecast_calc.mfc_datetime_utc
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            0,
            im_markets_forecast_calc.mfc_indicator_id,
            'Суммарная разница между выкачкой и закачкой в сутки'::text,
            sum((im_markets_forecast_calc.mfc_val_4 - im_markets_forecast_calc.mfc_val_3)) AS sum,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 2) AND (im_markets_forecast_calc.mfc_indicator_id = 31) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (im_system_variables.max_iter - 8)
                   FROM im.im_system_variables)) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
          GROUP BY im_markets_forecast_calc.mfc_iteration, im_markets_forecast_calc.mfc_scenario, im_markets_forecast_calc.mfc_commodity_id, im_markets_forecast_calc.mfc_indicator_id, im_markets_forecast_calc.mfc_datetime_utc
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            0,
            im_markets_forecast_calc.mfc_indicator_id,
            'Cуммарная добыча газа в час'::text,
            sum(im_markets_forecast_calc.mfc_val_1) AS sum,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 2) AND (im_markets_forecast_calc.mfc_indicator_id = 25) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (im_system_variables.max_iter - 8)
                   FROM im.im_system_variables)) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
          GROUP BY im_markets_forecast_calc.mfc_iteration, im_markets_forecast_calc.mfc_scenario, im_markets_forecast_calc.mfc_commodity_id, im_markets_forecast_calc.mfc_indicator_id, im_markets_forecast_calc.mfc_datetime_utc
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            'Суммарный объем заявок импорта внешнего газа'::text,
            im_markets_forecast_calc.mfc_val_8,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 2) AND (im_markets_forecast_calc.mfc_indicator_id = 36) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (im_system_variables.max_iter - 8)
                   FROM im.im_system_variables)) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            0,
            im_markets_forecast_calc.mfc_indicator_id,
            'Суммарный объём заявок по СПГ'::text,
            sum(im_markets_forecast_calc.mfc_val_8) AS sum,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 2) AND (im_markets_forecast_calc.mfc_indicator_id = 34) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (im_system_variables.max_iter - 8)
                   FROM im.im_system_variables)) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
          GROUP BY im_markets_forecast_calc.mfc_iteration, im_markets_forecast_calc.mfc_scenario, im_markets_forecast_calc.mfc_commodity_id, im_markets_forecast_calc.mfc_indicator_id, im_markets_forecast_calc.mfc_datetime_utc) t
     LEFT JOIN im.im_indicator t1 ON ((t.indicator = t1.ind_id)))
     LEFT JOIN im.im_market_country t2 ON (((t.market = t2.m_id) AND (t2.m_commodity = 2))))
     LEFT JOIN bi.countries t3 ON ((t2.m_country = t3.id)));
create or replace view im.v_power_market_price("Итерация", "Рынок", "Сценарий", "Значение", "Дата-время UTC") as
SELECT t.mfc_iteration    AS "Итерация",
       t1.tdz_name        AS "Рынок",
       t.mfc_scenario     AS "Сценарий",
       t.mfc_val_2        AS "Значение",
       t.mfc_datetime_utc AS "Дата-время UTC"
FROM im.im_markets_forecast_calc_tradezone t
LEFT JOIN im.im_tradezone t1 ON t.mfc_tradezone = t1.tdz_id AND t1.tdz_commodity = 1
WHERE t.mfc_commodity_id = 1
  AND t.mfc_indicator_id = 19
  AND t.mfc_iteration > ((SELECT im_system_variables.max_iter - 8
                          FROM im.im_system_variables));
CREATE OR REPLACE VIEW im.v_gas_demand_price_forecast AS SELECT t.gdp_iteration AS "Итерация",
    t.gdp_mcrsrvc AS "Микросервис",
    t2.country_rus AS "Рынок",
    t.gdp_indicator AS "Индикатор",
    t.gdp_scenario AS "Сценарий",
    t.gdp_object_id AS "Код объекта",
    t.gdp_order_id AS "Поряд.№ заявки",
    t.gdp_order_rank AS "Ранг заявки",
    t.gdp_utc_datetime AS "Время UTC",
    t.gdp_val_1 AS "Объём заявки",
    t.gdp_val_2 AS "Цена заявки",
    t.gdp_val_8 AS "Акцептованный объём заявки"
   FROM ((( SELECT rank() OVER (PARTITION BY im_gas_demand_price_forecast_calc.gdp_iteration, im_gas_demand_price_forecast_calc.gdp_mcrsrvc, im_gas_demand_price_forecast_calc.gdp_market, im_gas_demand_price_forecast_calc.gdp_indicator, im_gas_demand_price_forecast_calc.gdp_scenario, im_gas_demand_price_forecast_calc.gdp_object_id, im_gas_demand_price_forecast_calc.gdp_order_id, im_gas_demand_price_forecast_calc.gdp_order_rank ORDER BY im_gas_demand_price_forecast_calc.gdp_iteration DESC, im_gas_demand_price_forecast_calc.gdp_utc_datetime DESC) AS rn,
            im_gas_demand_price_forecast_calc.gdp_iteration,
            im_gas_demand_price_forecast_calc.gdp_mcrsrvc,
            im_gas_demand_price_forecast_calc.gdp_market,
            im_gas_demand_price_forecast_calc.gdp_indicator,
            im_gas_demand_price_forecast_calc.gdp_scenario,
            im_gas_demand_price_forecast_calc.gdp_object_id,
            im_gas_demand_price_forecast_calc.gdp_order_id,
            im_gas_demand_price_forecast_calc.gdp_order_rank,
            im_gas_demand_price_forecast_calc.gdp_utc_datetime,
            im_gas_demand_price_forecast_calc.gdp_val_1,
            im_gas_demand_price_forecast_calc.gdp_val_2,
            im_gas_demand_price_forecast_calc.gdp_val_8
           FROM im.im_gas_demand_price_forecast_calc) t
     LEFT JOIN im.im_market_country t1 ON (((t.gdp_market = t1.m_id) AND (t1.m_commodity = 2))))
     LEFT JOIN bi.countries t2 ON ((t1.m_country = t2.id)))
  WHERE (t.rn = 1);
CREATE OR REPLACE VIEW im.v_powerunits_gaes_battery AS SELECT t0.unit_id AS "ID энергоблока",
    t0.powerunit AS "Энергоблок",
    t0.eic_code AS "Код энергоблока",
    b1.country_rus AS "Страна",
    t0.owner AS "Владелец",
    b2.generation_type_name AS "Тип генерации",
    t0.status AS "Статус",
    t0.powerunit_output_mw AS "Мощность МВтч",
    t0.start_date AS "Начало эксплуатации",
    t0.end_date AS "Конец эксплуатации",
    t0.hpp_min_capacity AS "Мин ёмкость резервуара/батареи МВ",
    t0.hpp_max_capacity AS "Макс ёмкость резервуара/батареи М",
    t0.hpp_min_injection_rate AS "Минимальный темп закачки МВтч/ч",
    t0.hpp_max_injection_rate AS "Максимальный темп закачки МВтч/ч",
    t0.hpp_calculated_min_capacity AS "Мин. расчётная ёмкость резервуара/",
    t0.hpp_calculated_max_capacity AS "Макс. расчётная ёмкость резервуар",
    t0.effectiveness AS "Эффективность"
   FROM ((im.powerunit_battery_gaes t0
     LEFT JOIN bi.countries b1 ON ((t0.country = b1.id)))
     LEFT JOIN power_generation_type_info_entsoe b2 ON ((t0.gen_id = b2.generation_type_id)));
CREATE OR REPLACE VIEW im.v_gas_interconn_full AS SELECT t1.id AS "ID",
    t1.name AS "Интерконнектор",
    t3.status AS "Статус",
    t1.direction AS "Направление",
    t4.country_rus AS "Из страны",
    t5.country_rus AS "В страну",
    t1.operator AS "Оператор",
    t1.unique_operator AS "Уникальный оператор",
    t1.max_capacity AS "Макс проп способность МВтч в день",
    t1.comments AS "Примечание",
    t2.start_date AS "Дата начала",
    t2.end_date AS "Дата окончания",
    t6.scenario_name_ru AS "Сценарий",
    t2.capacity AS "Пропускная способность МВтч в ден"
   FROM (((((im.gas_interconn_info t1
     LEFT JOIN im.gas_interconn_timeperiod t2 ON ((t1.id = t2.id_interconn)))
     LEFT JOIN im.gas_interconn_status t3 ON ((t1.status = t3.id)))
     LEFT JOIN bi.countries t4 ON ((t1.country_from = t4.id)))
     LEFT JOIN bi.countries t5 ON ((t1.country_to = t5.id)))
     LEFT JOIN im.im_scenario t6 ON ((t2.scenario = t6.scenario_id)));
CREATE OR REPLACE VIEW im.v_gas_interconn AS SELECT t1.id AS "ID",
    t1.name AS "Интерконнектор",
    COALESCE(t1.pipeline_name, ''::character varying) AS "Газопровод",
    t3.status AS "Статус",
    t1.direction AS "Направление",
    t4.country_rus AS "Из страны",
    t5.country_rus AS "В страну",
    t1.operator AS "Оператор",
    t1.unique_operator AS "Уникальный оператор",
    t1.max_capacity AS "Макс проп способность МВтч в день",
    t1.comments AS "Примечание"
   FROM (((im.gas_interconn_info t1
     LEFT JOIN im.gas_interconn_status t3 ON ((t1.status = t3.id)))
     LEFT JOIN bi.countries t4 ON ((t1.country_from = t4.id)))
     LEFT JOIN bi.countries t5 ON ((t1.country_to = t5.id)));
CREATE OR REPLACE VIEW im.v_gas_pipeline_ltc AS SELECT t1.id AS "LTC ID",
    t2.cp_name AS "Поставщик",
    t3.country_rus AS "Страна покупателя",
    t4.id AS "subcontract ID",
    t5.name AS "Интерконнектор",
    t4.start_date AS "Начало контракта",
    t4.end_date AS "Окончание контракта",
    t4.fixed_vol_mwd AS "Фиксированный объём",
    COALESCE((t4.float_vol_mwd)::text, ''::text) AS "Плавающий объём"
   FROM ((((im.gas_pipeline_ltc_info t1
     LEFT JOIN im.gas_counterparty_info t2 ON ((t1.supplier = t2.cp_id)))
     LEFT JOIN bi.countries t3 ON ((t1.buyer_country = t3.id)))
     LEFT JOIN im.gas_pipeline_ltc_timeperiod_aux t4 ON ((t1.id = t4.ltc_id)))
     LEFT JOIN im.gas_interconn_info t5 ON ((t4.interconn_id = t5.id)));
CREATE OR REPLACE VIEW im.v_regas_terminal AS SELECT t1.rgp_name AS "Проект",
    t2.country_rus AS "Страна",
    t3.rgt_name AS "Терминал",
    t4.rgt_name AS "Оператор",
    t3.rgt_status AS "Статус",
    t3.rgt_type AS "Тип",
    t3.rgt_startup AS "Начало эксплуатации",
    t3.rgt_losscap_mtpa AS "Мощность в млн.т в год",
    t3.rgt_losscap_mwhd AS "Мощность в МВтч в день",
    t3.rgt_losscap_mcmd AS "Мощность в млн. м3 в день",
    t3.rgt_storage_mcm AS "Объём хранилища в млн. м3",
    t3.rgt_3pta AS "Доступ третьих сторон"
   FROM (((im.gas_rgt_project_info t1
     LEFT JOIN bi.countries t2 ON ((t1.rgp_country = t2.id)))
     LEFT JOIN im.gas_rgt_terminal_info t3 ON ((t1.rgp_id = t3.rgt_project)))
     LEFT JOIN im.gas_rgt_operator_info t4 ON ((t3.operator_id = t4.rgt_oid)));
CREATE OR REPLACE VIEW im.v_gas_costprice AS SELECT row_number() OVER () AS num,
    t1.mfc_iteration AS "Итерация",
    t3.country_rus AS "Рынок",
    t4.scenario_name_ru AS "Сценарий",
    t1.mfc_val_1 AS "Равновесная цена газа",
    t1.mfc_datetime_utc AS "Дата время UTC"
   FROM (((im.im_markets_forecast_calc t1
     LEFT JOIN im.im_market_country t2 ON (((t1.mfc_market_id = t2.m_id) AND (t2.m_commodity = 2))))
     LEFT JOIN bi.countries t3 ON ((t2.m_country = t3.id)))
     LEFT JOIN im.im_scenario t4 ON ((t1.mfc_scenario = t4.scenario_id)))
  WHERE ((t1.mfc_indicator_id = 23) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 8)
           FROM im.im_system_variables)));
CREATE OR REPLACE VIEW im.v_power_demand_price_forecast AS SELECT row_number() OVER () AS num,
    t.edp_iteration AS "Итерация",
    t.edp_mcrsrvc AS "Микросервис",
    t.edp_indicator AS "Индикатор",
    t.edp_market AS "Рынок",
    t.edp_scenario AS "Сценарий",
    t.edp_object_id AS "Object ID",
    t.edp_order_id AS "Order ID",
    t.edp_order_rank AS "Order rank",
    t.edp_gt_id AS "Generation type",
    t.edp_val_1 AS "Объём заявки",
    t.edp_val_2 AS "Цена заявки Евро/МВтч",
    t.edp_val_3 AS "расчёт цен в национальных валютах",
    t.edp_val_4 AS "Прогноз/факт выбросов по заявке, в ",
    t.edp_val_5 AS "Прогноз/факт сожженного топлива п",
    t.edp_val_6 AS "Прогноз/факт выбросов по удовлетв",
    t.edp_val_7 AS "Прогноз/факт сожж топлива по удовл",
    t.edp_val_8 AS "Удовлетворённый объём заявки в МВ",
    t.edp_utc_datetime AS "Время UTC"
   FROM ( SELECT rank() OVER (PARTITION BY t1.edp_iteration, t1.edp_mcrsrvc, t1.edp_indicator, t1.edp_market, t1.edp_scenario, t1.edp_object_id, t1.edp_order_id, t1.edp_order_rank, t1.edp_gt_id ORDER BY t1.edp_iteration DESC, t1.edp_utc_datetime DESC) AS rn,
            t1.edp_iteration,
            t1.edp_mcrsrvc,
            t1.edp_indicator,
            t1.edp_market,
            t1.edp_scenario,
            t1.edp_utc_datetime,
            t1.edp_object_id,
            t1.edp_order_id,
            t1.edp_order_rank,
            t1.edp_gt_id,
            t1.edp_val_1,
            t1.edp_val_2,
            t1.edp_val_3,
            t1.edp_val_4,
            t1.edp_val_5,
            t1.edp_val_6,
            t1.edp_val_7,
            t1.edp_val_8
           FROM im.im_electr_demand_price_forecast_calc t1
          WHERE (t1.edp_iteration > ( SELECT (im_system_variables.max_iter - 6)
                   FROM im.im_system_variables))) t
  WHERE (t.rn = 1);
CREATE OR REPLACE VIEW im.v_power_generation_by_unit AS SELECT row_number() OVER () AS num,
    t.gfc_iteration AS "Итерация",
    t.gfc_scenario AS "Сценарий",
    t.gfc_utc_datetime AS "Дата-время UTC",
    t.gfc_market_id AS "Рынок",
    t.gfc_generationunit_id AS "ID энергоблока",
    t.gfc_indicator_id AS "Индикатор",
    t.gfc_val_1 AS "Доступная генерация в МВт",
    t.gfc_val_2 AS "Ген + ремонты МВт",
    t.gfc_val_3 AS "Ген + климат огранич МВт"
   FROM ( SELECT rank() OVER (PARTITION BY t1.gfc_iteration, t1.gfc_scenario, t1.gfc_generationunit_id ORDER BY t1.gfc_iteration DESC, t1.gfc_utc_datetime DESC) AS rn,
            t1.gfc_iteration,
            t1.gfc_scenario,
            t1.gfc_utc_datetime,
            t1.gfc_market_id,
            t1.gfc_generationunit_id,
            t1.gfc_indicator_id,
            t1.gfc_val_1,
            t1.gfc_val_2,
            t1.gfc_val_3
           FROM im.im_generationunit_forecast_calc t1
          WHERE ((t1.gfc_indicator_id = 15) AND (t1.gfc_id > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))) t
  WHERE (t.rn = 1);
CREATE OR REPLACE VIEW im.v_powerunits_directory AS SELECT row_number() OVER () AS num,
    t1.station AS "Станция",
    t1.eic_code AS "EIC код станции",
    t1.owner AS "Владелец",
    t4.country_rus AS "Страна",
    t2.unit_id AS "ID энергоблока",
    t2.powerunit AS "Энергоблок",
    t2.eic_code AS "EIC код энергоблока",
    t5.generation_type_name AS "Тип генерации",
    t2.powerunit_status AS "Статус энергоблока",
    t2.powerunit_output_mw AS "Мощность энергоблока",
    t2.effectiveness AS "Эффективность энергоблока",
    t2.heat_output_mw AS "Тепловая мощность",
    t2.chp_mode AS "Режим CHP",
    t2.co2_pollution AS "Выбросы CO2",
    t2.start_date AS "Начало эксплуатации",
    t2.end_date AS "Конец эксплуатации",
    t2.min_generation_mwh AS "Минимальная генерация МВтч",
    t2.max_generation_mwh AS "Максимальная генерация МВтч",
    t2.max_generation_mw AS "Максимальная генерация МВт",
    t2.power_mw_balkan AS "Мощность Balkan МВт",
    t2.startup_cost AS "Стоимость запуска",
    t2.startup_rate AS "Скорость запуска",
    t2.data_source AS "Источник данных",
    t2.icis_end_date AS "Срок окончания эксплуатации ICIS",
    t2.forecasted_end_date AS "Прогнозируемый срок окончания экс",
    t3.benchmark AS "Удельные выбросы СО2 МВтч",
    t2.must_run AS "Must run",
    t2.note AS "Примечания"
   FROM ((((im.power_powerstation_info t1
     LEFT JOIN im.power_powerunit_info t2 ON ((t2.station_id = t1.id)))
     LEFT JOIN im.power_co2_info t3 ON (((t2.eic_code)::text = (t3.powerunit_eic_code)::text)))
     LEFT JOIN bi.countries t4 ON ((t1.country = t4.id)))
     LEFT JOIN power_generation_type_info_entsoe t5 ON ((t2.generation_id = t5.generation_type_id)));
CREATE OR REPLACE VIEW im.v_forecasted_physical_gas_balance AS SELECT t.mfc_iteration AS "Итерация",
    t.mfc_scenario AS "Сценарий",
    t1.ind_name_ru AS "Индикатор",
    t3.country_rus AS "Рынок",
    t.value AS "Значение",
    t.mfc_datetime_utc AS "Дата-время UTC"
   FROM (((( SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            (- im_markets_forecast_calc.mfc_val_2) AS value,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 2) AND (im_markets_forecast_calc.mfc_indicator_id = 21) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (sys_var.max_iter - 5)
                   FROM im.sys_var
                  WHERE (sys_var.indicator = 21))))
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            (- im_markets_forecast_calc.mfc_val_7) AS value,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 2) AND (im_markets_forecast_calc.mfc_indicator_id = 22) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (sys_var.max_iter - 5)
                   FROM im.sys_var
                  WHERE (sys_var.indicator = 22))) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            (- im_markets_forecast_calc.mfc_val_1) AS value,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 2) AND (im_markets_forecast_calc.mfc_indicator_id = 27) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (sys_var.max_iter - 5)
                   FROM im.sys_var
                  WHERE (sys_var.indicator = 27))) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            (- im_markets_forecast_calc.mfc_val_3) AS value,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 2) AND (im_markets_forecast_calc.mfc_indicator_id = 31) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (sys_var.max_iter - 5)
                   FROM im.sys_var
                  WHERE (sys_var.indicator = 31))) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            im_markets_forecast_calc.mfc_val_1 AS value,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 2) AND (im_markets_forecast_calc.mfc_indicator_id = 25) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (sys_var.max_iter - 5)
                   FROM im.sys_var
                  WHERE (sys_var.indicator = 25))) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            im_markets_forecast_calc.mfc_val_8 AS value,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 2) AND (im_markets_forecast_calc.mfc_indicator_id = 36) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (sys_var.max_iter - 5)
                   FROM im.sys_var
                  WHERE (sys_var.indicator = 36))) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            im_markets_forecast_calc.mfc_val_4 AS value,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 2) AND (im_markets_forecast_calc.mfc_indicator_id = 31) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (sys_var.max_iter - 5)
                   FROM im.sys_var
                  WHERE (sys_var.indicator = 31))) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            im_markets_forecast_calc.mfc_val_8 AS value,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 2) AND (im_markets_forecast_calc.mfc_indicator_id = 34) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (sys_var.max_iter - 5)
                   FROM im.sys_var
                  WHERE (sys_var.indicator = 34))) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))) t
     LEFT JOIN im.im_indicator t1 ON ((t.mfc_indicator_id = t1.ind_id)))
     LEFT JOIN im.im_market_country t2 ON (((t.mfc_market_id = t2.m_id) AND (t2.m_commodity = 2))))
     LEFT JOIN bi.countries t3 ON ((t2.m_country = t3.id)));
CREATE OR REPLACE VIEW im.v_forecasted_physical_power_balance AS SELECT t.mfc_iteration AS "Итеррация",
    t.mfc_scenario AS "Сценарий",
    t2.country_rus AS "Рынок",
    t3.ind_name_ru AS indicator,
    t.value,
    t.mfc_datetime_utc AS "Дата-время UTC"
   FROM (((( SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            (- im_markets_forecast_calc.mfc_val_1) AS value,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 1) AND (im_markets_forecast_calc.mfc_indicator_id = 17) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            (- im_markets_forecast_calc.mfc_val_1) AS value,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 1) AND (im_markets_forecast_calc.mfc_indicator_id = 4) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            (- im_markets_forecast_calc.mfc_val_1) AS value,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 1) AND (im_markets_forecast_calc.mfc_indicator_id = 1) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            (- im_markets_forecast_calc.mfc_val_8) AS value,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 1) AND (im_markets_forecast_calc.mfc_indicator_id = 2) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            (- im_markets_forecast_calc.mfc_val_8) AS value,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 1) AND (im_markets_forecast_calc.mfc_indicator_id = ANY (ARRAY[1, 2, 8, 9, 10, 11, 12, 13, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49])) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            im_markets_forecast_calc.mfc_val_8 AS value,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 1) AND (im_markets_forecast_calc.mfc_indicator_id = ANY (ARRAY[1, 2, 8, 9, 10, 11, 12, 13, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, NULL::integer])) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            im_markets_forecast_calc.mfc_val_2 AS value,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 1) AND (im_markets_forecast_calc.mfc_indicator_id = 1) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))
        UNION ALL
         SELECT im_markets_forecast_calc.mfc_iteration,
            im_markets_forecast_calc.mfc_scenario,
            im_markets_forecast_calc.mfc_market_id,
            im_markets_forecast_calc.mfc_indicator_id,
            im_markets_forecast_calc.mfc_val_2 AS value,
            im_markets_forecast_calc.mfc_datetime_utc
           FROM im.im_markets_forecast_calc
          WHERE ((im_markets_forecast_calc.mfc_commodity_id = 1) AND (im_markets_forecast_calc.mfc_indicator_id = 2) AND (im_markets_forecast_calc.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)) AND (im_markets_forecast_calc.mfc_scenario = ANY (ARRAY[1, 2, 3])))) t
     LEFT JOIN im.im_market_country t1 ON (((t.mfc_market_id = t1.m_id) AND (t1.m_commodity = 1))))
     LEFT JOIN bi.countries t2 ON ((t1.m_country = t2.id)))
     LEFT JOIN im.im_indicator t3 ON ((t.mfc_indicator_id = t3.ind_id)));
CREATE OR REPLACE VIEW im.v_power_equilibrium_price AS SELECT t.mfc_iteration AS "Итерация",
    t.mfc_scenario AS "Сценарий",
    t2.country_rus AS "Рынок",
    COALESCE(NULLIF(t.mfc_val_1, 'NaN'::double precision), (0)::double precision) AS "Значение",
    t.mfc_datetime_utc AS "Дата-время UTC"
   FROM ((im.im_markets_forecast_calc t
     LEFT JOIN im.im_market_country t1 ON (((t.mfc_market_id = t1.m_id) AND (t1.m_commodity = 1))))
     LEFT JOIN bi.countries t2 ON ((t1.m_country = t2.id)))
  WHERE ((t.mfc_indicator_id = 18) AND (t.mfc_iteration > ( SELECT (im_system_variables.max_iter - 8)
           FROM im.im_system_variables)));
CREATE OR REPLACE VIEW im.v_gas_market_price AS SELECT t1.mfc_iteration AS iteration,
    t1.mfc_scenario AS scenario,
    t3.country_rus AS market,
    t1.mfc_val_1,
    t1.mfc_val_2,
    t1.mfc_date
   FROM ((( SELECT im_markets_forecast_calc_daily.mfc_iteration,
            im_markets_forecast_calc_daily.mfc_market_id,
            im_markets_forecast_calc_daily.mfc_scenario,
            im_markets_forecast_calc_daily.mfc_val_1,
            im_markets_forecast_calc_daily.mfc_val_2,
            im_markets_forecast_calc_daily.mfc_date
           FROM im.im_markets_forecast_calc_daily
          WHERE ((im_markets_forecast_calc_daily.mfc_commodity_id = 2) AND (im_markets_forecast_calc_daily.mfc_indicator_id = 24) AND (im_markets_forecast_calc_daily.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))) t1
     LEFT JOIN im.im_market_country t2 ON (((t1.mfc_market_id = t2.m_id) AND (t2.m_commodity = 2))))
     LEFT JOIN bi.countries t3 ON (((t2.m_country = t3.id) AND (t2.m_commodity = 2))));
CREATE OR REPLACE VIEW im.v_forecast_power_balance AS SELECT t.mfc_iteration AS "Итерация",
    t.mfc_scenario AS "Сценарий",
    t.mfc_datetime_local AS "Местное дата-время",
    t.mfc_datetime_utc AS "Дата-время UTC",
    t3.country_rus AS "Рынок",
    t4.ind_name_ru AS "Индикатор",
    t.value AS "Значение"
   FROM (((( SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 8) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 9) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 10) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_2 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 11) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 12) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 13) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            (- t1.mfc_val_1) AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 17) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 37) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 38) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 39) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 40) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 41) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 42) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 43) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 44) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 45) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 46) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 47) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 48) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))
        UNION ALL
         SELECT t1.mfc_iteration,
            t1.mfc_scenario,
            t1.mfc_datetime_local,
            t1.mfc_datetime_utc,
            t1.mfc_market_id,
            t1.mfc_indicator_id,
            t1.mfc_val_1 AS value
           FROM im.im_markets_forecast_calc t1
          WHERE ((t1.mfc_indicator_id = 49) AND (t1.mfc_iteration > ( SELECT (im_system_variables.max_iter - 5)
                   FROM im.im_system_variables)))) t
     LEFT JOIN im.im_market_country t2 ON (((t.mfc_market_id = t2.m_id) AND (t2.m_commodity = 1))))
     LEFT JOIN bi.countries t3 ON ((t2.m_country = t3.id)))
     LEFT JOIN im.im_indicator t4 ON ((t.mfc_indicator_id = t4.ind_id)));


CREATE OR REPLACE VIEW im.v_forecast_gas_balance
AS
SELECT t.mfc_iteration      AS "Итерация",
       t.mfc_scenario       AS "Сценарий",
       t.mfc_datetime_utc   AS "Дата-время UTC",
       t3.country_rus       AS "Рынок",
       t4.ind_name_ru       AS "Индикатор",
       t.val                AS "Значение индикатора"
FROM
(
    SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             - t1.mfc_val_2 AS val
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 21
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 4
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             - t1.mfc_val_7
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 22
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 4
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 25
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 4
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_1
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 34
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 4
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.mfc_iteration,
             t1.mfc_scenario,
             t1.mfc_datetime_utc,
             t1.mfc_market_id,
             t1.mfc_indicator_id,
             t1.mfc_val_2
      FROM im.im_markets_forecast_calc t1
      WHERE t1.mfc_indicator_id = 36
        AND t1.mfc_iteration > ((SELECT im_system_variables.max_iter - 4
                                 FROM im.im_system_variables))
      UNION ALL
      SELECT t1.gif_iteration,
             t1.gif_scenario,
             t1.gif_utc_datetime_dst,
             t1.gif_dst,
             t1.gif_indicator,
             t1.gif_val_1
      FROM im.im_gas_impex_forecast_calc t1
      WHERE t1.gif_indicator = 26 -- Импорт
      AND t1.gif_iteration > (SELECT max_iter - 4 FROM im.im_system_variables)
      UNION ALL
      SELECT t1.gif_iteration,
             t1.gif_scenario,
             t1.gif_utc_datetime_src,
             t1.gif_src,
             t1.gif_indicator,
             - t1.gif_val_1
      FROM im.im_gas_impex_forecast_calc t1
      WHERE t1.gif_indicator = 27 -- Экспорт
      AND t1.gif_iteration > (SELECT max_iter - 4 FROM im.im_system_variables)
) t
LEFT JOIN im.im_market_country t2 ON t.mfc_market_id = t2.m_id AND t2.m_commodity = 2
LEFT JOIN bi.countries t3 ON t2.m_country = t3.id
LEFT JOIN im.im_indicator t4 ON t.mfc_indicator_id = t4.ind_id;
end;
$$;

alter procedure sp_restore_all_dashboards() owner to postgres;

