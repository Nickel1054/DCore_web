create view v_eq_available_installed_capacity
            ("Date Hour", "Commodity", "Country Code", "Available Capacity MW", "Installed Capacity MW") as
SELECT e.date_time                   AS "Date Hour",
       c.commodity                   AS "Commodity",
       z.zone                        AS "Country Code",
       e.available_capacity_absolute AS "Available Capacity MW",
       e.installed_capacity          AS "Installed Capacity MW"
FROM eq_installed_available_capacity e
         JOIN eq_installed_available_capacity_zone z ON e.zone = z.id
         JOIN eq_installed_available_capacity_commodity c ON e.commodity = c.id
WHERE e.iteration = ((SELECT max(eq_installed_available_capacity.iteration) AS max
                      FROM eq_installed_available_capacity));

alter table v_eq_available_installed_capacity
    owner to postgres;

