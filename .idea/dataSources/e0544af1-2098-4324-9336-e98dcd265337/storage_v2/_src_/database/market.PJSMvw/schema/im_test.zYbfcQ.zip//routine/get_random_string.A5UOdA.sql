create function get_random_string() returns text
    language sql
as
$$
    SELECT STRING_AGG ( SUBSTR ( 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', CEIL (RANDOM() * 52)::integer, 1), '')
    FROM GENERATE_SERIES(1, 10)
$$;

alter function get_random_string() owner to postgres;

