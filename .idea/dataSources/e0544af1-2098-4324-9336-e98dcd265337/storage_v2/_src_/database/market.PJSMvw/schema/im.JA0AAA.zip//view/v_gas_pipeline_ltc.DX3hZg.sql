create view v_gas_pipeline_ltc
            ("LTC ID", "Поставщик", "Страна покупателя", "subcontract ID", "Интерконнектор", "Начало контракта",
             "Окончание контракта", "Фиксированный объём", "Плавающий объём")
as
SELECT t1.id                                      AS "LTC ID",
       t2.cp_name                                 AS "Поставщик",
       t3.country_rus                             AS "Страна покупателя",
       t4.id                                      AS "subcontract ID",
       t5.name                                    AS "Интерконнектор",
       t4.start_date                              AS "Начало контракта",
       t4.end_date                                AS "Окончание контракта",
       t4.fixed_vol_mwd                           AS "Фиксированный объём",
       COALESCE(t4.float_vol_mwd::text, ''::text) AS "Плавающий объём"
FROM im.gas_pipeline_ltc_info t1
         LEFT JOIN im.gas_counterparty_info t2 ON t1.supplier = t2.cp_id
         LEFT JOIN countries t3 ON t1.buyer_country = t3.id
         LEFT JOIN im.gas_pipeline_ltc_timeperiod_aux t4 ON t1.id = t4.ltc_id
         LEFT JOIN im.gas_interconn_info t5 ON t4.interconn_id = t5.id;

alter table v_gas_pipeline_ltc
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on v_gas_pipeline_ltc to quicksight;

