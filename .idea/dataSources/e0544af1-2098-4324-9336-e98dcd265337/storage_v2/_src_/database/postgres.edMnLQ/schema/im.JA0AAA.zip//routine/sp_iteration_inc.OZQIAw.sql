create procedure sp_iteration_inc()
    language plpgsql
as
$$
DECLARE
    n INTEGER;
BEGIN
    SELECT INTO n COUNT(*) FROM im.im_iteration;
    INSERT INTO im.im_iteration(it_id, it_start_time, it_end_time) VALUES (n+1,CURRENT_TIMESTAMP,NULL);
END;
$$;

alter procedure sp_iteration_inc() owner to postgres;

