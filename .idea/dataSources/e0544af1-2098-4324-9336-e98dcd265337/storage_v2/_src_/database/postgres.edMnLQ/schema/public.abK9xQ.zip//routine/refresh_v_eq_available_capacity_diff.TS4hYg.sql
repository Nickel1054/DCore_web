create function refresh_v_eq_available_capacity_diff() returns void
    language plpgsql
as
$$
     DECLARE
        retry_interval INTERVAL := '5 minutes';
    BEGIN
        LOOP
            BEGIN
                REFRESH MATERIALIZED VIEW market.bi.v_eq_available_capacity_diff;
                EXIT;
            EXCEPTION
                WHEN OTHERS THEN
                    RAISE NOTICE 'Exception detected, waiting before retrying...';
                    PERFORM pg_sleep(retry_interval);
            END;
        END LOOP;
    END;
$$;

alter function refresh_v_eq_available_capacity_diff() owner to postgres;

